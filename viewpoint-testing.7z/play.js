const viewPoints = [
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Screen reolution",
      description: "Screen reolution",
    },
    sample: "Screen reolution",
    confirmation: "Screen reolution",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    id: "19d96788-4c04-4291-8278-181999905433",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Color",
      description: "Color",
    },
    sample: "Color",
    confirmation: "Color",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "7b664a95-b28f-49e8-939a-d8dd800356f4",
    id: "b5ec4533-4244-486c-b714-266971c61923",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Status bar",
      description: "Status bar",
    },
    sample: "Status bar",
    confirmation: "Status bar",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    id: "da3df2f0-cfc4-4569-9cfe-2d66db2ea479",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "UI Testing",
      description: "UI Testing",
    },
    sample: "UI Testing",
    confirmation: "UI Testing",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: null,
    id: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Objects",
      description: "Objects",
    },
    sample: "Objects",
    confirmation: "Objects",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "7b664a95-b28f-49e8-939a-d8dd800356f4",
    id: "674f63dd-adcc-4fc0-8bda-a669dcbb6b77",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Layout",
      description: "Layout",
    },
    sample: "Layout",
    confirmation: "Layout",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    id: "7b664a95-b28f-49e8-939a-d8dd800356f4",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Type",
      description: "Type",
    },
    sample: "Type",
    confirmation: "Type",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: null,
    id: "023eb582-8dd4-4c41-8f66-ecfb24ced455",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
];

const viewPoints2 = [
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Screen reolution",
      description: "Screen reolution",
    },
    sample: "Screen reolution",
    confirmation: "Screen reolution",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    id: "19d96788-4c04-4291-8278-181999905433",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Status bar",
      description: "Status bar",
    },
    sample: "Status bar",
    confirmation: "Status bar",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    id: "da3df2f0-cfc4-4569-9cfe-2d66db2ea479",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "UI Testing",
      description: "UI Testing",
    },
    sample: "UI Testing",
    confirmation: "UI Testing",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: null,
    id: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Objects",
      description: "Objects",
    },
    sample: "Objects",
    confirmation: "Objects",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "7b664a95-b28f-49e8-939a-d8dd800356f4",
    id: "674f63dd-adcc-4fc0-8bda-a669dcbb6b77",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Layout",
      description: "Layout",
    },
    sample: "Layout",
    confirmation: "Layout",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: "219843e2-356c-4154-8b20-8b6bffbd0ab9",
    id: "7b664a95-b28f-49e8-939a-d8dd800356f4",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
  {
    testTypeId: "964d6b8f-5475-4512-b15b-e7417da7043e",
    viewPointCategoryId: "20457353-3444-4d73-aa8f-1b6daf23abf2",
    viewDetail: {
      language: "vi",
      name: "Type",
      description: "Type",
    },
    sample: "Type",
    confirmation: "Type",
    image: null,
    viewPointCollectionId: "459221fa-5d2d-4754-8984-24b3132c7d88",
    parentId: null,
    id: "023eb582-8dd4-4c41-8f66-ecfb24ced455",
    createdBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    updateBy: "04cecadc-672e-4c12-c8da-08daa51231eb",
    createdAt: "2022-10-11T00:00:00",
    updatedAt: "2022-10-11T00:00:00",
    isActive: true,
    isDeleted: false,
  },
];

const convertTreeData = (table) => {
  const keys = table.map((x) => x?.id);
  const formattedData = table.map((x) => {
    return {
      key: x.id,
      title: x.viewDetail.name,
      parentKey: x?.parentId,
      description: x?.description,
      isActive: x?.isActive,
    };
  });
  const result = formattedData
    .map((parent) => {
      const children = formattedData.filter((child) => {
        if (child.key !== child.parentKey && child.parentKey === parent.key) {
          return true;
        }
        return false;
      });

      if (children.length) {
        parent.children = children;
      }
      return parent;
    })
    .filter((obj) => {
      if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
        return true;
      }
      return false;
    });
  console.log(result);
};
convertTreeData(viewPoints);
const isSameUser = (a, b) => a.id === b.id;
const onlyInLeft = (left, right, compareFunction) =>
  left.filter(
    (leftValue) =>
      !right.some((rightValue) => compareFunction(leftValue, rightValue))
  );

const onlyInViewpoint = onlyInLeft(viewPoints, viewPoints2, isSameUser);
const onlyInViewpoint2 = onlyInLeft(viewPoints2, viewPoints, isSameUser);

const result = [...onlyInViewpoint, ...onlyInViewpoint2];

// const convertTreeData2 = (table) => {
//   const keys = table.map((x) => x?.id);
//   const formattedData = table.map((x) => {
//     return {
//       testTypeId: x.testTypeId,
//       viewPointCategoryId: x.viewPointCategoryId,
//       viewDetail: JSON.stringify([x?.viewDetail]),
//       sample: x?.sample,
//       confirmation: x?.confirmation,
//       image: x?.image,
//       viewPointCollectionId: x?.viewPointCollectionId,
//       parentId: x?.parentId,
//       id: x?.id,
//       createdBy: x?.createdBy,
//       updateBy: x?.updateBy,
//       createdAt: x?.createdAt,
//       updatedAt: x?.updatedAt,
//       isActive: x?.isActive,
//       isDeleted: x?.isDeleted,
//       parentKey: x?.parentId,
//       key: x.id,
//     };
//   });
//   const result = formattedData
//     .map((parent) => {
//       const children = formattedData.filter((child) => {
//         if (
//           child.key !== child.parentKey &&
//           child.parentKey === parent.key
//         ) {
//           return true;
//         }
//         return false;
//       });
//       if (children.length) {
//         parent.children = children;
//       }
//       return parent;
//     })
//     .filter((obj) => {
//       if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
//         return true;
//       }
//       return false;
//     });
//   // console.log(result[0].children);
//   return result;
// };
