import { themeReducer } from "./themeSlice";
import { combineReducers } from "redux";
import { authReducer } from "./authSlice";
import { domainReducer } from "./domainSlice";
import { roleReducer } from "./roleSlice";
import { userReducer } from "./userSlice";
import { viewpointCollectionReducer } from "./viewpointCollectionSlice";
import { productReducer } from "./productSlice";

export const rootReducer = combineReducers({
  auth: authReducer,
  theme: themeReducer,
  domain: domainReducer,
  role: roleReducer,
  user: userReducer,
  viewpoint: viewpointCollectionReducer,
  product: productReducer,
});
