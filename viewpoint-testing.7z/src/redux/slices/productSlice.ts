import { createSlice } from "@reduxjs/toolkit";
import { stateAuthType } from "@models/type";
type stateRoleType = {
  products: any;
  loading: boolean;
  loadingGetById: boolean ;
  currentProduct: any
};
const initialState: stateRoleType = {
  products: null,
  loading: false,
  loadingGetById: false,
  currentProduct: null
};

const productSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    getAllProduct(state, action) {
      // TODO: reducer for pending login action
      state.loading = true;
    },
    getAllProductSuccess(state, action) {
      state.products = action.payload;
      state.loading = false;
    },
    getAllProductError(state) {
      state.loading = false;
    },
    getProductById(state, action) {
      // TODO: reducer for pending login action
      state.loadingGetById = true;
    },
    getProductByIdSuccess(state, action) {
      state.currentProduct = action.payload.data;
      state.loadingGetById = false;
    },
    getProductByIdError(state) {
      state.loadingGetById = false;
    },
    deleteProduct(state, action) {
      state.loading = false;
    },
    cloneProduct(state, action) {
      state.loading = true;
    },
    cloneProductSuccess(state, action) {
      state.loading = false;
    },
    cloneProductError(state, action) {
      state.loading = false;
    },
    createProduct(state, action) {
      state.loading = true;
    },
    createProductSuccess(state, action) {
      state.loading = false;
    },
  },
});

const { actions, reducer } = productSlice;

export {
  actions as productActions,
  reducer as productReducer,
};
