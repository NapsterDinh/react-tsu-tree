// response data
export interface IReponseData {
  data?: IResponseViewPointCollection;
  errors?: [];
  isSucceeded?: boolean;
}

// filter log
export interface IDataBodyFilterLog {
  text?: string;
  pageNumber?: string | number;
  pageSize?: string | number;
  type?: string | number;
  owner?: string | number;
  time?: string | number;
}

export interface Detail {
  name?: string;
  description?: string;
  language?: string;
}

export interface JsonDetail {
  Name?: string;
  Description?: string;
  Language?: string;
}

// domain
export interface Domain {
  detail: Detail & JsonDetail;
  parentId: React.Key | null;
  user: {
    id: React.Key;
    userName: string;
    account: string;
    email: string;
    phoneNumber: string;
  };
  id: React.Key;
  index: number;
  createdBy: React.Key;
  updateBy: React.Key;
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
  isDeleted: boolean;
  previousDomainId: React.Key | null;
  nextDomainId: React.Key | null;
}

// Test type
export interface IDataBodyFilterTestType {
  text?: string;
  pageNumber: number | string;
  pageSize: number | string;
  sort?: number | string;
  isActive?: number | string;
}

// viewpoint collection
export interface IResponseViewPointCollection {
  cloneCollectionId: string;
  createdAt: Date;
  createdBy: string;
  detail: Detail;
  domains: Domain[];
  id: string;
  isActive: boolean;
  isDeleted: boolean;
  rating: null & number;
  status: boolean & number;
  updateBy: string;
  updatedAt: Date;
  user: IUser;
  viewPoints: [];
}

// user
export interface IUser {
  account: string;
  email: string;
  id: string;
  phoneNumber: string & null;
  userName: string;
}

type Pagination = {
  currentPage: number;
  hasNext: boolean;
  hasPreviousPage: boolean;
  pageSize: number;
  totalCount: number;
  totalPages: number;
};

type Role = "Admin" | "User" | "Leader" | "Guest";

export type User = {
  account?: string;
  role?: Role | string;
  id?: string;
  userName?: string;
  permissions?: Permission[];
  createdAt?: Date;
  updatedAt?: Date;
  isActive?: boolean;
  isDeleted?: boolean;
};

export type Permission =
  | "DOMAIN.VIEW"
  | "DOMAIN.CREATE"
  | "DOMAIN.UPDATE"
  | "DOMAIN.DELETE"
  | "CATEGORY.VIEW"
  | "CATEGORY.UPDATE"
  | "CATEGORY.CREATE"
  | "CATEGORY.DELETE"
  | "TEST_TYPE.VIEW"
  | "TEST_TYPE.UPDATE"
  | "TEST_TYPE.CREATE"
  | "TEST_TYPE.DELETE"
  | "USER.VIEW"
  | "USER.UPDATE_ROLE"
  | "USER.UPDATE_STATUS"
  | "ROLE.VIEW"
  | "ROLE.CREATE"
  | "ROLE.UPDATE"
  | "ROLE.DELETE"
  | "VIEWPOINT.VIEW"
  | "VIEWPOINT.CREATE"
  | "VIEWPOINT.UPDATE"
  | "VIEWPOINT.DELETE"
  | "VIEWPOINT.CLONE"
  | "PRODUCT.VIEW"
  | "PRODUCT.CREATE"
  | "PRODUCT.UPDATE"
  | "PRODUCT.DELETE"
  | "PRODUCT.CLONE"
  | "REQUEST.VIEW"
  | "REQUEST.CREATE"
  | "REQUEST.UPDATE"
  | "REQUEST.REVIEW";
