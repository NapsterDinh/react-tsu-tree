//text-area
export const MAX_LENGTH_TEXT_AREA = 1200;
export const MIN_LENGTH_TEXT_AREA = 2;
export const ROWS_DEFAULT_TEXT_AREA = 4;
//input
export const MIN_LENGTH_INPUT = 2;
export const MAX_LENGTH_INPUT_NAME_FIELD = 40;
