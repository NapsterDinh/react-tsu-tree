import { DataTreeNode } from "@models/type";
import React, { useState, useEffect } from "react";
import { Domain } from "@models/model";
import { DataNode } from "antd/lib/tree";

export const patternNotContainsSpecialCharacters =
  /\`|\~|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\+|\=|\[|\{|\]|\}|\||\\|\'|\<|\,|\.|\>|\?|\/|\""|\;|\:/;

export const checkContainsSpecialCharacter = (values) => {
  if (typeof values === "string") {
    return patternNotContainsSpecialCharacters.test(values.trim());
  }
  return false;
};
export const removeEmoji = (value) => {
  if (typeof value === "string") {
    return !value.replace(
      /([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g,
      ""
    );
  }
  return false;
};
export const debounce = (callback, wait) => {
  let timeoutId = null;
  return () => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => {
      callback();
    }, wait);
  };
};

export const deepFind = (obj, path) => {
  const paths = path.split(".");
  let current = obj;

  for (let i = 0; i < paths.length; ++i) {
    if (current[paths[i]] == undefined) {
      return undefined;
    } else {
      current = current[paths[i]];
    }
  }
  return current;
};

export const deepCopy = (object: any) => {
  return JSON.parse(JSON.stringify(object));
};

export const convertedToDataTree = (
  parentViewpoint,
  vpCollection,
  keyFlatData,
  pathGetTitle
) => {
  parentViewpoint.children = [];

  if (parentViewpoint?.orderStrings?.length > 0) {
    for (let index = 0; index < parentViewpoint?.orderStrings.length; index++) {
      const orderItem = parentViewpoint?.orderStrings[index];
      for (
        let indexVP = 0;
        indexVP < vpCollection?.[keyFlatData].length;
        indexVP++
      ) {
        const viewpointItem = vpCollection?.[keyFlatData][indexVP];
        if (viewpointItem?.id === orderItem) {
          viewpointItem.key = viewpointItem?.id; //do not use spread to clone
          viewpointItem.parentKey = viewpointItem?.parentId;
          viewpointItem.title = deepFind(viewpointItem, pathGetTitle);
          viewpointItem.path = parentViewpoint?.path
            ? parentViewpoint.path + "/" + viewpointItem.key
            : viewpointItem.key;

          //optional
          delete viewpointItem.id;
          delete viewpointItem.parentId;

          parentViewpoint.children.push(viewpointItem);
          convertedToDataTree(
            viewpointItem,
            vpCollection,
            keyFlatData,
            pathGetTitle
          );
        }
      }
    }
  }
  const newData = {
    ...parentViewpoint,
    flatDataList: parentViewpoint[keyFlatData],
  };
  delete newData[keyFlatData];
  return newData;
};

export const deleteMultiObjectByListObject = (arrayOfObjects, listToDelete) => {
  const temp = [...arrayOfObjects];
  for (let i = 0; i < arrayOfObjects.length; i++) {
    const id = arrayOfObjects[i];

    if (listToDelete.indexOf(id) !== -1) {
      temp.splice(i, 1);
    }
  }
  return temp;
};

export const getPasswordRules = (extendRule = []) => {
  return [
    {
      required: true,
      message: "Password is required",
      title: "Required",
    },
    {
      pattern: /\d/,
      message: "Password has at least 1 digit",
      title: "At least 1 digit",
    },
    {
      pattern: /[a-z]/,
      message: "Password has at least 1 lowercase",
      title: "At least 1 lowercase",
    },
    {
      pattern: /[A-Z]/,
      message: "Password has at least 1 uppercase",
      title: "At least 1 uppercase",
    },
    {
      pattern: /[!@#$%^&*?]/,
      message: "Password has at least 1 special character",
      title: "At least 1 special character",
    },
    {
      pattern: /^.{8,50}$/,
      message: "Password has 8 to 50 characters",
      title: "8 to 50 characters",
    },
    ...extendRule,
  ];
};

export function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

const sortArray = (array) => {
  const objectMap = new Map();
  let firstObject;
  const sortedArray = [];
  for (const obj of array) {
    objectMap.set(obj.key, obj);
    if (!obj.prev) {
      firstObject = obj;
    }
  }
  for (let start = firstObject; start; start = objectMap.get(start.next)) {
    sortedArray.push(start);
  }
  return sortedArray;
};

export const convertTreeData = (data) => {
  const keys = data.map((x: Domain) => x.id);

  const formatedData = data.map((x: Domain) => {
    return {
      key: x.id,
      title: x?.detail?.name,
      description: x?.detail?.description,
      parentKey: x.parentId,
      isActive: x.isActive,
      index: x.index,
      prev: x.previousDomainId,
      next: x.nextDomainId,
    };
  });
  const result = formatedData
    .map((parent: DataTreeNode) => {
      const children = formatedData.filter((child: DataTreeNode) => {
        if (child.key !== child.parentKey && child.parentKey === parent.key) {
          return true;
        }
        return false;
      });
      if (children.length) {
        // parent.children = children;
        parent.children = sortArray(children);
      }
      return parent;
    })
    .filter((obj: DataTreeNode) => {
      if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
        return true;
      }
      return false;
    });
  return sortArray(result);
  // return result;
};

// update tree node
const updateDataTree = (
  element: DataTreeNode,
  matchingKey: React.Key,
  changedData: DataTreeNode
) => {
  if (element.key == matchingKey) {
    element.title = changedData.title;
    element.isActive = changedData.isActive;
    element.description = changedData.description;
    element.index = changedData.index;
    element.prev = changedData.prev;
    element.next = changedData.next;
    return;
  } else if (element.children != null) {
    for (let i = 0; i < element.children.length; i++) {
      return updateDataTree(element.children[i], matchingKey, changedData);
    }
    return;
  }
  return;
};

export const loopUpdateDataTreeNode = (data, matchingKey, changedData) => {
  for (let i = 0; i < data.length; i++) {
    updateDataTree(data[i], matchingKey, changedData);
  }
  return data;
};

// get list id children of tree node
const getAllIdTreeData = (listKey = [], data) => {
  data.map((item) => {
    listKey.push(item.key);
    if (item.children) {
      getAllIdTreeData(listKey, item.children);
    }
  });
};

export const getListIdChildrenTreeNode = (listKey = [], data, key) => {
  data.map((item) => {
    if (item.key === key) {
      listKey.push(item.key);
      if (item.children) {
        getAllIdTreeData(listKey, item.children);
      }
      return;
    } else {
      if (item.children) {
        getListIdChildrenTreeNode(listKey, item.children, key);
      }
    }
  });
  return listKey;
};

export const generateList = (
  data: DataTreeNode[],
  generatedList: DataTreeNode[]
) => {
  for (let i = 0; i < data?.length; i++) {
    const node = data[i];
    generatedList.push({
      key: node.key,
      title: node.title,
      parentKey: node.parentKey,
      description: node.description,
      isActive: node.isActive,
      index: node.index,
      prev: node.prev,
      next: node.next,
    });
    if (node.children) {
      generateList(node.children, generatedList);
    }
  }
};

export const generateFlattenedList = (data) => {
  return data.map((item) => {
    return {
      key: item.id,
      title: item?.detail.name,
      parentKey: item.parentId,
      description: item?.detail.description,
      isActive: item.isActive,
      index: item.index,
      prev: item.previousDomainId,
      next: item.nextDomainId,
    };
  });
};

export const expandedKeysWithLevel = (
  data,
  levelShow: number,
  expandedKeys: React.Key[]
) => {
  if (levelShow - 1 > 0) {
    data.map((item) => {
      expandedKeys.push(item.key);
      if (levelShow - 1 > 0) {
        if (item.children) {
          //de quy
          expandedKeysWithLevel(item.children, levelShow - 1, expandedKeys);
        }
      }
    });
  }
  return expandedKeys;
};

export const convertViewpointToDataTree = (
  data,
  keys: Array<string>,
  temp: { children }
) => {
  data.forEach(function (a) {
    return keys.reduce(function (r, k) {
      if (!r[a[k]]) {
        r[a[k]] = { children: [] };
        r.children.push({
          ["key"]: a[k],
          ["children"]: r[a[k]].children,
          // content: a,
          title:
            k === "domainId"
              ? a.domainId
              : k === "testTypeId"
              ? a.testTypeId
              : k === "viewPointCategoryId"
              ? a.viewPointCategoryId
              : a.viewDetail.name,
          type:
            k === "domainId"
              ? "domain"
              : k === "testTypeId"
              ? "test-type"
              : k === "viewPointCategoryId"
              ? "category"
              : "viewpoint",
        });
      }
      return r[a[k]];
    }, temp);
  });
};

export const getNodeListToUpdate = (
  dragNode: DataTreeNode & DataNode,
  dropNode: DataTreeNode & DataNode,
  dropToGap: boolean,
  dropPosition: number,
  flattenedData: DataTreeNode[]
) => {
  const domainList = [];
  if (dragNode.prev !== dropNode.key || dropPosition === -1 || !dropToGap) {
    if (dropPosition === -1) {
      if (dragNode?.prev) {
        const oldPrevDomain = {
          id: dragNode?.prev,
          nextDomainId: dragNode?.next,
          previousDomainId: "",
          parentId: "",
        };
        domainList.push(oldPrevDomain);
      }
      if (dragNode?.next) {
        const oldNextDomain = {
          id: dragNode?.next,
          previousDomainId: dragNode?.prev,
          nextDomainId: "",
          parentId: "",
        };
        domainList.push(oldNextDomain);
      }
      const newCurrentDomain = {
        id: dragNode?.key,
        parentId: null,
        previousDomainId: null,
        nextDomainId: dropNode?.key,
      };
      domainList.push(newCurrentDomain);
      const newNextDomain = {
        id: dropNode.key,
        previousDomainId: dragNode?.key,
        nextDomainId: "",
        parentId: "",
      };
      domainList.push(newNextDomain);
    } else {
      // drag / drop inside a branch in tree
      if (dropToGap) {
        if (dragNode?.prev) {
          const oldPrevDomain = {
            id: dragNode?.prev,
            nextDomainId: dragNode?.next,
            previousDomainId: "",
            parentId: "",
          };
          domainList.push(oldPrevDomain);
        }
        if (dragNode?.next) {
          const oldNextDomain = {
            id: dragNode?.next,
            previousDomainId: dragNode?.prev,
            parentId: "",
            nextDomainId: "",
          };
          domainList.push(oldNextDomain);
        }
        if (dropPosition === 0) {
          const parentDomainOfDragedDomain: DataTreeNode = flattenedData.find(
            (item: DataTreeNode) =>
              item.parentKey === dropNode.key && item?.prev === null
          );
          if (parentDomainOfDragedDomain) {
            const newCurrentDomain = {
              id: dragNode?.key,
              previousDomainId: null,
              nextDomainId: parentDomainOfDragedDomain?.key,
              parentId: "",
            };
            domainList.push(newCurrentDomain);
            const newNextDomain = {
              id: parentDomainOfDragedDomain?.key,
              previousDomainId: dragNode?.key,
              parentId: parentDomainOfDragedDomain?.parentKey,
              nextDomainId: "",
            };
            domainList.push(newNextDomain);
          } else {
            const newCurrentDomain = {
              id: dragNode?.key,
              previousDomainId: null,
              nextDomainId: null,
              parentId: parentDomainOfDragedDomain?.parentKey,
            };
            domainList.push(newCurrentDomain);
          }
        } else {
          const newCurrentDomain = {
            id: dragNode?.key,
            nextDomainId: dropNode?.next,
            previousDomainId: dropNode?.key,
            parentId:
              dragNode?.parentKey === dropNode?.parentKey
                ? ""
                : dropNode?.parentKey,
          };
          domainList.push(newCurrentDomain);
          const newPrevDomain = {
            id: dropNode?.key,
            nextDomainId: dragNode?.key,
            parentId: "",
            previousDomainId: "",
          };
          domainList.push(newPrevDomain);

          if (dropNode?.next) {
            const newNextDomain = {
              id: dropNode?.next,
              previousDomainId: dragNode?.key,
              nextDomainId: "",
              parentId: "",
            };
            domainList.push(newNextDomain);
          }
        }
      } else {
        if (dragNode?.prev) {
          const oldPrevDomain = {
            id: dragNode?.prev,
            nextDomainId: dragNode?.next,
            previousDomainId: "",
            parentId: "",
          };
          domainList.push(oldPrevDomain);
        }
        if (dragNode?.next) {
          const oldNextDomain = {
            id: dragNode?.next,
            previousDomainId: dragNode?.prev,
            nextDomainId: "",
            parentId: "",
          };
          domainList.push(oldNextDomain);
        }
        const parentDomainOfDragedDomain: DataTreeNode = flattenedData.find(
          (item: DataTreeNode) =>
            item.parentKey === dropNode.key && item?.prev === null
        );
        if (
          parentDomainOfDragedDomain &&
          parentDomainOfDragedDomain?.key !== dragNode?.key
        ) {
          const newCurrentDomain = {
            id: dragNode?.key,
            parentId: dropNode?.key,
            previousDomainId: null,
            nextDomainId: parentDomainOfDragedDomain?.key,
          };
          domainList.push(newCurrentDomain);
          const newNextDomain = {
            id: parentDomainOfDragedDomain?.key,
            previousDomainId: dragNode?.key,
            nextDomainId: "",
            parentId: "",
          };
          domainList.push(newNextDomain);
        } else {
          const newCurrentDomain = {
            id: dragNode?.key,
            parentId: dropNode?.key,
            previousDomainId: null,
            nextDomainId: null,
          };
          domainList.push(newCurrentDomain);
        }
      }
    }
  }
  return domainList;
};
