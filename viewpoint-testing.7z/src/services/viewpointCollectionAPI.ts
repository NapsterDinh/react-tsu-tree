import { IReponseData } from "@models/model";
import { AxiosResponse } from "axios";
import { axiosInstance, axiosInstanceFormData } from "./axiosInstance";

const viewpointCollectionAPI = {
  getAllViewpointCollection: async ({
    payload,
  }: any): Promise<AxiosResponse<any>> => {
    if (payload.PageSize) {
      const url = `/ViewPointCollection?PageSize=${
        payload.PageSize
      }&PageNumber=${payload.PageNumber}&${payload.search.slice(1)}`;
      const response = axiosInstance.get<any>(url);
      return response;
    } else {
      const url = payload.search
        ? `/ViewPointCollection${payload.search}`
        : "/ViewPointCollection";
      const response = axiosInstance.get<any>(url);
      return response;
    }
  },

  getViewpointCollectionById: async (id: any): Promise<AxiosResponse<any>> => {
    const url = `/ViewPointCollection/GetById/${id}`;
    const response = axiosInstance.get<any>(url);
    return response;
  },
  deleteCollection: async ({
    payload,
  }: any): Promise<AxiosResponse<IReponseData>> => {
    const url = `/ViewPointCollection/${payload?.id}`;
    const response = axiosInstance.delete<any>(url);
    return response;
  },
  cloneCollection: async ({ payload }: any) => {
    const url = "/ViewPointCollection/AddVPCollection";
    const response = axiosInstance.post<any>(url, payload);
    return response;
  },
  createViewpointCollection: async ({
    payload,
  }: any): Promise<AxiosResponse<any>> => {
    const url = "/ViewPointCollection";
    const response = axiosInstance.post(url, payload);
    return response;
  },
  importViewpointCollection: async (
    payload
  ): Promise<AxiosResponse<any, any>> => {
    const url = "/Excel/ImportViewpoint";
    const response = axiosInstanceFormData.post(url, payload);
    return response;
  },
  exportViewpointCollection: async (id): Promise<AxiosResponse<any, any>> => {
    const url = "/ViewPointCollection/export";
    const response = axiosInstance.get(url + "/id");
    return response;
  },
  ratingViewpointCollection: async (
    id,
    rating
  ): Promise<AxiosResponse<any, any>> => {
    const url = "/Rating";
    const response = axiosInstance.post(url, {
      viewPointCollectionId: id,
      startRating: rating,
    });
    return response;
  },
  updateStatus: async (
    id,
    status,
    isActive
  ): Promise<AxiosResponse<any, any>> => {
    const url = "/ViewPointCollection/Update";
    const response = axiosInstance.put(url + `/${id}`, {
      status: status,
      // isActive: isActive,
    });
    return response;
  },
};

export default viewpointCollectionAPI;
