import { AxiosResponse } from "axios";
import { axiosInstance } from "./axiosInstance";

const productAPI = {
  getAllProduct: async ({
    payload,
  }: any): Promise<AxiosResponse<any>> => {
    if (payload.PageSize) {
      const url = `/Product?PageSize=${
        payload.PageSize
      }&PageNumber=${payload.PageNumber}&${payload.search.slice(1)}`;
      const response = axiosInstance.get<any>(url);
      return response;
    } else {
      const url = payload.search
        ? `/Product${payload.search}`
        : "/Product";
      const response = axiosInstance.get<any>(url);
      return response;
    }
  },

  getProductById: async (id: any): Promise<AxiosResponse<any>> => {
    const url = `/Product/GetById/${id}`;
    const response = axiosInstance.get<any>(url);
    return response;
  },
  deleteProduct: async ({ payload }: any): Promise<AxiosResponse<any>> => {
    const url = `/Product/${payload?.id}`;
    const response = axiosInstance.delete<any>(url);
    return response;
  },
  cloneProduct: async ({ payload }: any): Promise<AxiosResponse<any>> => {
    const url = "/Product/AddVPCollection";
    const response = axiosInstance.post<any>(url, payload);
    return response;
  },
  createProduct: async ({
    payload,
  }: any): Promise<AxiosResponse<any>> => {
    const url = "/Product";
    const response = axiosInstance.post(url, payload);
    return response;
  },
};

export default productAPI;
