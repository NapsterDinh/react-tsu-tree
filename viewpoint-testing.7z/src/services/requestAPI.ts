import { AxiosResponse } from "axios";
import { axiosInstance } from "./axiosInstance";

const requestAPI = {
  createRequest: async ({ payload }: any): Promise<AxiosResponse<any>> => {
    const url = "/Request";
    const response = axiosInstance.post(url, payload);
    return response;
  },
};

export default requestAPI;
