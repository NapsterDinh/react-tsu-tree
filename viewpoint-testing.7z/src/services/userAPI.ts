import { AxiosResponse } from "axios";
import { axiosInstance } from "./axiosInstance";

const userApi = {
  getAllUser: async ({ payload }: any): Promise<AxiosResponse<any>> => {
    if (payload.PageSize) {
      const url = `/User?PageSize=${payload.PageSize}&PageNumber=${
        payload.PageNumber
      }&${payload.search.slice(1)}`;
      const response = axiosInstance.get<any>(url, payload);
      return response;
    } else {
      const url = `/User${payload.search}`;
      const response = axiosInstance.get<any>(url, payload);
      return response;
    }
  },
  updateRole: async ({ payload }: any): Promise<AxiosResponse<any>> => {
    const url = `/User/UpdateUser/${payload.id}`;
    const response = axiosInstance.put<any>(url, { role: payload.role });
    return response;
  },
  updateStatus: async ({ payload }: any): Promise<AxiosResponse<any>> => {
    const url = `/User/UpdateStatus/${payload.id}`;
    const status = payload.isActive === "true" ? true : false;
    const response = axiosInstance.put<any>(url, {
      isActive: status,
    });
    return response;
  },
};

export { userApi };
