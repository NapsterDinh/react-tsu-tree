import { AxiosResponse } from "axios";
import type { User } from "@models/model";
import { axiosInstance } from "./axiosInstance";

const baseUrl = "/viewpoint";

export type IViewpoint = {
  id: number;
  name: string;
  thumbnail: string;
  owner: User;
  lastOpenedTime: Date;
  description: string;
  isPublic?: boolean;
  viewPointStructors: [];
};

export type ResponseViewpoints = {
  isSuccess: true;
  data: IViewpoint[];
  errors: string[];
};

const ViewpointAPI = {
  getAllViewpoint: async (): Promise<
    AxiosResponse<ResponseViewpoints, any>
  > => {
    const url = "/viewpoints";
    const response = axiosInstance.get(url);
    return response;
  },
  addNewViewpoint: async (
    payload
  ): Promise<AxiosResponse<ResponseViewpoints, any>> => {
    const response = axiosInstance.post(baseUrl, baseUrl);
    return response;
  },
};

export default ViewpointAPI;
