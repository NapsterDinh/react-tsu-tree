import styled, { createGlobalStyle } from "styled-components";
export const GlobalStyle = createGlobalStyle`
  * {
    font-family: ${() => {
      const language = localStorage.getItem("i18nextLng");
      language;
      switch (language) {
        case "en":
          return "Montserrat";
        case "vi":
          return "Montserrat";
        case "jp":
          return "Montserrat";
        default:
          return "Montserrat";
      }
    }}
  }
  body {
    color: var(--clr-text);
    font-weight: 500;

    .table-row-menu-dropdown
    {
        font-size: 20px;
        color: #5F6368;
        margin-right: 15px;
    }

    .ant-btn-icon-only
    {
      background-color: transparent;
      border: none;
      box-shadow: none;
      border-radius: 50%!important;
      width: 40px;
      height: 40px;
      padding: 8px;
      padding-top: 6px;
      svg
      {
        font-size: var(--font-size-icon-header);

      }
      &:hover
      {
        background-color: var(--background-hover-btn-icon);
      }
    }

    .ant-select
    {
      font-size: var(--font-size-span);
      .ant-select-selector
      {
        border-radius: var(--border-radius-element)!important;
        background-color: var(--background-side-bar-color)!important;
          transition: all 0.1s ease-in-out;
      }
      .ant-select-selection-item,
      .ant-select-arrow
      {
        color: var(--clr-text);
      }
    }

    /* input
    {
      font-size: var(--font-size-span)!important;
      padding: 5px 10px 5px!important;
    } */

    /* button */
    .ant-btn
    {
      border-radius: var(--border-radius-element);
      span
      {
        font-size: var(--font-size-span);
      }
    }

    .ant-btn-default:focus {
      background: initial;
    }

    .ant-btn-default {
      color: var(--clr-text) !important;
      background-color: transparent;
    }

    .ant-btn-default:hover {
      background-color: var(--background-color-cancel-btn-hover);
    }

    /* breadcrumb */
    .ant-breadcrumb
    {
      span
      {
        font-size: var(--font-size-span);
        color: var(--clr-text-second);
        &.ant-breadcrumb-link
        {
          color: var(--clr-text);
        }
      }
    }
    .ant-checkbox-disabled+span
    {
      color: var(--clr-background-icon-hover);
    }

    .ant-pagination-options
    {
      span
      {
        font-size: var(--font-size-span);
      }
    }

    /* dropdown */
    .ant-select-dropdown {
      padding: 0;
      border-radius: var(--border-radius-list);
      background-color: var(--background-side-bar-color);

      .ant-select-item-option-content {
        color: var(--clr-text);
      }

      .ant-select-item-option-selected:not(.ant-select-item-option-disabled) {
        background-color: var(--clr-background-menu-hover);
      }

      .ant-select-item-option-active:not(.ant-select-item-option-disabled) {
        background-color: var(--clr-background-menu-hover);
      }
    }

    .ant-result-title {
      font-weight: 600;
      font-size: 2.375rem;
    }

    .site-tree-search-value {
      color: #f50;
    }

    .ant-menu-vertical .ant-menu-item,
    .ant-menu-inline .ant-menu-item:not(:last-child) {
      margin: 0;
    }

    /* table ant*/
    .ant-table
    {
      box-shadow: var(--box-shadow-table);
      border-radius: var(--border-radius-element);
      background-color: var(--background-side-bar-color);
      border-bottom-left-radius: var(--border-radius-element);
      border-bottom-right-radius: var(--border-radius-element);
      transition: all ease-in-out 0.2s;
      thead th.ant-table-cell
      {
        color: var(--clr-text);
        font-weight: 600!important;
        font-size: var(--font-size-span);
        &:first-child
        {
          border-top-left-radius: var(--border-radius-element);
        }
        &:last-child
        {
          border-top-right-radius: var(--border-radius-element);
        }
      }

      tbody td *, tbody td
      {
        color: var(--clr-text);
        font-size: var(--font-size-span);
      }
      .ant-table-tbody>tr>td
      {
        border: none;
        &.ant-table-column-sort
        {
          background-color: transparent!important;
        }
      }
      .ant-table-tbody>tr.ant-table-row:hover>td, .ant-table-tbody>tr>td.ant-table-cell-row-hover
      {
        background-color: var(--background-color-selected-sidebar)!important;
      }
      .ant-table-tbody>tr.ant-table-placeholder:hover>td
      {
        background: none;
      }
      .ant-table-thead>tr>th
      {
        background: transparent;
      }
    }

    /* selector */
    .ant-select:not(.ant-select-customize-input) .ant-select-selector {
      border-radius:var(--border-radius-element);
      background-color: var(--background-color-element);
      /* border: solid 1px var(--clr-text-second); */
      transition-duration: 0.2s;
    }

    .ant-select-selection-item,
    .ant-select-arrow  {
      color: var(--clr-text-second);
      font-weight: 500;
    }

    /* input */
    .ant-input {
      color: var(--clr-text) !important;
      font-weight: 500 !important;
    }

    .ant-input::placeholder {
      color: var(--clr-text-second);
    }

    .ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input, .ant-input-status-error:not(.ant-input-disabled):not(.ant-input-borderless).ant-input:hover {
      background-color: var(--background-color-element);
    }

    /* search */
    .ant-input-search .ant-input-group .ant-input-affix-wrapper:not(:last-child),
    .ant-input-group>.ant-input:first-child {
      border-top-left-radius:var(--border-radius-element);
      border-bottom-left-radius:var(--border-radius-element);
    }

    .ant-input-affix-wrapper,
    .ant-input-group-addon,
    .ant-input {
      background-color: var(--background-color-element);
    }

    .ant-input-affix-wrapper {
      border: none;
    }

    .ant-input-prefix > .anticon > svg {
      color: var(--clr-text-second);
    }

    /* modal */
    .ant-modal-content,
    .ant-modal-header {
      background-color: var(--background-color-element);
    }

    .ant-modal-close {
      color: var(--clr-text-second);
    }

    .ant-modal-close:focus, .ant-modal-close:hover{
      color: var(--clr-text-second);
    }

    .ant-modal-header .ant-modal-title,
    .ant-form-item-label>label,
    .ant-form-item-label>label .ant-form-item-tooltip {
      color: var(--clr-text);
    }

    .ant-modal-confirm-title
    {
      color: var(--clr-text-second)!important;
    }
    .ant-modal-confirm-content
    {
      color: var(--clr-text)!important;
    }

    .ant-form-item-control-input-content > input.ant-input {
      color: var(--clr-text);
      font-weight: 500;
    }

    .ant-form-item-control-input-content > input.ant-input::placeholder {
      color: var(--clr-text-second);
    }

    .ant-input-textarea-show-count:after
    {
      color: var(--clr-text);
    }

    .ant-modal-wrap::-webkit-scrollbar {
      width: 0;
    }

    /* empty */
    .ant-empty-description {
      color: var(--clr-text);
    }

    /* pagination */
    .ant-pagination-item a {
      color: var(--clr-text);
    }

    .ant-pagination-item-active a {
      color: #1890ff !important;
    }

    .ant-pagination li
    {
      border-radius: var(--border-radius-element)!important;
      background-color: transparent!important;
      border-color: var(--border-active)!important;
      &.ant-pagination-disabled
      {
        opacity: 0.6;
      }
      button
      {
        border-radius: var(--border-radius-element)!important;
        background-color: transparent!important;
        border-color: var(--border-active)!important;
        opacity: 0.6;
        span svg
        {
          margin-top: 6px;
          margin-left: -1px;
          color: var(--border-active);
        }
      }
      &.ant-pagination-item-active
      {
        opacity: 1;
      }
      &.ant-pagination-options
      {
        .ant-select-selector
        {
          background-color: var(--background-side-bar-color)!important;
          transition: all 0.1s ease-in-out;
        }
        .ant-select-selection-item,
        .ant-select-arrow
        {
          color: var(--clr-text);
        }
      }
    }

    .ant-pagination-options-quick-jumper {
      color: var(--clr-text);
    }

    /* description */
    .ant-descriptions-item-label {
      color: var(--clr-text-second);
    }

    .ant-descriptions-title,
    .ant-descriptions-item-content {
      color: var(--clr-text);
    }

    /* tree select */
    .ant-select-tree {
      background-color: var(--background-color-element);
      color: var(--clr-text);
    }
    .ant-select-tree .ant-select-tree-node-content-wrapper:hover {
      background-color: var(--clr-background-menu-hover);
    }
    .ant-select,
    .ant-select-multiple .ant-select-selection-item-content {
      color: var(--clr-text);
    }

    .ant-select-multiple .ant-select-selection-item {
      background-color: #1890ff;
      border: #1890ff;
    }

    .ant-select-multiple .ant-select-selection-item-content,
    .ant-select-multiple .ant-select-selection-item-remove>.anticon {
      color: var(--clr-white);
    }

    .ant-tree .ant-tree-node-content-wrapper:hover {
      background-color: var(--clr-background-menu-hover);
    }

    .ant-input[disabled]
    {
      background-color: transparent!important;
    }
  }
`;

export const ElementWrapper = styled.div`
  height: 100%;
  min-height: 630px;
  padding: 1.5rem;
  border-radius: var(--border-radius-element);
  background-color: var(--background-color-element);
  box-shadow: var(--box-shadow-element-wrapper);
  transition: all ease-in-out 0.2s;
`;

export const SpinContainer = styled.div`
  display: flex;
  flex-direction: row;
  height: 100vh;
  width: 100vw;
  align-items: center;
  justify-content: center;
`;

export const WrapperCenter = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const SearchContainer = styled.div`
  width: 100%;
  max-width: 320px;
`;
