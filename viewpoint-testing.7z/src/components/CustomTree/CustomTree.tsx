import {
  ExclamationCircleOutlined,
  PlusCircleOutlined,
} from "@ant-design/icons";
import { DataTreeNode, ResponseDomain } from "@models/type";
import { domainActions } from "@redux/slices";
import DomainAPI from "@services/domainAPI";
import {
  convertTreeData,
  getListIdChildrenTreeNode,
} from "@utils/helpersUtils";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import { Button, Modal, Tree } from "antd";
import type { DataNode, EventDataNode } from "antd/es/tree";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import CustomTreeNode from "./CustomTreeNode/CustomTreeNode";
import { Wrapper } from "./CustomTreeStyle";

interface ITreeInfo {
  event: "select";
  selected: boolean;
  node: EventDataNode<DataNode>;
  selectedNodes: DataNode[];
  nativeEvent: MouseEvent;
}

interface IProps {
  searchValue: string;
  flattenedData: DataTreeNode[];
  onSetFlattenedData: (value: React.SetStateAction<DataTreeNode[]>) => void;
  dataTree: DataNode[];
  expandedKeys?: React.Key[];
  showLine?: boolean;
  autoExpandParent?: boolean;
  onSetDataTree: (data: DataNode[]) => void;
  callDeleteNodeApi?: (
    treeNodeId: React.Key[]
  ) => Promise<ResponseDomain | any>;
  onCreate: () => void;
  onAddChildNode: (
    node: DataTreeNode,
    newTitle: string
  ) => Promise<ResponseDomain | any>;
  onSelect?: (treeNodeId: React.Key[], info: ITreeInfo) => void;
  onExpand?: (expandedKeys: React.Key[]) => void;
  onUpdate?: (node: DataTreeNode, name: string) => void;
  onDrag?: (
    dragNode,
    dropNode,
    dropToGap,
    dropPosition
  ) => Promise<ResponseDomain | any>;
  onUpdateNameInDetailForm?: (content: string) => void;
  onResetDetailDomainForm?: () => void;
  nodeEditing: DataTreeNode;
  setNodeEditing: React.Dispatch<any>;
}

const CustomTree = ({
  searchValue,
  flattenedData,
  dataTree,
  onSetDataTree,
  nodeEditing,
  setNodeEditing,
  callDeleteNodeApi,
  onCreate,
  onAddChildNode,
  onSelect,
  onExpand,
  onUpdate,
  onDrag,
  onUpdateNameInDetailForm,
  onResetDetailDomainForm,
  expandedKeys,
  autoExpandParent,
  showLine,
  onSetFlattenedData,
}: IProps) => {
  const { t } = useTranslation(["common"]);
  const dispatch = useDispatch();

  const [isSelectable, setIsSelectable] = useState<boolean>(true);

  const onSetIsSelectable = (value) => {
    setIsSelectable(value);
  };
  const handleDropNode = async (info) => {
    try {
      const response: ResponseDomain = await onDrag(
        info.dragNode,
        info.node,
        info.dropToGap,
        info.dropPosition
      );
      if (response?.isSucceeded) {
        dispatch(domainActions.getDomain());
        showSuccessNotification(t("common:update_domain_succeed"));
      }
    } catch (error) {
      showErrorNotification(t("common:update_domain_failed"));
    }
  };

  const deleteNode = (key: React.Key, data) => {
    data.map((item, index) => {
      if (item.key === key) {
        if (data.length > 1 && index !== 0) {
          data[index - 1].next = data[index].next;
        }
        data.splice(index, 1);
        return;
      } else {
        if (item.children) {
          deleteNode(key, item.children);
        }
      }
    });
  };

  const saveNode = (
    key: React.Key,
    data: DataTreeNode[],
    content: string,
    newKey?: React.Key
  ) => {
    return data.map((item: DataTreeNode, index: number) => {
      if (item.key === key) {
        data.splice(index, 1, {
          ...item,
          title: content,
          key: newKey ?? key,
          prev: item.prev,
          next: item.next,
        } as DataTreeNode);
        data[index] = {
          ...item,
          title: content,
          key: newKey ?? key,
          prev: item.prev,
        };
        if (index !== 0) {
          data[index - 1].next = newKey ?? key;
        }
      }
      if (item.children) {
        saveNode(key, item.children, content, newKey);
      }
    });
  };

  const onAdd = (key: React.Key) => {
    const result = [...dataTree];
    addNode(key, result);
    onSetDataTree(result);
    const newExpandedKeys = [...expandedKeys];
    newExpandedKeys.push(key);
    onExpand(newExpandedKeys);
  };

  const addNode = (key: React.Key, data) => {
    data.map((item: DataTreeNode) => {
      if (item.key === key) {
        const randomKey = Math.random();
        const newNode: DataTreeNode = {
          title: "",
          key: randomKey,
          parentKey: key,
          description: "",
          isActive: true,
          index: 0,
          next: null,
        };
        if (!item.children || !item.children.length) {
          item.children = [];
          newNode.prev = null;
        } else {
          newNode.prev = item.children[item.children.length - 1].key;
          item.children[item.children.length - 1].next = randomKey;
        }
        item.children.push(newNode);
        setNodeEditing(newNode);
        return;
      }
      if (item.children) {
        addNode(key, item.children);
      }
    });
    return data;
  };

  const handleShowDeleteModal = (key: React.Key) => {
    Modal.confirm({
      title: t("common:domain_modal_delete"),
      icon: <ExclamationCircleOutlined />,
      content: t("common:domain_modal_delete_content"),
      okText: t("common:domain_delete"),
      cancelText: t("common:domain_cancel"),
      onOk: async () => {
        const listKey = [];
        const result = [...dataTree];
        if (nodeEditing) {
          deleteNode(nodeEditing?.key, result);
        }
        try {
          const listKeyChildrenTreeNode = getListIdChildrenTreeNode(
            listKey,
            result,
            key
          );
          const response: ResponseDomain = await callDeleteNodeApi(
            listKeyChildrenTreeNode
          );
          if (response.isSucceeded) {
            deleteNode(key, result);
            onSetFlattenedData(
              flattenedData.filter((item) => {
                return !listKeyChildrenTreeNode.includes(item.key);
              })
            );
            onResetDetailDomainForm();
            showSuccessNotification(t("common:delete_domain_succeed"));
          }
        } catch (error) {
          showErrorNotification(t("common:delete_domain_failed"));
        } finally {
          onSetDataTree(result);
          setNodeEditing(null);
        }
      },
    });
  };

  return (
    <Wrapper>
      <Tree
        className="draggable-tree"
        draggable
        blockNode
        selectable={isSelectable}
        expandedKeys={expandedKeys}
        autoExpandParent={autoExpandParent}
        showLine={showLine}
        onExpand={onExpand}
        onSelect={onSelect}
        onDrop={handleDropNode}
        treeData={dataTree}
        titleRender={(node) => (
          <CustomTreeNode
            searchValue={searchValue}
            data={dataTree}
            onSetDataTree={onSetDataTree}
            flattenedData={flattenedData}
            onSetFlattenedData={onSetFlattenedData}
            node={node}
            onDelete={deleteNode}
            onUpdate={onUpdate}
            onSave={saveNode}
            onAdd={onAdd}
            onSetIsSelectable={onSetIsSelectable}
            nodeEditing={nodeEditing}
            setNodeEditing={setNodeEditing}
            callAddChildNodeApi={onAddChildNode}
            onShowDeleteNodeModal={handleShowDeleteModal}
            onUpdateNameInDetailForm={onUpdateNameInDetailForm}
          />
        )}
      />
      <Button
        icon={<PlusCircleOutlined />}
        onClick={onCreate}
        style={{
          marginTop: "0.5rem",
          marginLeft: "0.5rem",
        }}
      >
        {t("common:domain_add")}
      </Button>
    </Wrapper>
  );
};

export default CustomTree;
