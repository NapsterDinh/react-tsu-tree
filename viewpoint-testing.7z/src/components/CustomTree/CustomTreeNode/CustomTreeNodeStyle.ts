import styled from "styled-components";

export const Wrapper = styled.div`
  &&& {
    input {
      border: 1px solid #d9d9d9;
      outline: none;
      background-color: transparent;
      padding-top: 0px;
      padding-bottom: 0px;
      box-shadow: none;
    }
    .custom-tree-node {
      position: relative;
      display: flex;
      justify-content: flex-start;
      align-items: center;

      .custom-tree-node__title {
        font-weight: 500;
      }
      .option-tree-node {
        display: none;
        z-index: 99;
      }
      &:hover {
        .option-tree-node {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          margin-left: 1rem;

          .option-tree-node-btn {
            height: 100%;
            width: auto;

            &.add {
              color: #52c41a;
            }

            &.edit {
              color: #1890ff;
            }
            &.delete {
              color: #ff4d4f;
            }
          }
          svg {
            font-size: 1rem;
            transform: translateY(3px);
          }
        }
      }
    }
  }
`;
