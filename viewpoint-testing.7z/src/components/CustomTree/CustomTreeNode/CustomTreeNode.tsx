import { generateList, removeEmoji } from "@utils/helpersUtils";
import { Tooltip, Input, Space, Button, Tag } from "antd";
import { useState, useEffect, useMemo } from "react";
import { useTranslation } from "react-i18next";
import {
  AiOutlinePlusCircle,
  AiOutlineDelete,
  AiOutlineEdit,
} from "react-icons/ai";
import { Wrapper } from "./CustomTreeNodeStyle";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { DataTreeNode, ResponseDomain } from "@models/type";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import { JsonDetail } from "@models/model";

const CustomTreeNode = ({
  data,
  searchValue,
  flattenedData,
  node,
  onDelete,
  onSave,
  onAdd,
  nodeEditing,
  setNodeEditing,
  onSetIsSelectable,
  onUpdate,
  onSetDataTree,
  callAddChildNodeApi,
  onSetFlattenedData,
  onShowDeleteNodeModal,
  onUpdateNameInDetailForm,
}) => {
  const { t } = useTranslation(["common", "validate"]); // languages
  const [isShowInput, setIsShowInput] = useState(
    typeof node?.key === "number" ? true : false
  ); // show input to add child or edit
  const [content, setContent] = useState(node?.title); // content input
  const [contentSearch, setContentSearch] = useState(node?.titleSearch); // content show when search value has value
  const [isChangedInput, setIsChangedInput] = useState(true); // check content has been changed
  const [error, setError] = useState(""); // validate input

  // change input
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setContent(value);
    handleCheckErrors(value);

    // check the input content changes compared to the original
    if (value === node?.title) {
      setIsChangedInput(true);
    } else {
      setIsChangedInput(false);
    }
  };

  // validate input
  const handleCheckErrors = (contentInput: string) => {
    // check the input content is empty
    if (!contentInput.trim()) {
      setError(t("validate:edit_input_tree"));
      return;
    }
    // check the input content contains special character
    if (
      checkContainsSpecialCharacter(contentInput.trim()) ||
      removeEmoji(contentInput)
    ) {
      setError(t("validate:edit_input_tree_contains_special_character"));
      return;
    }
    // check if the input content is the same as other
    if (
      flattenedData
        .filter((item: DataTreeNode) => item.key !== node.key)
        .some(
          (item: DataTreeNode) =>
            item.title.toLowerCase() === contentInput.toLowerCase()
        )
    ) {
      setError(t("validate:edit_input_tree_same_name"));
      return;
    }
    setError("");
  };

  // cancel input editing
  const handleCancel = (e: React.MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    // check if current node is mock node
    if (nodeEditing && typeof nodeEditing.key === "number") {
      const result = [...data];
      onDelete(node?.key, result); //delete mock node
      onSetDataTree(result);
    } else {
      // current node is not mock node
      setIsShowInput(false); // show input
      setContent(node.title); // set content input to original value
    }
    setNodeEditing(null); // set mock node to null
    onSetIsSelectable(true); // set value allows to select another node in the tree
    setError(""); // set empty error
  };

  // double click content to show input
  const handleOnClick = (e: any) => {
    e.preventDefault();
    if (e.detail === 2) {
      setIsShowInput(true); // show input
    }
    setError(""); // set empty error
  };

  // set keyboard shortcut event
  const handleOnKeyDown = (e: any) => {
    // keyboard Enter
    if (e.key === "Enter") {
      handleSaveDataNode(e); // save updated node
    }
    // keyboard Escape
    if (e.keyCode === 27) {
      handleCancel(e); // cancel input
    }
  };

  // save node
  const handleSaveDataNode = async (e: any) => {
    e.stopPropagation();
    if (!error) {
      // check the input content has changed or not error
      if (!isChangedInput && !error) {
        // update title of node
        if (typeof node?.key === "string") {
          const result = [...data];
          try {
            const reponse: ResponseDomain = await onUpdate(node, content);
            if (reponse?.isSucceeded) {
              onSave(node.key, result, content);
              onSetDataTree(result);
              const newFlattenedData = flattenedData.map((item) => {
                if (item.key === node.key) return { ...node, title: content };
                return item;
              });
              onSetFlattenedData(newFlattenedData);
              onUpdateNameInDetailForm(content);
              showSuccessNotification(t("common:update_domain_succeed"));
            }
          } catch (error) {
            setContent(node.title);
            showErrorNotification(t("common:update_domain_failed"));
          } finally {
            setIsShowInput(false); // close input
            setIsChangedInput(true); // set check changed input to true
            onSetIsSelectable(true); // set value allows to select nodes on the tree
            setNodeEditing(null);
          }
        }
        // update id and title of mock node
        else {
          const result = [...data];
          try {
            const response: ResponseDomain = await callAddChildNodeApi(
              node,
              content
            );
            if (response.isSucceeded) {
              const detail: JsonDetail = JSON.parse(
                response.data.detail as string
              );
              onSave(node.key, result, content, response.data.id);
              node.title = detail.Name;
              node.key = response.data.id;
              onSetDataTree(result);
              const newFlattenedData = flattenedData.map((item) => {
                if (item.key === node.key)
                  return { ...node, title: content, key: response.data.id };
                return item;
              });
              onSetFlattenedData(newFlattenedData);
              onAdd(node.parentKey);
              showSuccessNotification(t("common:create_domain_succeed"));
            }
          } catch (error) {
            onDelete(node.key, result);
            onSetDataTree(result);
            showErrorNotification("Error");
          } finally {
            setIsShowInput(false); // close input
            setIsChangedInput(true); // set check changed input to true
            onSetIsSelectable(true); // set value allows to select nodes on the tree
          }
        }
        // check search value has value
        if (searchValue) {
          handleChangeTitle(content); // change the content of titleSearch in data
        } else {
          setContentSearch(null); // set empty content search
        }
      }
      setError(""); // set empty error
    }
  };

  // handle change title in data of node
  const handleChangeTitle = (newContent: string) => {
    const strTitle = newContent.toLowerCase();
    const indexTitle = strTitle.indexOf(searchValue.toLowerCase());
    const beforeStr = newContent.substring(0, indexTitle);
    const afterStr = newContent.substring(indexTitle + searchValue.length);
    const newTitle = indexTitle > -1 && (
      <span>
        {beforeStr}
        <span className="site-tree-search-value">
          {newContent.substring(indexTitle, indexTitle + searchValue.length)}
        </span>
        {afterStr}
      </span>
    );
    setContentSearch(newTitle); // set new content with search value
  };

  // count number element of node
  const handleCountNumberChildTreeNode = useMemo(() => {
    const flattenedDataNode = [];
    generateList(node.children, flattenedDataNode);
    return flattenedDataNode.length;
  }, [data, node, node.children]);

  // set content show when search value changed
  useEffect(() => {
    if (searchValue) {
      handleChangeTitle(content);
    } else {
      setContentSearch(null);
    }
  }, [searchValue]);

  // render
  if (isShowInput && nodeEditing?.key === node.key) {
    return (
      <Wrapper>
        <Space
          style={{
            width: "100%",
            justifyContent: "space-between",
          }}
        >
          <Tooltip title={error} visible={error ? true : false} color="#ff4d4f">
            <Input
              autoFocus
              status={error ? "error" : ""}
              onKeyDown={handleOnKeyDown}
              value={content}
              onChange={handleInputChange}
              width={100}
            />
          </Tooltip>
          <Space>
            <Button
              disabled={isChangedInput}
              type="primary"
              size="small"
              onClick={(e) => {
                if (!error) {
                  handleSaveDataNode(e);
                }
              }}
            >
              {t("common:save")} [Enter]
            </Button>
            <Button size="small" onClick={handleCancel}>
              {t("common:cancel")} [ESC]
            </Button>
          </Space>
        </Space>
      </Wrapper>
    );
  } else {
    return (
      <Wrapper>
        <div className="custom-tree-node">
          <Space direction="horizontal">
            <div onClick={handleOnClick} className="custom-tree-node__title">
              {contentSearch && contentSearch !== 0 ? contentSearch : content}
            </div>
            {node.children && handleCountNumberChildTreeNode !== 0 && (
              <Tag color="#87d068" style={{ fontSize: "0.75rem" }}>
                {handleCountNumberChildTreeNode}
              </Tag>
            )}
          </Space>
          <div className="option-tree-node">
            <div className="option-tree-node-btn add">
              <AiOutlinePlusCircle
                onClick={(e) => {
                  e.stopPropagation();
                  const result = [...data];
                  onDelete(nodeEditing?.key, result);
                  onSetDataTree(result);
                  onAdd(node.key);
                }}
              />
            </div>
            <div className="option-tree-node-btn edit">
              <AiOutlineEdit
                onClick={(e) => {
                  e.stopPropagation();
                  setIsShowInput(true);
                  onSetIsSelectable(false);
                  if (nodeEditing && typeof nodeEditing.key === "number") {
                    const result = [...data];
                    onDelete(nodeEditing?.key, result);
                    onSetDataTree(result);
                  }
                  setNodeEditing(node);
                }}
              />
            </div>
            <div className="option-tree-node-btn delete">
              <AiOutlineDelete
                onClick={(e) => {
                  e.stopPropagation();
                  onShowDeleteNodeModal(node.key);
                }}
              />
            </div>
          </div>
        </div>
      </Wrapper>
    );
  }
};

export default CustomTreeNode;
