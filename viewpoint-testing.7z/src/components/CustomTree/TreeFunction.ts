// import { Key } from "react";
// import { DataNode } from "antd/lib/tree";

// const loopDragDrop = (
//   data: DataNode[],
//   key: React.Key,
//   callback: (dataNode: DataNode, index: number, data: DataNode[]) => void
// ) => {
//   for (let i = 0; i < data.length; i++) {
//     if (data[i].key === key) {
//       return callback(data[i], i, data);
//     }
//     if (data[i].children) {
//       loopDragDrop(data[i].children, key, callback);
//     }
//   }
// };

// // drag/drop node
// const dropNode = (
//   info:
//     | {
//         dragNode: any;
//         dragNodesKeys: Key[];
//         dropPosition: number;
//         dropToGap: boolean;
//       }
//     | any,
//   dataTree: DataNode[]
// ) => {
//   const dropKey = info.node.key;
//   const dragKey = info.dragNode.key;
//   const dropPos = info.node.pos.split("-");
//   const dropToGap = info.dropToGap;
//   const dropPosition = info.dropPosition - Number(dropPos[dropPos.length - 1]);
//   const data = [...dataTree];
//   let dragObj: DataNode;
//   loopDragDrop(data, dragKey, (item, index, dataNode) => {
//     dataNode.splice(index, 1);
//     dragObj = item;
//   });

//   if (!info.dropToGap) {
//     // Drop on the content
//     loopDragDrop(data, dropKey, (item) => {
//       item.children = item.children || [];

//       item.children.unshift({
//         ...dragObj,
//         parentKey: dropKey,
//       });
//     });
//   } else if (
//     (info.node.props.children || []).length > 0 &&
//     info.node.props.expanded &&
//     dropPosition === 1
//   ) {
//     loopDragDrop(data, dropKey, (item) => {
//       item.children = item.children || [];
//       for (let index = 0; index < item.children.length; index++) {
//         const element = item.children[index];
//         if (element?.parentKey !== dragObj?.parentKey) {
//           dragObj.parentKey = element?.parentKey;
//           break;
//         }
//       }

//       item.children.unshift(dragObj);
//     });
//   } else {
//     let ar = [];
//     let i;
//     loopDragDrop(data, dropKey, (_item, index, arr) => {
//       ar = arr;
//       i = index;
//     });
//     for (let index = 0; index < ar.length; index++) {
//       const element = ar[index];
//       if (element?.parentKey !== dragObj?.parentKey) {
//         dragObj.parentKey = element?.parentKey;
//         break;
//       }
//     }
//     if (dropPosition === -1) {
//       ar.splice(i, 0, dragObj);
//     } else {
//       ar.splice(i + 1, 0, dragObj);
//     }
//   }
// };

// export { dropNode };
