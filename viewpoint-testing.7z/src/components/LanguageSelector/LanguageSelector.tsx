import ENFlag from "@assets/images/en.png";
import JPNFlag from "@assets/images/jpn.png";
import VIFlag from "@assets/images/vi.png";
import React from "react";
import { StyledSelect } from "./LanguageSelectorStyle";

const languages = [
  {
    key: "vi",
    value: "VietNam",
    flag: VIFlag,
  },
  {
    key: "en",
    value: "English",
    flag: ENFlag,
  },
  {
    key: "jpn",
    value: "Japan",
    flag: JPNFlag,
  },
];

const LanguageSelector: React.FC = () => {
  const handleChangeLanguages = (value) => {
    const selectedLanguage = languages.find((item) => item.value === value);
    window.location.reload();
    localStorage.setItem("i18nextLng", selectedLanguage.key);
    // i18n.changeLanguage(value); need reload to call API get new data for new language, so comment this line
  };

  const getFlag = () => {
    const target = localStorage.getItem("i18nextLng") ?? "en";
    return languages.find((item) => item.key === target).flag;
  };

  const getValuesLanguage = () => {
    switch (localStorage.getItem("i18nextLng")) {
      case "vi":
        return "VietNam";
      case "jpn":
        return "Japan";
      case "en":
        return "English";

      default:
        return "English";
    }
  };

  return (
    <StyledSelect
      suffixIcon={<img src={getFlag()}></img>}
      defaultValue={getValuesLanguage()}
      onChange={handleChangeLanguages}
      options={languages}
      dropdownMatchSelectWidth={false}
    />
  );
};

export default LanguageSelector;
