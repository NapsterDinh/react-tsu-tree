import { LogoBlack, LogoWhite } from "@assets/svg";
import DarkMode from "@components/DarkMode/DarkMode";
import LanguageSelector from "@components/LanguageSelector/LanguageSelector";
import { rootState } from "@models/type";
import { Space } from "antd";
import React from "react";
import { useSelector } from "react-redux";
import { Outlet } from "react-router-dom";
import {
  AuthContent,
  AuthHeader,
  StyledAuthLayout,
  WrapperContent,
  WrapperHeader,
} from "./LayoutAuthStyle";

const LayoutAuth: React.FC = () => {
  const { theme } = useSelector((state: rootState) => state.theme);

  return (
    <StyledAuthLayout>
      <AuthHeader>
        <WrapperHeader>
          {theme === "dark" ? (
            <LogoWhite style={{ width: "80px", height: "80px" }} />
          ) : (
            <LogoBlack style={{ width: "80px", height: "80px" }} />
          )}
          <Space>
            <LanguageSelector />
            <DarkMode />
          </Space>
        </WrapperHeader>
      </AuthHeader>
      <AuthContent>
        <WrapperContent>
          <Outlet />
        </WrapperContent>
      </AuthContent>
    </StyledAuthLayout>
  );
};

export default LayoutAuth;
