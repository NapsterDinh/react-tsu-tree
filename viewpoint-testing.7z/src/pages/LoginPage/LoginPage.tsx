import logoBlackText from "@assets/svg/logo-black.svg";
import logoWhiteText from "@assets/svg/logo-white.svg";
import thumbnailImage from "@assets/svg/thumbnail_login.svg";
import { rootState } from "@models/type";
import { authActions } from "@redux/slices";

import {
  Button,
  Col,
  Form,
  Input,
  message,
  Row,
  Space,
  Typography,
} from "antd";
import React from "react";
import { useTranslation } from "react-i18next";
import { AiOutlineLock, AiOutlineUser } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import {
  FormLogin,
  Logo,
  ThumbnailLogin,
  WrapperLogin,
} from "./LoginPageStyled";

import { checkContainsSpecialCharacter } from "@utils/helpersUtils";

const { Title, Text } = Typography;

import { useNavigate } from "react-router-dom";

const LoginPage: React.FC = (): JSX.Element => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { loginLoading, errorLogin } = useSelector(
    (state: rootState) => state.auth
  );
  const { theme } = useSelector((state: rootState) => state.theme);
  const [form] = Form.useForm<{
    username: string;
    password: string;
    remember: boolean;
  }>();
  const { t } = useTranslation(["common", "validate", "responseMessage"]);

  // function handle login
  const onFinishLogin = (values) => {
    try {
      dispatch(
        authActions.login({
          username: values.username.trim(),
          password: values.password.trim(),
          onSuccess: () => {
            dispatch(
              authActions.getCurrentUser({
                onSuccess: () => navigate("/", { replace: true }),
              })
            );
          },
        })
      );
    } catch (error) {}
  };

  // function handle failed login
  const onFinishFailed = (errorInfo: any) => {
    message.error(errorInfo);
  };

  return (
    <WrapperLogin>
      <Row gutter={8}>
        <Col xs={0} md={12}>
          <ThumbnailLogin src={thumbnailImage} />
        </Col>
        <Col xs={24} md={12}>
          <FormLogin>
            <Space align="center" size={0}>
              <Logo src={theme === "dark" ? logoWhiteText : logoBlackText} />
              <Title level={2}>{t("common:login")}</Title>
              <Text type="secondary">
                {t("common:sign_in_internal_platform")}
              </Text>
            </Space>
            <Form
              form={form}
              onFinish={onFinishLogin}
              onFinishFailed={onFinishFailed}
              layout="vertical"
              autoComplete="off"
            >
              <Form.Item
                name="username"
                label={t("common:username")}
                rules={[
                  { required: true, message: t("validate:username_required") },
                  {
                    validator: (_, value) => {
                      if (checkContainsSpecialCharacter(value)) {
                        return Promise.reject(
                          t(
                            "validate:edit_input_tree_contains_special_character"
                          )
                        );
                      } else {
                        return Promise.resolve();
                      }
                    },
                  },
                ]}
                validateTrigger={["onBlur", "onChange"]}
              >
                <Input
                  maxLength={16}
                  prefix={<AiOutlineUser className="site-form-item-icon" />}
                  placeholder={t("common:enter_user")}
                  size="large"
                />
              </Form.Item>
              {errorLogin !== "" && (
                <p
                  style={{ marginBottom: "0px", marginTop: "-20px" }}
                  className="color-red"
                >
                  {t(`responseMessage:${errorLogin}`)}
                </p>
              )}
              <Form.Item
                name="password"
                label={t("common:password")}
                rules={[
                  { required: true, message: t("validate:password_required") },
                ]}
                validateTrigger={["onBlur", "onChange"]}
              >
                <Input.Password
                  maxLength={20}
                  prefix={<AiOutlineLock className="site-form-item-icon" />}
                  placeholder={t("common:enter_password")}
                  size="large"
                />
              </Form.Item>
              <Button
                style={{ marginTop: "20px" }}
                type="primary"
                htmlType="submit"
                size="large"
                loading={loginLoading}
              >
                {t("common:login")}
              </Button>
            </Form>
          </FormLogin>
        </Col>
      </Row>
    </WrapperLogin>
  );
};

export default LoginPage;
