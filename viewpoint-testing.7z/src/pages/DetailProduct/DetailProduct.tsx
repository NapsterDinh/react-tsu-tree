import { HomeOutlined } from "@ant-design/icons";
import { rootState } from "@models/type";
import productAPI from "@services/productAPI";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import { STATUS_VIEWPOINT_COLLECTION, TYPE_TREE_NODE } from "@utils/constants";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import { Breadcrumb, Col, Empty, Row, Space, Spin, Switch, Tag } from "antd";
import { ElementWrapper } from "AppStyled";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate, useParams } from "react-router-dom";
import { routes } from "routes";
import { CommonAction, ViewpointTree } from "./components";
import DetailViewpointForm from "./components/DetailProductForm/DetailProductForm";
import { Wrapper } from "./DetailProductStyle";

const DetailProduct = () => {
  const [currentProduct, setCurrentProduct] = useState(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [visibleInfo, setVisibleInfo] = useState(false); // show info modal
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation(["common", "validate"]); // languages
  const [dataTree, setDataTree] = useState([]);
  const user = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : null;

  const onShowInfoModal = () => {
    setVisibleInfo(true);
  };

  const onCloseInfoModal = () => {
    setVisibleInfo(false);
  };

  const dispatch = useDispatch();
  const { currentViewpointCollection, loadingGetById } = useSelector(
    (state: rootState) => state.viewpoint
  );

  const onChangeSelectLevel = (values) => {
    // //-1: show full
    // const updatedData = [];
    // const clonedData = [...data];
    // if (values == -1) {
    //   expandedKeysWithLevel(clonedData, Infinity, updatedData);
    // } else {
    //   expandedKeysWithLevel(clonedData, values, updatedData);
    // }
    // setExpandedKeys(updatedData);
  };

  const handleGetViewpointCollection = async () => {
    try {
      if (id) {
        const response = await productAPI.getProductById(id);
        const keys = ["domainId", "groupFunctionId", "id"],
          temp = { children: [] };
        response?.data?.functions.forEach(function (a) {
          return keys.reduce(function (r, k) {
            if (!r[a[k]]) {
              r[a[k]] = { children: [] };
              r.children.push({
                ["key"]:
                  k === "domainId"
                    ? a[k]
                    : k === "groupFunctionId"
                    ? a.domainId + "-" + a[k]
                    : a.domainId + "-" + a.groupFunctionId + "-" + a[k],
                ["children"]: r[a[k]].children,
                // content: a,
                item: a,
                title:
                  k === "domainId"
                    ? JSON.parse(a?.domain?.detail)?.Name
                    : k === "groupFunctionId"
                    ? JSON.parse(a?.groupFunction?.detail)?.Name
                    : JSON.parse(a?.detail)?.Name,
                type:
                  k === "domainId"
                    ? TYPE_TREE_NODE.DOMAIN
                    : k === "groupFunctionId"
                    ? TYPE_TREE_NODE.GROUP_FUNCTION
                    : TYPE_TREE_NODE.FUNCTION,
              });
            }
            return r[a[k]];
          }, temp);
        });
        setDataTree(temp.children);
        setCurrentProduct(response?.data);
      }
    } catch (error) {
      console.log(error);

      if (error?.code !== "IdInvalid") {
        if (error?.response?.status === 400) {
          if (!error?.response?.data?.errors?.[0]?.code) {
            showErrorNotification(t("responseMessage:IdInvalid"));
          } else {
            showErrorNotification(t(`responseMessage:${error?.code}`));
          }
          navigate("/not-found", {
            state: {
              from: {
                pathname: routes.ViewpointCollection.path[0],
              },
            },
          });
        } else {
          showErrorNotification(t(`responseMessage:${error?.code}`));
        }
      } else {
        showErrorNotification(t(`responseMessage:${error?.code}`));
        navigate("/not-found", {
          state: {
            from: {
              pathname: routes.ViewpointCollection.path[0],
            },
          },
        });
      }
    }
  };

  const handleDeleteDomain = (domainId) => {
    return;
  };
  const handleDeleteCategory = (categoryId) => {
    return;
  };
  const handleDeleteTestType = (categoryId) => {
    return;
  };
  const handleDeleteViewpoint = (viewpointId) => {
    return;
  };

  // call domain's action
  useEffect(() => {
    (async () => {
      await handleGetViewpointCollection();
    })();
  }, []);

  const handleOnSelectNode = (e) => {
    setSelectedNode(e?.node);
  };

  const handleChangeStatus = async (checked) => {
    try {
      await viewpointCollectionAPI.updateStatus(
        currentProduct?.id,
        checked
          ? STATUS_VIEWPOINT_COLLECTION.PUBlISH
          : STATUS_VIEWPOINT_COLLECTION.PRIVATE,
        checked
          ? STATUS_VIEWPOINT_COLLECTION.PUBlISH
          : STATUS_VIEWPOINT_COLLECTION.PRIVATE
      );
      setCurrentProduct({
        ...currentProduct,
        status: checked
          ? STATUS_VIEWPOINT_COLLECTION.PUBlISH
          : STATUS_VIEWPOINT_COLLECTION.PRIVATE,
      });
      showSuccessNotification(t("common:change_is_active_success"));
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error?.code}`));
    } finally {
    }
  };

  return (
    <Wrapper>
      <Breadcrumb>
        <Breadcrumb.Item>
          <Link to={"/"}>
            <HomeOutlined />
          </Link>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <Link
            to={routes.ProductManagement.path[0]}
            style={{ color: "var(--clr-text)" }}
          >
            {t("common:product_management")}
          </Link>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          {/* {t("common:viewpoint_collection_detail")} */}
          {currentProduct?.detail?.name}
        </Breadcrumb.Item>
      </Breadcrumb>
      <CommonAction
        currentProduct={currentProduct}
        getData={handleGetViewpointCollection}
        setCurrentProduct={setCurrentProduct}
      />
      <Space
        align="center"
        style={{
          display: "flex",
          justifyContent: "space-between",
          margin: "1rem 0 0.5rem",
        }}
      >
        <Space>
          {t("common:type")}
          <Space size={0}>
            <Tag color="#73d13d">{t("common:domain")}</Tag>
            <Tag color="#faad14">{t("common:group_function")}</Tag>
            <Tag color="#9254de">{t("common:function")}</Tag>
          </Space>
        </Space>
        {currentProduct?.status !== STATUS_VIEWPOINT_COLLECTION.ON_GOING &&
          user?.id === currentProduct?.user?.id && (
            <Space>
              <span className="label">{t("common:private")}</span>
              <Switch
                key={"switchStatus"}
                checked={
                  currentProduct?.status === STATUS_VIEWPOINT_COLLECTION.PUBlISH
                }
                onChange={(checked) => handleChangeStatus(checked)}
              />
              <span className="label">{t("common:publish")}</span>
            </Space>
          )}
      </Space>
      <Row gutter={8}>
        <Col xs={16}>
          <ElementWrapper>
            <div className="detail-viewpoint-collection-tree">
              {false ? (
                <Space
                  align="center"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  <Spin tip={t("common:loading")} />
                </Space>
              ) : dataTree.length ? (
                <ViewpointTree
                  dataTree={dataTree}
                  setDataTree={setDataTree}
                  onCallDeleteDomainApi={handleDeleteDomain}
                  onCallDeleteTestTypeApi={handleDeleteTestType}
                  onCallDeleteCategoryApi={handleDeleteCategory}
                  onCallDeleteViewpointApi={handleDeleteViewpoint}
                  handleOnSelectNode={handleOnSelectNode}
                />
              ) : (
                <div className="detail-viewpoint-collection-empty">
                  <Empty
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    description={<span>{t("common:no_data")}</span>}
                  />
                </div>
              )}
            </div>
          </ElementWrapper>
        </Col>
        <Col xs={8}>
          <DetailViewpointForm data={selectedNode} setData={setSelectedNode} />
        </Col>
      </Row>
    </Wrapper>
  );
};

export default DetailProduct;
