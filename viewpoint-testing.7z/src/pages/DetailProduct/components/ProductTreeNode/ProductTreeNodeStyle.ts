import styled from "styled-components";

export const Wrapper = styled.div`
  &&& {
    display: flex;
    align-items: center;
    padding: 0.25rem 0;

    &:hover .custom-tree-node__action {
      display: flex;
    }

    .custom-tree-node {
      position: relative;
    }

    .custom-tree-node__action {
      position: absolute;
      right: 1rem;
      top: 0;
      bottom: 0;
      display: none;
      justify-content: space-between;
      gap: 0.75rem;

      .option-tree-node-btn {
        cursor: pointer;

        &.add {
          color: #52c41a;
        }

        &.edit {
          color: #1890ff;
        }
        &.delete {
          color: #ff4d4f;
        }
      }

      .option-tree-node-btn svg {
        font-size: 1.25rem;
        transform: translateY(30%);
      }
    }

    .tag {
      width: 1rem;
      min-width: 1rem;
      height: 0.5rem;
      border-radius: 0.25rem;
      margin-right: 0.25rem;
    }
    .tag.domain {
      background-color: #73d13d;
    }

    .tag.group-function {
      background-color: #faad14;
    }

    .tag.function {
      background-color: #9254de;
    }
  }
`;
