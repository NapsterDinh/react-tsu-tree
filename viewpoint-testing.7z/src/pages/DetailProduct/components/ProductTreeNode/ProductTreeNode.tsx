import { Modal } from "antd";
import {
  AiOutlineDelete,
  AiOutlineEdit,
  AiOutlinePlusCircle,
} from "react-icons/ai";
import { Wrapper } from "./ProductTreeNodeStyle";
// interface IProps {
//   //   type?:
//   //     | "domain"
//   //     | "category"
//   //     | "test_type"
//   //     | "viewpoint"
//   //     | "sample"
//   //     | "example"
//   //     | "confirmation";
//   //   title: string;
//   //   key: string;
// //   node: DataNode;
// }
const ProductTreeNode = ({ node, onDelete }) => {
  const handleShowDeleteConfirm = () => {
    Modal.warning({
      title: "Delete",
      content: "Are you sure to delete this node?",
      cancelText: "Cancel",
      okText: "Delete",
      onOk: () => onDelete(node),
    });
  };
  return (
    <Wrapper>
      <div className={`tag ${node.type}`}></div>
      <div className={`custom-tree-node ${node?.type}`}>{node?.title}</div>
      <div className="custom-tree-node__action">
        {node?.type === "viewpoint" && (
          <div className="option-tree-node-btn add">
            <AiOutlinePlusCircle
              onClick={(e) => {
                e.stopPropagation();
              }}
            />
          </div>
        )}
        {node?.type === "viewpoint" && (
          <div className="option-tree-node-btn edit">
            <AiOutlineEdit
              onClick={(e) => {
                e.stopPropagation();
              }}
            />
          </div>
        )}
        <div className="option-tree-node-btn delete">
          <AiOutlineDelete
            onClick={(e) => {
              e.stopPropagation();
              handleShowDeleteConfirm();
            }}
          />
        </div>
      </div>
    </Wrapper>
  );
};

export default ProductTreeNode;
