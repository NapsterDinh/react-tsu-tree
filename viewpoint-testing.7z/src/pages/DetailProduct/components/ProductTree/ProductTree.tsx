import { showErrorNotification } from "@utils/notificationUtils";
import { Tree } from "antd";
import React from "react";
import ProductTreeNode from "../ProductTreeNode/ProductTreeNode";
import { Wrapper } from "./ProductTree.Style";

const ProductTree = ({
  dataTree,
  setDataTree,
  onCallDeleteDomainApi,
  onCallDeleteTestTypeApi,
  onCallDeleteCategoryApi,
  onCallDeleteViewpointApi,
  handleOnSelectNode,
}) => {
  const handleDropNode = (info) => {
    const typeDragNode = info.dragNode.type;
    const typeDropNode = info.node.type;
    if (typeDragNode === typeDropNode) {
      const dropKey = info.node.key;
      const dragKey = info.dragNode.key;
      const dropPos = info.node.pos.split("-");
      const dropPosition =
        info.dropPosition - Number(dropPos[dropPos.length - 1]);

      const loop = (data, key: React.Key, callback) => {
        for (let i = 0; i < data.length; i++) {
          if (data[i].key === key) {
            return callback(data[i], i, data);
          }

          if (data[i].children) {
            loop(data[i].children, key, callback);
          }
        }
      };
      const data = [...dataTree]; // Find dragObject
      let dragObj;
      loop(data, dragKey, (item, index, arr) => {
        arr.splice(index, 1);
        dragObj = item;
      });

      if (!info.dropToGap) {
        // Drop on the content
        loop(data, dropKey, (item) => {
          item.children = item.children || [];

          item.children.unshift({
            ...dragObj,
            parentKey: dropKey,
          });
        });
      } else if (
        (info.node.props.children || []).length > 0 &&
        info.node.props.expanded &&
        dropPosition === 1
      ) {
        loop(data, dropKey, (item) => {
          item.children = item.children || [];
          for (let index = 0; index < item.children.length; index++) {
            const element = item.children[index];
            if (element?.parentKey !== dragObj?.parentKey) {
              dragObj.parentKey = element?.parentKey;
              break;
            }
          }

          item.children.unshift(dragObj);
        });
      } else {
        let ar = [];
        let i;
        loop(data, dropKey, (_item, index, arr) => {
          ar = arr;
          i = index;
        });
        for (let index = 0; index < ar.length; index++) {
          const element = ar[index];
          if (element?.parentKey !== dragObj?.parentKey) {
            dragObj.parentKey = element?.parentKey;
            break;
          }
        }
        if (dropPosition === -1) {
          ar.splice(i, 0, dragObj);
        } else {
          ar.splice(i + 1, 0, dragObj);
        }
      }
      setDataTree(data);
    } else {
      showErrorNotification("Can not drag this node");
    }
  };

  const onDelete = async (node) => {
    const result = [...dataTree];
    let response;
    switch (node?.key) {
      case "domain":
        response = onCallDeleteDomainApi();
        break;
      case "category":
        break;
      case "test-type":
        break;
      default:
    }
    // delete domain node
    if (response?.isSucceeded) {
      deleteNode(node.key, result);
      setDataTree(result);
    } else {
      showErrorNotification("Delete Failed");
    }
  };

  const deleteNode = (key, data) =>
    data.map((item, index) => {
      if (item.key === key) {
        data.splice(index, 1);
        return;
      } else {
        if (item.children) {
          deleteNode(key, item.children);
        }
      }
    });

  return (
    <Wrapper>
      <Tree
        showIcon
        defaultExpandAll
        blockNode
        draggable
        onSelect={(selectedKeys, e) => handleOnSelectNode(e)}
        treeData={dataTree}
        onDrop={handleDropNode}
        titleRender={(node) => {
          return <ProductTreeNode node={node} onDelete={onDelete} />;
        }}
      />
    </Wrapper>
  );
};

export default ProductTree;
