import { TYPE_TREE_NODE } from "@utils/constants";
import {
  Button,
  Descriptions,
  Empty,
  Form,
  Input,
  Space,
  Tag,
  Typography,
} from "antd";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Wrapper } from "./DetailProductForm.Styled";
const { Title } = Typography;

interface IDomainParams {
  name: string;
  description: string;
  isActive: boolean;
  parentId: React.Key;
}

interface IProps {
  onChange?: (e) => void;
  data: any;
  setData: (any) => void;
}

const DetailProductForm = ({ onChange, data, setData }: IProps) => {
  const { t } = useTranslation(["common", "validate"]);
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();

  const onFinish = (values) => {
    console.log(values);
  };

  useEffect(() => {
    if (data && data?.type === TYPE_TREE_NODE.VIEWPOINT) {
      form.setFieldValue("no", data?.item?.viewDetail?.no);
      form.setFieldValue(
        "viewpointDetail",
        data?.item?.viewDetail?.viewpointDetail
      );
      form.setFieldValue("confirmation", data?.item?.viewDetail?.confirmation);
      form.setFieldValue("example", data?.item?.viewDetail?.example);
      form.setFieldValue("note", data?.item?.viewDetail?.note);
    }
  }, [data]);
  console.log(data);

  return (
    <Wrapper className="sticky">
      {!data ? (
        <div className="detail-viewpoint-collection-detail">
          <div className="detail-viewpoint-collection-tree-empty">
            <Empty
              image={Empty.PRESENTED_IMAGE_SIMPLE}
              description={<span>{t("common:no_data")}</span>}
            />
          </div>
        </div>
      ) : (
        <div className="detail-viewpoint-collection-detail">
          <div>
            <Typography.Title level={4} className="color-text">
              {t("common:detail_info")}
            </Typography.Title>
            {data?.type === TYPE_TREE_NODE.VIEWPOINT && (
              <Tag color="#9254de">{t("common:viewpoint")}</Tag>
            )}
            {data?.type === TYPE_TREE_NODE.DOMAIN && (
              <Tag color="#73d13d">{t("common:domain")}</Tag>
            )}
            {data?.type === TYPE_TREE_NODE.TEST_TYPE && (
              <Tag color="#faad14">{t("common:test_type")}</Tag>
            )}
            {data?.type === TYPE_TREE_NODE.CATEGORY && (
              <Tag color="#40a9ff">{t("common:category")}</Tag>
            )}
          </div>
          <Form
            style={{ marginTop: "1.5rem" }}
            onFinish={onFinish}
            form={form}
            layout="vertical"
            autoComplete="off"
            onChange={onChange}
          >
            {data?.type !== TYPE_TREE_NODE.VIEWPOINT ? (
              <Descriptions>
                <Descriptions.Item label={t("common:name")} span={12}>
                  {data?.item?.domain?.detail?.name}
                </Descriptions.Item>
                <Descriptions.Item label={t("common:description")}>
                  {data?.item?.domain?.detail?.description}
                </Descriptions.Item>
              </Descriptions>
            ) : (
              <>
                <Form.Item name="no" label={t("common:no")}>
                  <Input placeholder={t("common:enter_no")} />
                </Form.Item>
                <Form.Item
                  name="viewpointDetail"
                  label={t("common:viewpoint_detail")}
                >
                  <Input.TextArea
                    rows={2}
                    placeholder={t("common:enter_viewpoint_detail")}
                  />
                </Form.Item>
                <Form.Item name="confirmation" label={t("common:confirmation")}>
                  <Input.TextArea
                    rows={3}
                    placeholder={t("common:enter_confirmation")}
                  />
                </Form.Item>
                <Form.Item name="example" label={t("common:example")}>
                  <Input.TextArea
                    rows={3}
                    placeholder={t("common:enter_example")}
                  />
                </Form.Item>
                <Form.Item name="Note" label={t("common:note")}>
                  <Input.TextArea
                    rows={3}
                    placeholder={t("common:enter_note")}
                  />
                </Form.Item>
                <Space style={{ justifyContent: "right", width: "100%" }}>
                  <Button type="primary" htmlType="submit" loading={loading}>
                    {t("common:save")}
                  </Button>
                </Space>
              </>
            )}
          </Form>
        </div>
      )}
    </Wrapper>
  );
};

export default DetailProductForm;
