import { CloseOutlined } from "@ant-design/icons";
import { LocaleProvider } from "@components";
import { IReponseData } from "@models/model";
import { rootState } from "@models/type";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import { checkContainsSpecialCharacter, debounce } from "@utils/helpersUtils";
import {
  AutoComplete,
  Col,
  Empty,
  Form,
  Input,
  Modal,
  Row,
  Space,
  Spin,
  Tree,
  TreeSelect,
  Typography,
} from "antd";
import type { SelectProps } from "antd/es/select";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import { ViewpointCollectionWrapper } from "./ModalClone.Styled";
const { SHOW_PARENT } = TreeSelect;

const ModalClone = ({ isModalOpen, setIsModalOpen, getData }) => {
  const [form] = Form.useForm();
  const { domain } = useSelector((state: rootState) => state.domain);
  const [value, setValue] = useState([]);
  const [viewpointCollection, setViewpointCollection] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [loadingViewpointTree, setLoadingViewpointTree] = useState(false);
  const [viewpointSelect, setViewpointSelect] = useState([]);
  const [valueSelect, setValueSelect] = useState<any>();
  const [checkedKeys, setCheckedKeys] = useState<React.Key[]>(["0-0-0"]);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);
  const { t } = useTranslation(["common", "validate", "responseMessage"]);
  const [treeData0, setTreeData0] = useState([]);
  const [errorSearch, setErrorSearch] = useState("");
  const [options, setOptions] = useState<SelectProps<object>["options"]>([]);
  const [selectedVPCollection, setSelectedVPCollection] = useState(null);

  const searchResult = (arr) => {
    return arr.map((item) => {
      return {
        value: item?.detail?.name,
        id: item?.id,
        label: (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>{item?.detail?.name}</span>
            <span>{item?.user?.account}</span>
          </div>
        ),
      };
    });
  };

  const handleSearch = async (value) => {
    if (checkContainsSpecialCharacter(value.trim())) {
      setErrorSearch(t("validate:string_not_contains_special_characters"));
    } else {
      setErrorSearch("");
      try {
        setLoading(true);
        const response = await viewpointCollectionAPI.getAllViewpointCollection(
          {
            payload: {
              search: value?.trim(),
            },
          }
        );
        setOptions(searchResult(response?.data));
      } catch (error) {
      } finally {
        setLoading(false);
      }
    }
  };

  const onSelectAutoCompleted = async (value: string, option: any) => {
    try {
      setLoadingViewpointTree(true);
      const response = await viewpointCollectionAPI.getViewpointCollectionById(
        option.id
      );
      setSelectedVPCollection(response?.data);
    } catch (error) {
    } finally {
      setLoadingViewpointTree(false);
    }
  };

  useEffect(() => {
    let dataViewpoint;
    // convert data when we have a viewpointCollection and click on the icon clone collection
    if (viewpointCollection && valueSelect) {
      const res = viewpointCollection.data.filter(
        (viewpoint) => viewpoint.id == valueSelect?.id
      );
      // function convert data to format tree in antd

      const convertTreeData = (table) => {
        const keys = table.map((x) => x?.id);
        const formattedData = table.map((x) => {
          return {
            key: x.id,
            title: x.viewDetail.name,
            // JSON.parse(x.viewDetail)[0]?.Name
            parentKey: x?.parentId,
            description: x?.description,
            isActive: x?.isActive,
          };
        });
        const result = formattedData
          .map((parent) => {
            const children = formattedData.filter((child) => {
              if (
                child.key !== child.parentKey &&
                child.parentKey === parent.key
              ) {
                return true;
              }
              return false;
            });
            if (children.length) {
              parent.children = children;
            }
            return parent;
          })
          .filter((obj) => {
            if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
              return true;
            }
            return false;
          });
        return result;
      };
      if (res[0]?.viewPoints?.length > 0) {
        dataViewpoint = convertTreeData(res[0]?.viewPoints);
      } else {
        dataViewpoint = [];
      }
    }
    setTreeData0(dataViewpoint);
  }, []);

  const validateMessages = {
    required: t("validate:label_translate"),
    types: {
      email: t("common:email_validate"),
      number: t("common:number_validate"),
      name: t("validate:name_validate"),
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };
  let treeData;
  if (domain) {
    const convertTreeData = (table) => {
      const keys = table.map((x) => x?.id);
      const formattedData = table.map((x) => {
        return {
          key: x.id,
          title: x.detail.name,
          parentKey: x?.parentId,
          value: x?.id,
        };
      });
      const result = formattedData
        .map((parent) => {
          const children = formattedData.filter((child) => {
            if (
              child.key !== child.parentKey &&
              child.parentKey === parent.key
            ) {
              return true;
            }
            return false;
          });

          if (children.length) {
            parent.children = children;
          }
          return parent;
        })
        .filter((obj) => {
          if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
            return true;
          }
          return false;
        });
      return result;
    };
    treeData = convertTreeData(domain);
  }
  const onChangeTreeDomain = (newValue: string[]) => {
    setValue(newValue);
  };
  const tProps = {
    treeData: treeData,
    value,
    onChange: onChangeTreeDomain,
    // onSelect,
    treeCheckable: true,
    treeCheckStrictly: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: t("common:select_domain"),
    style: {
      width: "100%",
    },
  };
  useEffect(() => {
    if (valueSelect) {
      const value = valueSelect?.domains.map((e) => e.id);

      form.setFieldsValue({ domainIds: value });
    }
  }, [valueSelect]);

  //  function submit clone collection
  const onFinish = async (values: any) => {
    try {
      setLoading(true);
      const contentLanguage = localStorage.getItem("i18nextLng");
      const res = {
        detail: JSON.stringify([
          {
            name: values?.name,
            language: contentLanguage,
            description: values?.description,
          },
        ]),
        cloneCollectionId: valueSelect?.id,
        domainIds: values?.domainIds.map((domainId) => domainId?.value)[0]
          ? values?.domainIds.map((domainId) => domainId?.value)
          : values?.domainIds,
        viewPoints: viewpointSelect
          ? viewpointSelect.map((e) => {
              return {
                confirmation: e?.confirmation,
                createdAt: e?.createdAt,
                createdBy: e?.createdBy,
                id: e?.id,
                image: e?.image,
                isActive: e?.isActive,
                isDeleted: e?.isDeleted,
                parentId: e?.parentId,
                sample: e?.sample,
                testTypeId: e?.testTypeId,
                updateBy: e?.updateBy,
                updatedAt: e?.updatedAt,
                viewDetail: JSON?.stringify([e?.viewDetail]),
                viewPointCategoryId: e?.viewPointCategoryId,
                viewPointCollectionId: e?.viewPointCollectionId,
              };
            })
          : [],
        status: 0,
      };
      const respone: IReponseData =
        await viewpointCollectionAPI.cloneCollection({
          payload: res,
        });
      form.resetFields();
      await getData();
      setIsModalOpen(false);
      setViewpointSelect(null);
      setValueSelect(null);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };

  // function check and uncheck viewpoint
  const onCheck = (checkedKeysValue: any, infor) => {
    const array = [];
    const res = viewpointCollection.data.filter(
      (viewpoint) => viewpoint.id == valueSelect?.id
    );
    if (infor.halfCheckedKeys.length == 0) {
      checkedKeysValue.forEach((node) => {
        res.forEach((value) => {
          value.viewPoints.forEach((viewpoint) => {
            if (viewpoint.id == node) {
              array.push(viewpoint);
            }
          });
        });
      });
    } else {
      checkedKeysValue.forEach((node) => {
        res.forEach((value) => {
          value.viewPoints.forEach((viewpoint) => {
            if (viewpoint.id == node) {
              array.push(viewpoint);
            }
          });
        });
      });
      infor.halfCheckedKeys.forEach((key) => {
        res.forEach((value) => {
          value.viewPoints.forEach((viewpoint) => {
            if (viewpoint.id == key) {
              array.push(viewpoint);
            }
          });
        });
      });
    }
    setViewpointSelect(array);
    setCheckedKeys(checkedKeysValue);
  };

  const onSelect = (selectedKeysValue: React.Key[], info: any) => {
    setSelectedKeys(selectedKeysValue);
  };

  return (
    <Modal
      visible={isModalOpen}
      onOk={() => setIsModalOpen(false)}
      onCancel={() => {
        setValueSelect([]);
        form.resetFields();
        setValueSelect(null);
        setIsModalOpen(false);
      }}
      confirmLoading={loading}
      width={1200}
      closable={false}
      okText={t("common:clone")}
      cancelText={t("common:cancel")}
      bodyStyle={{ padding: "0" }}
      style={{ top: 80 }}
    >
      <Row>
        <Col md={24} style={{ padding: "30px 60px" }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", marginBottom: "20px" }}>
              <div>
                <h1 style={{ margin: "0", color: "var(--clr-text)" }}>
                  {t("common:clone_viewpoint")}
                </h1>
              </div>
            </div>
            <ViewpointCollectionWrapper>
              <div>
                <CloseOutlined
                  onClick={() => {
                    setIsModalOpen(false);
                    form.resetFields();
                    setValueSelect(null);
                  }}
                  className="icon-close"
                />
              </div>
            </ViewpointCollectionWrapper>
          </div>
          <Space direction="vertical">
            <Space direction="vertical">
              <Typography.Text className="color-text">
                {t("common:search_vp_clone")}
              </Typography.Text>
              <AutoComplete
                dropdownMatchSelectWidth={252}
                style={{ width: 420 }}
                options={options}
                onSelect={onSelectAutoCompleted}
                onSearch={handleSearch}
                maxLength={40}
              >
                <Input.Search
                  className="search-box"
                  placeholder={t("common:enter_search_text")}
                  enterButton={t("common:search")}
                  loading={loading}
                  status={errorSearch !== "" ? "error" : ""}
                />
              </AutoComplete>
              {errorSearch !== "" && (
                <span className="error-search">{errorSearch}</span>
              )}
            </Space>
            {selectedVPCollection && (
              <Space direction="vertical">
                <Typography.Text className="color-text">
                  {t("common:your_selected_viewpoint")}
                </Typography.Text>
                <Typography.Title level={3} className="color-text">
                  {selectedVPCollection?.detail?.name}
                </Typography.Title>
              </Space>
            )}
          </Space>

          <div style={{ marginTop: "10px" }}>
            <Typography.Text className="color-text">
              {t("common:detail_new_viewpoint")}
            </Typography.Text>
            <Spin spinning={loadingViewpointTree}>
              {treeData0?.length > 0 ? (
                <div
                  style={{
                    border: "1px solid #ccc",
                    padding: "20px",
                    marginTop: "10px",
                  }}
                >
                  <Tree
                    checkable
                    // onExpand={onExpand}
                    // expandedKeys={expandedKeys}
                    defaultExpandAll
                    autoExpandParent={false}
                    onCheck={onCheck}
                    checkedKeys={checkedKeys}
                    onSelect={onSelect}
                    selectedKeys={selectedKeys}
                    treeData={treeData0}
                    rootStyle={{
                      backgroundColor: "var(--background-color-element)",
                      color: "var(--clr-text)",
                    }}
                  />
                </div>
              ) : (
                <div
                  style={{
                    border: "1px solid #ccc",
                    padding: "20px",
                    marginTop: "10px",
                    borderRadius: "var(--border-radius-element)",
                  }}
                >
                  <LocaleProvider>
                    <Empty style={{ marginTop: "10px" }} />
                  </LocaleProvider>
                </div>
              )}
            </Spin>
          </div>
        </Col>
      </Row>
    </Modal>
  );
};

export default ModalClone;
