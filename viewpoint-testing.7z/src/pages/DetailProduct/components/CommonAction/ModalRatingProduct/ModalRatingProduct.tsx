import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import { Modal, Rate, Typography } from "antd";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Wrapper } from "./ModalRatingProduct.Styled";

interface IProps {
  visible: boolean;
  onCancel: () => void;
  currentProduct: any;
  setCurrentProduct: (any) => void;
}

const ModalRatingVPCollection = ({
  visible,
  onCancel,
  currentProduct,
  setCurrentProduct,
}: IProps) => {
  const { t } = useTranslation(["common"]);
  const [value, setValue] = useState(1);

  const handleOnOk = async () => {
    try {
      const response = await viewpointCollectionAPI.ratingViewpointCollection(
        currentProduct?.id,
        value
      );
      setCurrentProduct({
        ...currentProduct,
        avgRating: response?.data?.starRating,
      });
      showSuccessNotification(t("common:rating_successfully"));
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error?.code}`));
    } finally {
      onCancel();
      setValue(1);
    }
  };
  return (
    <Modal
      title={t("common:rating_vp_collection")}
      visible={visible}
      onCancel={() => {
        onCancel();
        setValue(1);
      }}
      onOk={handleOnOk}
      okText={t("common:rating")}
      cancelText={t("common:cancel")}
      width={500}
    >
      <Wrapper>
        <Typography.Text className="color-text">
          {t("common:rating")}:
        </Typography.Text>
        <Rate
          onChange={setValue}
          value={value}
          style={{ marginLeft: "100px" }}
        />
      </Wrapper>
    </Modal>
  );
};

export default ModalRatingVPCollection;
