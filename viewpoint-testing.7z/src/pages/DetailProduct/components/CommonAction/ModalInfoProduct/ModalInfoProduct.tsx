import { STATUS_VIEWPOINT_COLLECTION } from "@utils/constants";
import { Button, Descriptions, Modal } from "antd";
import React from "react";
import { useTranslation } from "react-i18next";

interface IProps {
  visible: boolean;
  onCancel: () => void;
  currentProduct: any;
}

const ModalInfoVPCollection = ({
  visible,
  onCancel,
  currentProduct,
}: IProps) => {
  const { t } = useTranslation(["common"]);
  return (
    <Modal
      title={t("common:viewpoint_detail")}
      visible={visible}
      onCancel={onCancel}
      width={800}
      footer={[
        <Button key="ok" type="primary" onClick={onCancel}>
          {t("common:ok")}
        </Button>,
      ]}
    >
      <Descriptions title={currentProduct?.detail?.name} layout="vertical">
        <Descriptions.Item label={t("common:create_by")}>
          {currentProduct?.user?.account}
        </Descriptions.Item>
        <Descriptions.Item label={t("common:status")}>
          {currentProduct?.status === STATUS_VIEWPOINT_COLLECTION.ON_GOING &&
            t("common:on_going")}
          {currentProduct?.status === STATUS_VIEWPOINT_COLLECTION.PUBlISH &&
            t("common:publish")}
          {currentProduct?.status === STATUS_VIEWPOINT_COLLECTION.PRIVATE &&
            t("common:private")}
        </Descriptions.Item>
        <Descriptions.Item label={t("common:date_created")}>
          {new Date(currentProduct?.createdAt).toLocaleString()}
        </Descriptions.Item>
        <Descriptions.Item label="Domain">Automative</Descriptions.Item>
        <Descriptions.Item label={t("common:last_modified_by")}>
          ThienNTM
        </Descriptions.Item>
        <Descriptions.Item label={t("common:last_updated")}>
          {new Date(currentProduct?.updatedAt).toLocaleString()}
        </Descriptions.Item>
        <Descriptions.Item label={t("common:clone_from")}>
          {currentProduct?.cloneCollectionId}
        </Descriptions.Item>
      </Descriptions>
    </Modal>
  );
};

export default ModalInfoVPCollection;
