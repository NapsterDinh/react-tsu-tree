import { CloseOutlined } from "@ant-design/icons";
import { LocaleProvider } from "@components";
import {
  checkContainsSpecialCharacter,
  expandedKeysWithLevel,
  removeEmoji,
} from "@utils/helpersUtils";
import {
  Button,
  Col,
  Empty,
  Form,
  Input,
  Modal,
  Row,
  Select,
  Tree,
  TreeSelect,
} from "antd";
import { Option } from "antd/lib/mentions";
import { useState, useEffect } from "react";
import { ViewpointCollectionWrapper } from "../../ViewpointCollectionWrapper";
const ModalClone = ({
  isModalOpen,
  handleOk,
  handleCancel,
  setIsModalOpen,
  onFinish,
  onFinishFailed,
  form,
  valueSelect,
  domain,
  onExpand,
  autoExpandParent,
  checkedKeys,
  onCheck,
  onSelect,
  selectedKeys,
  treeData0,
  t,
  setValueSelect,
  setMessageClone,
}) => {
  const { SHOW_PARENT } = TreeSelect;
  // const [expandedKeys, setExpandedKeys] = useState<React.Key[]>([]); // array of expanded keys for tree

  const [value, setValue] = useState([]);
  const validateMessages = {
    required: t("validate:label_translate"),
    types: {
      email: t("common:email_validate"),
      number: t("common:number_validate"),
      name: t("validate:name_validate"),
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };
  let treeData;
  if (domain) {
    const convertTreeData = (table) => {
      const keys = table.map((x) => x?.id);
      const formattedData = table.map((x) => {
        return {
          key: x.id,
          title: x.detail.name,
          parentKey: x?.parentId,
          value: x?.id,
        };
      });
      const result = formattedData
        .map((parent) => {
          const children = formattedData.filter((child) => {
            if (
              child.key !== child.parentKey &&
              child.parentKey === parent.key
            ) {
              return true;
            }
            return false;
          });

          if (children.length) {
            parent.children = children;
          }
          return parent;
        })
        .filter((obj) => {
          if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
            return true;
          }
          return false;
        });
      return result;
    };
    treeData = convertTreeData(domain);
  }

  const onChangeTreeDomain = (newValue: string[]) => {
    setValue(newValue);
  };
  const tProps = {
    treeData: treeData,
    value,
    onChange: onChangeTreeDomain,
    // onSelect,
    treeCheckable: true,
    treeCheckStrictly: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: t("common:select_domain"),
    style: {
      width: "100%",
    },
    filterTreeNode: (search, item) => {
      return item.title.toLowerCase().indexOf(search.toLowerCase()) >= 0;
    },
  };
  useEffect(() => {
    if (valueSelect) {
      const value = valueSelect?.domains.map((e) => e.id);

      form.setFieldsValue({ domainIds: value });
    }
    // handleChangeSearchInputSelectLevel(-1);
  }, [valueSelect]);
  // const handleChangeSearchInputSelectLevel = (value) => {
  //   const updatedData = [];

  //   const clonedData = [...treeData];
  //   if (value == -1) {
  //     expandedKeysWithLevel(clonedData, Infinity, updatedData);
  //   } else {
  //     expandedKeysWithLevel(clonedData, value, updatedData);
  //   }
  //   setExpandedKeys(updatedData);
  // };
  return (
    <Modal
      visible={isModalOpen}
      onOk={handleOk}
      onCancel={() => {
        handleCancel();
        setMessageClone(null);
        form.resetFields();
        setValueSelect(null);
      }}
      width={1200}
      footer={null}
      closable={false}
      bodyStyle={{ padding: "0" }}
      style={{ top: 80 }}
    >
      <Row>
        <Col md={24} style={{ padding: "30px 60px" }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", marginBottom: "20px" }}>
              <div>
                <h1 style={{ margin: "0", color: "var(--clr-text)" }}>
                  {t("common:clone_viewpoint")}
                </h1>
              </div>
            </div>
            <ViewpointCollectionWrapper>
              <div>
                <CloseOutlined
                  onClick={() => {
                    setIsModalOpen(false);
                    form.resetFields();
                    setValueSelect(null);
                  }}
                  className="icon-close"
                />
              </div>
            </ViewpointCollectionWrapper>
          </div>
          <Form
            name="basic"
            labelCol={{ span: 24 }}
            wrapperCol={{ span: 24 }}
            initialValues={{ remember: true }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off"
            // layout="vertical"
            validateMessages={validateMessages}
            form={form}
          >
            <Form.Item
              label={<strong>{t("common:name")}</strong>}
              name="name"
              required
              rules={[
                {
                  validator(_, value) {
                    if (!value) {
                      return Promise.reject(t("validate:viewpoint_name"));
                    } else if (value.startsWith(" ") || value.endsWith(" ")) {
                      return Promise.reject(t("validate:viewpoint_trim_space"));
                    } else if (checkContainsSpecialCharacter(value)) {
                      return Promise.reject(
                        t("validate:viewpoint_name_contains_special_character")
                      );
                    } else if (removeEmoji(value)) {
                      return Promise.reject(
                        t("validate:viewpoint_name_contains_special_character")
                      );
                    }
                    return Promise.resolve();
                  },
                },
                {
                  min: 6,
                  message: t("validate:name_viewpoint_collection_min_length"),
                },
                {
                  max: 30,
                  message: t("validate:name_viewpoint_collection_max_length"),
                },
              ]}
              validateTrigger={["onBlur", "onChange"]}
            >
              <Input
                style={{ height: "40px" }}
                placeholder={t("common:input_viewpoint_collection_name")}
              />
            </Form.Item>
            <Form.Item
              label={<strong>{t("common:domain")}</strong>}
              name="domainIds"
              rules={[
                {
                  required: true,
                  message: t(
                    "validate:name_viewpoint_collection_with_domain_list"
                  ),
                },
              ]}
              validateTrigger={["onBlur", "onChange"]}
            >
              <TreeSelect {...tProps} />
            </Form.Item>
            <Form.Item
              label={<strong>{t("common:description")}</strong>}
              name="description"
              required
              validateTrigger={["onBlur", "onChange"]}
              rules={[
                {
                  validator(_, value) {
                    if (!value) {
                      return Promise.reject(
                        t("validate:viewpoint_description")
                      );
                    } else if (value.startsWith(" ") || value.endsWith(" ")) {
                      return Promise.reject(t("validate:viewpoint_trim_space"));
                    } else if (checkContainsSpecialCharacter(value)) {
                      return Promise.reject(
                        t(
                          "validate:description_name_contains_special_character"
                        )
                      );
                    } else if (removeEmoji(value)) {
                      return Promise.reject(
                        t(
                          "validate:description_name_contains_special_character"
                        )
                      );
                    }
                    return Promise.resolve();
                  },
                },
                {
                  max: 1200,
                  message: t(
                    "validate:description_viewpoint_collection_max_length"
                  ),
                },
              ]}
            >
              <Input.TextArea
                placeholder={t("common:input_viewpoint_collection_description")}
                rows={4}
                maxLength={250}
              />
            </Form.Item>
            <strong
              style={{
                color: "var(--clr-text)",
              }}
            >
              {t("common:detail_new_viewpoint")}
            </strong>
            {/* <Select
              onChange={handleChangeSearchInputSelectLevel}
              defaultValue="1"
              style={{ width: 150 }}
            >
              <Option value="-1">{t("common:all_level")}</Option>
              <Option value="1">{`${t("common:domain_level")} 1`}</Option>
              <Option value="2">{`${t("common:domain_level")} 2`}</Option>
              <Option value="3">{`${t("common:domain_level")} 3`}</Option>
              <Option value="4">{`${t("common:domain_level")} 4`}</Option>
              <Option value="5">{`${t("common:domain_level")} 5`}</Option>
              <Option value="6">{`${t("common:domain_level")} 6`}</Option>
              <Option value="7">{`${t("common:domain_level")} 7`}</Option>
            </Select> */}
            {treeData0?.length > 0 ? (
              <div
                style={{
                  border: "1px solid #ccc",
                  padding: "20px",
                  marginTop: "10px",
                }}
              >
                <Tree
                  checkable
                  onExpand={onExpand}
                  // expandedKeys={expandedKeys}
                  // defaultExpandAll
                  autoExpandParent={autoExpandParent}
                  onCheck={onCheck}
                  checkedKeys={checkedKeys}
                  onSelect={onSelect}
                  selectedKeys={selectedKeys}
                  treeData={treeData0}
                  rootStyle={{
                    backgroundColor: "var(--background-color-element)",
                    color: "var(--clr-text)",
                  }}
                />
              </div>
            ) : (
              <div
                style={{
                  border: "1px solid #ccc",
                  padding: "20px",
                  marginTop: "10px",
                  borderRadius: "var(--border-radius-element)",
                }}
              >
                <LocaleProvider>
                  <Empty style={{ marginTop: "10px" }} />
                </LocaleProvider>
              </div>
            )}
            <Form.Item
              wrapperCol={{ offset: 20, span: 21 }}
              style={{ marginTop: "20px" }}
            >
              <ViewpointCollectionWrapper>
                <div style={{ display: "flex", justifyContent: "end" }}>
                  <Button
                    style={{ color: "var(--clr-text)" }}
                    htmlType="button"
                    onClick={() => {
                      setIsModalOpen(false);
                      form.resetFields();
                      setValueSelect(null);
                    }}
                  >
                    {t("common:cancel")}
                  </Button>
                  <Button
                    style={{
                      backgroundColor: "#107649",
                      border: "1px solid #107649",
                      marginLeft: "21px",
                    }}
                    className="btn-submit"
                    htmlType="submit"
                  >
                    {t("common:save")}
                  </Button>
                </div>
              </ViewpointCollectionWrapper>
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </Modal>
  );
};

export default ModalClone;
