import styled from "styled-components";

export const RequestManagementWrapper = styled.div`
  color: var(--clr-text);
  .mr-t-20 {
    margin-top: 20px;
  }
  .container-sort {
    display: flex;
  }
  .ant-input-affix-wrapper {
    padding: 0;
  }
`;
