import { BreadCrumb } from "@components";
import { userActions } from "@redux/slices";
import { DatePicker, Input, Select, Space, Spin, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import { Link, useLocation, useSearchParams } from "react-router-dom";
import { RequestManagementWrapper } from "./RequestManagementWrapper";
import { LocaleProvider } from "@components";
const { Option } = Select;
const { Search } = Input;
const RequestManagement: React.FC = () => {
  const location = useLocation();
  const { t } = useTranslation(["common"]); // languages

  const [searchParams, setSearchParams] = useSearchParams();
  const handleChangeAsc = (value: string) => {
    if (searchParams.getAll("Text")[0] && searchParams.getAll("isActive")[0]) {
      setSearchParams({
        isActive: searchParams.getAll("isActive")[0],
        Text: searchParams.getAll("Text")[0],
        Sort: value,
      });
    } else if (searchParams.getAll("Text")[0]) {
      setSearchParams({
        Text: searchParams.getAll("Text")[0],
        Sort: value,
      });
    } else if (searchParams.getAll("isActive")[0]) {
      setSearchParams({
        isActive: searchParams.getAll("isActive")[0],
        Sort: value,
      });
    } else {
      setSearchParams({
        Sort: value,
      });
    }
  };
  const handleChangeSortActive = (value: string) => {
    if (searchParams.getAll("Text")[0] && searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        Text: searchParams.getAll("Text")[0],
        isActive: value,
      });
    } else if (searchParams.getAll("Text")[0]) {
      setSearchParams({
        Text: searchParams.getAll("Text")[0],
        isActive: value,
      });
    } else if (searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        isActive: value,
      });
    } else {
      setSearchParams({
        isActive: value,
      });
    }
  };
  const handleChangeStatus = (id: string, value: string) => {
    console.log(`selected ${value}`);
    dispatch(userActions.updateStatus({ isActive: value, id }));
  };
  const handleChangeRole = (id: string, value: string) => {
    console.log(`selected ${value} ${id}`);
    dispatch(userActions.updateRole({ role: value, id }));
  };
  const onSearch = (value: string) => {
    if (searchParams.getAll("isActive")[0] && searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        isActive: searchParams.getAll("isActive")[0],
        Text: value,
      });
    } else if (searchParams.getAll("isActive")[0]) {
      setSearchParams({
        isActive: searchParams.getAll("isActive")[0],
        Text: value,
      });
    } else if (searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        Text: value,
      });
    } else {
      setSearchParams({
        Text: value,
      });
    }
  };
  interface DataType {
    key: React.Key;
    id: string;
    requestType: string;
    requester: string;
    description: string;
    status: any;
    dateStart: any;
    action: any;
  }
  const { RangePicker } = DatePicker;

  const columns: ColumnsType<DataType> = [
    {
      title: "id",
      dataIndex: "id",
    },
    {
      title: t("common:request_type"),
      dataIndex: "requestType",
    },
    {
      title: t("common:requester"),
      dataIndex: "requester",
    },

    {
      title: t("common:description"),
      dataIndex: "description",
    },
    {
      title: t("common:date_created"),
      dataIndex: "dateStart",
    },
    {
      title: t("common:status"),
      dataIndex: "status",
    },
    {
      title: t("common:action"),
      dataIndex: "action",
    },
  ];
  const data: DataType[] = [
    {
      key: "1",
      id: "1",
      requestType: "Viewpoint*",
      requester: "IVS1",
      description: "Update master data",
      dateStart: "2022 20/10",
      status: "Pending",
      action: <Link to="/detail-request/1">Detail</Link>,
    },
    {
      key: "2",
      id: "2",
      requestType: "Viewpoint*",
      requester: "IVS2",
      description: "Update master data",
      dateStart: "2022 20/10",
      status: "Pending",
      action: <Link to="/detail-request/2">Detail</Link>,
    },
    {
      key: "3",
      id: "3",
      requestType: "Viewpoint*",
      requester: "IVS3",
      description: "Update master data",
      dateStart: "2022 20/10",
      status: "Pending",
      action: <Link to="/detail-request/3">Detail</Link>,
    },
  ];

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(userActions.getAllUser({ search: location.search }));
  }, [location.search]);
  let userData;

  const onChange = (page, pageSize) => {
    // dispatch(
    //   userActions.getAllUser({
    //     search: location.search,
    //     PageSize: pageSize,
    //     PageNumber: page,
    //   })
    // );
  };
  return (
    <RequestManagementWrapper>
      <BreadCrumb
        title={t("request_management")}
        previousTitle={t("home_page")}
        link="/"
        breadCrumb={true as boolean}
      />
      <Space className="container-sort">
        <div className="item-sort">
          <p className="label">{t("common:sort")}</p>
          <Select
            defaultValue={t("common:no_sort")}
            style={{ width: 180 }}
            onChange={handleChangeAsc}
          >
            <Option value={0}>{t("common:sort_by_name_a_z")}</Option>
            <Option value={1}>{t("common:sort_by_name_z_a")}</Option>
            <Option value={2}>{t("common:no_sort")}</Option>
          </Select>
        </div>
        <div className="item-sort">
          <p className="label">{t("common:status")}</p>
          <Select
            defaultValue={t("common:status_active")}
            style={{ width: 180 }}
            onChange={handleChangeSortActive}
          >
            <Option value="1">{t("common:status_active")}</Option>
            <Option value="0">{t("common:status_inactive")}</Option>
          </Select>
        </div>
        <div className="item-sort1">
          <p className="label">{t("common:search")}</p>
          {/* <Search
            placeholder="input search text"
            allowClear
            onSearch={onSearch}
            style={{ width: 400 }}
          /> */}

          <Search
            placeholder={t("common:enter_search_text")}
            onSearch={onSearch}
            maxLength={20}
            enterButton={t("common:search")}
            style={{ width: 343 }}
          />
        </div>
      </Space>
      <div className="mr-t-20">
        <LocaleProvider>
          <Table
            scroll={{
              x: 600,
            }}
            rowKey={"id"}
            columns={columns}
            dataSource={data}
            pagination={
              data?.length > 20
                ? {
                    defaultPageSize: 20,
                    showSizeChanger: true,
                    pageSizeOptions: ["20", "30", "50"],
                    // total: viewpointCollection?.metaData?.totalCount,
                    defaultCurrent: 1,
                    onChange: onChange,
                    showQuickJumper: true,
                  }
                : false
            }
          />
        </LocaleProvider>
      </div>
    </RequestManagementWrapper>
  );
};

export default RequestManagement;
