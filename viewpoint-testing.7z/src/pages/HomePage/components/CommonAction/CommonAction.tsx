import { Input, Select, Space } from "antd";
import { useTranslation } from "react-i18next";
import { Wrapper } from "./CommonAction.Styled";
const { Option } = Select;
const { Search } = Input;

type CommonActionProps = {
  onSearch: (any) => void;
  handleChangeFilter: (string, any) => void;
  loading: boolean;
  errorSearch: string;
};

const CommonAction: React.FC<CommonActionProps> = ({
  onSearch,
  handleChangeFilter,
  loading,
  errorSearch,
}) => {
  const { t } = useTranslation(["common"]);
  return (
    <Wrapper>
      <Space
        className="common-action"
        style={{ justifyContent: "space-between", position: "relative" }}
        align="end"
      >
        <Space direction="vertical" className="search-container">
          <p className="label">{t("common:search")}</p>
          <Search
            className="search-box"
            placeholder={t("common:enter_search_text")}
            enterButton={t("common:search")}
            onSearch={onSearch}
            maxLength={20}
            loading={loading}
            status={errorSearch !== "" ? "error" : ""}
          />
          {errorSearch !== "" && (
            <span className="error-search">{errorSearch}</span>
          )}
        </Space>
        <Space>
          <Space direction="vertical">
            <span className="label">{t("common:last_opened_time")}</span>
            <Select
              defaultValue="3"
              style={{
                width: 180,
              }}
              onChange={(value) => handleChangeFilter("LastOpenedTime", value)}
            >
              <Option value="3">{t("common:all_of_time")}</Option>
              <Option value="0">{t("common:today")}</Option>
              <Option value="1">{t("common:within_last_7_days")}</Option>
              <Option value="2">{t("common:within_last_30_days")}</Option>
            </Select>
          </Space>
          <Space direction="vertical">
            <span className="label">{t("common:owner")}</span>
            <Select
              defaultValue="3"
              style={{
                width: 180,
              }}
              onChange={(value) => handleChangeFilter("Owner", value)}
            >
              <Option value="3">{t("common:owned_by_everyone")}</Option>
              <Option value="2">{t("common:owned_by_me")}</Option>
              <Option value="0">{t("common:not_owned_by_me")}</Option>
            </Select>
          </Space>

          <Space direction="vertical">
            <span className="label">{t("common:type_file")}</span>
            <Select
              defaultValue="2"
              style={{
                width: 180,
              }}
              onChange={(value) => handleChangeFilter("TypeFile", value)}
            >
              <Option value="2">{t("common:all_of_type_file")}</Option>
              <Option value="1">{t("common:product")}</Option>
              <Option value="0">{t("common:viewpoint_collection")}</Option>
            </Select>
          </Space>
        </Space>
      </Space>
    </Wrapper>
  );
};

export default CommonAction;
