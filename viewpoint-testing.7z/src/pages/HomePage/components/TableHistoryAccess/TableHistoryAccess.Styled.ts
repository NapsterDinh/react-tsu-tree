import styled from "styled-components";

export const Wrapper = styled.div`
  &&& {
    .type_file div {
      margin: auto;
    }
  }
`;
