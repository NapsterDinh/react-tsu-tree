import { LocaleProvider } from "@components";
import { HistoryAccessItem } from "@pages/HomePage/HomePage";
import { Space, Table, Tooltip } from "antd";

import type { ColumnsType } from "antd/es/table";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Wrapper } from "./TableHistoryAccess.Styled";

type TableHistoryAccessProps = {
  data: HistoryAccessItem[];
  loading: boolean;
  pagination: any;
  setPagination: (any) => void;
  handleCallAPI: (any?) => void;
};

const TableHistoryAccess: React.FC<TableHistoryAccessProps> = ({
  data,
  loading,
  pagination,
  setPagination,
  handleCallAPI,
}) => {
  const { t } = useTranslation(["common"]);

  const columns: ColumnsType<HistoryAccessItem> = [
    {
      title: t("common:name"),
      dataIndex: "name",
      width: "30%",
      ellipsis: true,
      render: (text, item) => (
        <Tooltip title={text}>
          <Space>
            {item?.icon}
            <Link to={`/viewpoint-management/${item?.commonId}`}>{text}</Link>
          </Space>
        </Tooltip>
      ),
    },
    {
      title: "Domain",
      dataIndex: "domainName",
      ellipsis: true,
      width: "20%",
      render: (text, item) => (
        <Tooltip title={text}>
          <span>{text}</span>
        </Tooltip>
      ),
    },
    {
      title: t("common:owner"),
      dataIndex: "userName",
      width: "15%",
      align: "center" as const,
    },
    {
      title: t("common:last_updated_at"),
      dataIndex: "updatedAt",
      width: "15%",
    },
    {
      title: t("common:last_opened_time"),
      dataIndex: "lastOpenedTime",
      width: "15%",
    },
  ];

  const handleOnChangePagination = (page, pageSize) => {
    setPagination({ ...pagination, pageSize: pageSize, currentPage: page });
    handleCallAPI({ ...pagination, pageSize: pageSize, currentPage: page });
  };

  return (
    <Wrapper>
      <LocaleProvider>
        <div>
          <Table
            id="history-access-table"
            columns={columns}
            dataSource={data}
            pagination={
              pagination?.totalCount < 20
                ? false
                : {
                    pageSize: pagination?.pageSize,
                    total: pagination.totalCount,
                    defaultCurrent: 1,
                    showSizeChanger: true,
                    onChange: handleOnChangePagination,
                    pageSizeOptions: ["20", "30", "40"],
                  }
            }
            loading={loading}
          />
        </div>
      </LocaleProvider>
    </Wrapper>
  );
};

export default TableHistoryAccess;
