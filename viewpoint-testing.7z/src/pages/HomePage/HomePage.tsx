import { Icon } from "@components";
import type { Domain, IDataBodyFilterLog, User } from "@models/model";
import HistoryAccessAPI from "@services/historyAccessAPI";
import {
  DEFAULT_PAGINATION,
  FILTER_TIME,
  OWNED,
  TYPE_FILTER_LOG,
} from "@utils/constants";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { Space, Typography } from "antd";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import CommonAction from "./components/CommonAction/CommonAction";
import TableHistoryAccess from "./components/TableHistoryAccess/TableHistoryAccess";
import { Wrapper } from "./HomePage.Styled";
const { Paragraph } = Typography;

export type HistoryAccessItem = {
  name: string;
  type: string;
  lastOpenedTime: string;
  user: User;
  domain: Domain;
  id: string;
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
  isDeleted: boolean;
  key: string;
  icon: any;
  domainName: string;
  userName: string;
  commonId: string;
};

const HomePage = () => {
  const { t } = useTranslation(["common", "validate"]);
  const [data, setData] = useState<HistoryAccessItem[]>([]);
  const [pagination, setPagination] = useState(DEFAULT_PAGINATION);
  const [loading, setLoading] = useState(false);
  const [loadingSearch, setLoadingSearch] = useState(false);
  const [contentSearch, setContentSearch] = useState("");
  const [filter, setFilter] = useState({
    lastOpenedTimeRange: FILTER_TIME.NO_TIME,
    domain: "",
    type: "",
    owner: OWNED.NOT_FILTER,
  });
  const [errorSearch, setErrorSearch] = useState("");

  const handleChangeFilter = (typeChange, value) => {
    const tempVar = { ...filter };
    switch (typeChange) {
      case "Owner":
        tempVar.owner = value;
        break;
      case "TypeFile":
        tempVar.type = value;
        break;
      case "Domain":
        tempVar.domain = value;
        break;
      case "LastOpenedTime":
        tempVar.lastOpenedTimeRange = value;
        break;
      default:
        tempVar.owner = value;
        break;
    }
    setFilter(tempVar);
  };

  const handleCallAPI = async (paginationProps?) => {
    try {
      setLoading(true);
      const dataBody: IDataBodyFilterLog = {
        pageNumber: !paginationProps
          ? pagination?.currentPage
          : paginationProps?.currentPage,
        pageSize: !paginationProps
          ? pagination?.pageSize
          : paginationProps?.pageSize,
        type: 2,
      };
      if (contentSearch) {
        setLoadingSearch(true);
        dataBody.text = contentSearch.trim();
      }
      if (filter.type) {
        dataBody.type = filter.type;
      }
      if (filter.owner) {
        dataBody.owner = filter.owner;
      }
      if (filter.lastOpenedTimeRange) {
        dataBody.time = filter.lastOpenedTimeRange;
      }
      const response = await HistoryAccessAPI.filterLogs(dataBody);

      setPagination({
        ...response.metaData,
      });
      const convertedData = response.data;
      for (let index = 0; index < convertedData.length; index++) {
        const element = convertedData[index];
        const target =
          element.type === TYPE_FILTER_LOG.PRODUCT
            ? element?.product?.[0]
            : element?.viewPointCollections?.[0];
        convertedData[index] = {
          ...convertedData[index],
          key: element.id,
          updatedAt: element?.updatedAt
            ? new Date(element?.createdAt).toLocaleString()
            : new Date(element?.updatedAt).toLocaleString(),
          lastOpenedTime: new Date(element?.lastOpenedTime).toLocaleString(),
          icon: (
            <Icon isProductIcon={element.type === TYPE_FILTER_LOG.PRODUCT} />
          ),
          name: target ? JSON.parse(target?.detail)?.Name : "No name",
          domainName:
            target && target?.domains.length !== 0
              ? target?.domains.map((e, i) => {
                  if (i == target?.domains?.length - 1) {
                    return JSON.parse(e?.detail)?.Name + " ";
                  } else {
                    return JSON.parse(e?.detail)?.Name + ", ";
                  }
                })
              : "No Domain Name",
          userName: element?.user?.account,
        };
      }
      setData(
        convertedData.sort((a: any, b: any) => {
          return (
            (new Date(b?.lastOpenedTime) as any) -
            (new Date(a?.lastOpenedTime) as any)
          );
        })
      );
    } catch (error) {
    } finally {
      setLoading(false);
      setLoadingSearch(false);
    }
  };

  useEffect(() => {
    handleCallAPI();
  }, [contentSearch, filter]);

  const onSearch = (value) => {
    if (checkContainsSpecialCharacter(value.trim())) {
      setErrorSearch(t("validate:string_not_contains_special_characters"));
    } else {
      setErrorSearch("");
      setContentSearch(value);
    }
  };

  return (
    <div>
      <Wrapper>
        <div
          style={{
            fontSize: "1.5rem",
            fontWeight: "600",
            color: "var(--clr-text)",
          }}
        >
          {t("common:your_history_access")}
        </div>
        <div>
          <Space>
            <Icon />
            <Paragraph className="note">{t("common:product")}</Paragraph>
          </Space>
          <Space>
            <Icon isProductIcon={false} />
            <Paragraph className="note">
              {t("common:viewpoint_collection")}
            </Paragraph>
          </Space>
        </div>
      </Wrapper>

      <CommonAction
        errorSearch={errorSearch}
        onSearch={onSearch}
        loading={loadingSearch}
        handleChangeFilter={handleChangeFilter}
      />
      <TableHistoryAccess
        data={data}
        loading={loading}
        pagination={pagination}
        setPagination={setPagination}
        handleCallAPI={handleCallAPI}
      />
    </div>
  );
};

export default HomePage;
