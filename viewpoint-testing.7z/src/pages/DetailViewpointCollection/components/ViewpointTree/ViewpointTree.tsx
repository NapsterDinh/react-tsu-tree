import { DataTreeNode } from "@models/type";
import { MAX_LEVEL_TREE } from "@utils/constants";
import {
  deepCopy,
  deleteMultiObjectByListObject,
  expandedKeysWithLevel,
} from "@utils/helpersUtils";
import {
  showErrorNotification,
  showInfoNotification,
} from "@utils/notificationUtils";
import { Tree } from "antd";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import ViewpointTreeNode from "../ViewpointTreeNode/ViewpointTreeNode";
import { Wrapper } from "./ViewpointTreeStyle";

type TreeData = {
  children: any[]; //get ID, order item
  flatDataList: any[]; // only get title to validate title
};

type TreeComponentProps = {
  dataObjectTree: TreeData;
  setDataObjectTree: (any) => void;
  handleDeleteNodeAPI: (any) => Promise<boolean>;
  handleDragDropAPI: (
    dragParentKey: React.Key,
    targetKey: React.Key,
    dropParentKey: React.Key,
    previousNodeAfterDropKey: React.Key
  ) => Promise<boolean>;
  handleSaveNodeAPI: (key: React.Key, content: string) => Promise<boolean>;
  handleAddChildAPI: (any) => Promise<React.Key>;
  handleOnSelectNode: (any) => void;
  selectedNode: any;
  setSelectedNode: (any) => void;
  isCheckTitleExisted?: boolean;
  searchValue: string;
  setSearchValue: (string) => void;
  levelShow: number;
  defaultNewTreeNode: any;
};

const ViewpointTree: React.FC<TreeComponentProps> = ({
  dataObjectTree,
  setDataObjectTree,
  handleDeleteNodeAPI,
  handleDragDropAPI,
  handleSaveNodeAPI,
  handleOnSelectNode,
  setSelectedNode,
  handleAddChildAPI,
  isCheckTitleExisted = false,
  searchValue,
  setSearchValue,
  levelShow,
  defaultNewTreeNode,
}) => {
  const { t } = useTranslation(["common", "responseMessage"]);
  const [error, setError] = useState("");
  const [isSelectable, setIsSelectable] = useState<boolean>(true);
  const [expandedKeys, setExpandedKeys] = useState<React.Key[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);
  const [autoExpandParent, setAutoExpandParent] = useState<boolean>(true);
  const [nodeEditing, setNodeEditing] = useState(null);
  const [prevNodeEditing, setPrevNodeEditing] = useState(null); //only save mock node
  const [currentContentEditing, setCurrentContentEditing] = useState("");
  const customSetNodeEditing = (newNodeEditing) => {
    typeof nodeEditing?.key === "number"
      ? setPrevNodeEditing(nodeEditing)
      : setPrevNodeEditing(null);

    setNodeEditing(newNodeEditing);
  };

  const handleDropNode = async (info) => {
    if (nodeEditing) {
      return;
    }
    setSelectedKeys([]);
    setSelectedNode(null);
    const typeDragNode = info.dragNode.type;
    const typeDropNode = info.node.type;
    if (typeDragNode === typeDropNode) {
      const dropKey = info.node.key;
      const dragKey = info.dragNode.key;
      const dropPos = info.node.pos.split("-");
      const dropPosition =
        info.dropPosition - Number(dropPos[dropPos.length - 1]);

      const loop = (data, key: React.Key, callback) => {
        for (let i = 0; i < data.length; i++) {
          if (data[i].key === key) {
            return callback(data[i], i, data);
          }

          if (data[i].children) {
            loop(data[i].children, key, callback);
          }
        }
      };

      const data = [...dataObjectTree.children]; // Find dragObject
      let dragObj;
      loop(data, dragKey, (item, index, arr) => {
        arr.splice(index, 1);
        dragObj = item;
      });

      if (!info.dropToGap) {
        // Drop on the content
        loop(data, dropKey, async (item) => {
          item.children = item.children || [];
          item.children.unshift({
            ...dragObj,
            parentKey: dropKey,
          });
          try {
            await handleDragDropAPI(
              dragObj.parentKey,
              dragObj.key,
              dropKey,
              null
            );
          } catch (error) {
            showErrorNotification(t(`responseMessage:${error?.code}`));
          }
        });
      } else if (
        (info.node.props.children || []).length > 0 &&
        info.node.props.expanded &&
        dropPosition === 1
      ) {
        loop(data, dropKey, async (item) => {
          item.children = item.children || [];
          for (let index = 0; index < item.children.length; index++) {
            const element = item.children[index];
            if (element?.parentKey !== dragObj?.parentKey) {
              dragObj.parentKey = element?.parentKey;
              break;
            }
          }
          item.children.unshift(dragObj);
          try {
            await handleDragDropAPI(
              dragObj.parentKey,
              dragObj.key,
              dropKey,
              null
            );
          } catch (error) {
            showErrorNotification(t(`responseMessage:${error?.code}`));
          }
        });
      } else {
        let ar = [];
        let i;
        loop(data, dropKey, (_item, index, arr) => {
          ar = arr;
          i = index;
        });
        for (let index = 0; index < ar.length; index++) {
          const element = ar[index];
          if (element?.parentKey !== dragObj?.parentKey) {
            dragObj.parentKey = element?.parentKey;
            break;
          }
        }
        const dropParentKey = ar[ar.length - 1].parentKey;
        const previousNodeAfterDropKey = ar[i].key;
        if (dropPosition === -1) {
          ar.splice(i, 0, dragObj);
        } else {
          ar.splice(i + 1, 0, dragObj);
        }

        try {
          await handleDragDropAPI(
            dragObj.parentKey,
            dragObj.key,
            dropParentKey,
            previousNodeAfterDropKey
          );
        } catch (error) {
          showErrorNotification(t(`responseMessage:${error?.code}`));
        }
      }
      setDataObjectTree({
        ...dataObjectTree,
        children: data,
      });
    } else {
      showErrorNotification(t("common:can_not_drag_node"));
    }
  };

  const onDelete = async (node) => {
    if (node) {
      const previousData = deepCopy(dataObjectTree);
      if (typeof node.key === "string") {
        const isSuccess = await handleDeleteNodeAPI(node);
        if (!isSuccess) {
          setDataObjectTree(previousData);
          return;
        }
      }
      const temp = deepCopy(previousData?.children);
      deleteNode(node?.key, temp);
      const tempFlat = deleteMultiObjectByListObject(
        previousData?.flatDataList,
        [node?.key]
      );

      setDataObjectTree({
        children: temp,
        flatDataList: tempFlat,
      });
    }
  };

  const deleteNode = (key, data) => {
    return data.map((item, index) => {
      if (item.key === key) {
        data.splice(index, 1);
        return;
      } else {
        if (item.children) {
          deleteNode(key, item.children);
        }
      }
    });
  };

  const onSave = async (node) => {
    const previousData = deepCopy(dataObjectTree);
    let newFlattenedData = [];
    const result = deepCopy(previousData.children);
    if (node?.title !== currentContentEditing?.trim()) {
      if (typeof node?.key === "string") {
        const isSuccess = await handleSaveNodeAPI(
          node.key,
          currentContentEditing
        );
        if (!isSuccess) {
          setDataObjectTree(previousData);
        } else {
          saveNode(result, node.key, currentContentEditing);
          newFlattenedData = deepCopy(dataObjectTree.flatDataList).map(
            (item) => {
              if (item.key === node.key)
                return { ...node, title: currentContentEditing };
              return item;
            }
          );
          setDataObjectTree({
            children: result,
            flatDataList: newFlattenedData,
          });
          customSetNodeEditing(null);
        }
      } else {
        const newKey: React.Key = await handleAddChildAPI(node);
        if (newKey) {
          saveNode(result, node.key, currentContentEditing, newKey);
          newFlattenedData = deepCopy(dataObjectTree.flatDataList).map(
            (item) => {
              if (item.key === node.key)
                return { ...node, title: currentContentEditing, key: newKey };
              return item;
            }
          );

          onAdd(node?.parentKey, {
            children: result,
            flatDataList: newFlattenedData,
          });
        } else {
          onDelete(node);
        }
      }
    }
    setIsSelectable(true); // set value allows to select nodes on the tree
    setSelectedNode(null);
    setSelectedKeys([]);
    return {
      children: result,
      flatDataList: newFlattenedData,
    };
  };

  const saveNode = (data, key, content, newKey?) => {
    return data.map((item, index: number) => {
      if (item.key === key) {
        data.splice(index, 1, {
          ...item,
          title: content,
          viewDetail: {
            //custom by requirement
            ...item.viewDetail,
            viewpointDetail: content,
          },
          key: newKey ?? key,
        });
      }
      if (item.children) {
        saveNode(item.children, key, content, newKey);
      }
    });
  };

  const onAdd = async (key: React.Key, node?: any, savedData?: TreeData) => {
    const arrLevel = node?.path.split("/");
    if (arrLevel.length === MAX_LEVEL_TREE - 1) {
      //warning
      showInfoNotification(t("common:node_is_max_level"));
    }
    if (arrLevel.length === MAX_LEVEL_TREE) {
      //prevent add new child and show error message
      showErrorNotification(
        t("common:can_not_add_new_child_over_max_level_tree")
      );
      return;
    }
    const clonedObjectData = deepCopy(dataObjectTree);
    let clonedChildren = deepCopy(clonedObjectData.children);
    let clonedFlatList = deepCopy(clonedObjectData.flatDataList);

    if (nodeEditing) {
      if (typeof nodeEditing?.key === "string") {
        //real node -> edit real node
        //save data
        const { children, flatDataList } = await onSave(nodeEditing);
        clonedChildren = deepCopy(children);
        clonedFlatList = deepCopy(flatDataList);
      } else {
        if (nodeEditing?.parentKey !== key) {
          //current has mock node but click add mock node on another branch
          //delete old mock node and create new mock node on new position
          deleteNode(nodeEditing?.key, clonedChildren);
          deleteMultiObjectByListObject(clonedFlatList, [nodeEditing?.key]);
          // console.log(dataObjectTree.children, dataObjectTree.flatDataList);
        } else {
          //save current mock node on branch
          //and create new mock node after this
          if (savedData) {
            (clonedChildren = savedData.children),
              (clonedFlatList = savedData.flatDataList);
          } else {
            //same level in branch
            return;
          }
        }
      }
    }
    //create new mock node
    addNode(key, clonedChildren);

    setDataObjectTree({
      children: clonedChildren,
      flatDataList: clonedFlatList,
    });

    const newExpandedKeys = [...expandedKeys];
    newExpandedKeys.push(key);
    handleExpand(newExpandedKeys);
  };

  const addNode = (key, data) => {
    data.map((item) => {
      if (item.key === key) {
        const randomKey = Math.random();
        const newNode: DataTreeNode = {
          ...defaultNewTreeNode,
          key: randomKey,
          parentKey: key,
          title: "",
          children: [],
          path: item.path + "/" + randomKey,
        };
        if (!item.children) {
          item.children = [];
        }
        item.children.push(newNode);
        customSetNodeEditing(newNode);
        return newNode;
      }
      if (item.children) {
        addNode(key, item.children);
      }
    });
  };

  const handleSelect = (selectedKeys: React.Key[], e) => {
    setSelectedKeys(selectedKeys);
    handleOnSelectNode(e);
    setSelectedNode(e.node);
  };

  const handleExpand = (newExpandedKeys: React.Key[]) => {
    setExpandedKeys(newExpandedKeys);
    setAutoExpandParent(false);
  };

  // cancel input editing
  const handleCancel = (e: React.MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    // check if current node is mock node
    if (nodeEditing && typeof nodeEditing.key === "number") {
      onDelete(nodeEditing); //delete mock node
    }
    customSetNodeEditing(null); // set mock node to null
    setIsSelectable(true); // set value allows to select another node in the tree
    setError(""); // set empty error
  };

  // search tree
  const handleChangeSearchInput = (searchValue: string) => {
    const newExpandedKeys = deepCopy(dataObjectTree.flatDataList)
      .map((item) => {
        if (item.title.toLowerCase().indexOf(searchValue.toLowerCase()) > -1) {
          return item.parentKey;
        }
        return null;
      })
      .filter(
        (item, i, self) =>
          item &&
          item !== "00000000-0000-0000-0000-000000000000" &&
          self.indexOf(item) === i
      );
    setExpandedKeys(newExpandedKeys as React.Key[]);
    setSearchValue(searchValue);
    setAutoExpandParent(true);
  }; // change input search value

  const handleChangeSearchInputSelectLevel = (value) => {
    //-1: show full
    const updatedData = [];
    const clonedData = deepCopy(dataObjectTree.children);
    if (value == -1) {
      expandedKeysWithLevel(clonedData, Infinity, updatedData);
    } else {
      expandedKeysWithLevel(clonedData, value, updatedData);
    }
    setExpandedKeys(updatedData);
  };

  React.useEffect(() => {
    handleChangeSearchInputSelectLevel(levelShow);
  }, [levelShow]);

  React.useEffect(() => {
    handleChangeSearchInput(searchValue);
  }, [searchValue]);

  console.log(dataObjectTree);

  return (
    <Wrapper id="tree-data">
      <Tree
        defaultExpandAll
        blockNode
        selectable={isSelectable}
        expandedKeys={expandedKeys}
        autoExpandParent={autoExpandParent}
        onExpand={handleExpand}
        selectedKeys={selectedKeys}
        onDragStart={() => handleOnSelectNode(null)}
        draggable
        onSelect={handleSelect}
        treeData={dataObjectTree?.children}
        onDrop={handleDropNode}
        titleRender={(node: any) => (
          <ViewpointTreeNode
            data={dataObjectTree}
            nodeEditing={nodeEditing}
            setNodeEditing={customSetNodeEditing}
            onSetIsSelectable={setIsSelectable}
            node={node}
            onAdd={onAdd}
            onSave={onSave}
            onDelete={onDelete}
            setError={setError}
            error={error}
            onCancel={handleCancel}
            searchValue={searchValue}
            isCheckTitleExisted={isCheckTitleExisted}
            setCurrentContentEditing={setCurrentContentEditing}
          />
        )}
      />
    </Wrapper>
  );
};

export default ViewpointTree;
