import styled from "styled-components";

export const Wrapper = styled.div`
  &&& {
    .ant-tree,
    .ant-tree-show-line .ant-tree-switcher {
      background-color: var(--background-color-element);
      color: var(--clr-text);
      transition: all ease-in-out 0.2s;
    }

    .ant-tree .ant-tree-treenode {
      align-items: center;
    }

    .ant-tree-switcher {
      align-self: unset;
    }

    .ant-tree .ant-tree-node-content-wrapper:hover {
      background-color: rgba(0, 0, 0, 0.1);
    }

    .ant-tree .ant-tree-node-content-wrapper.ant-tree-node-selected {
      background-color: var(--background-color-selected-node-tree);
    }

    .ant-tree .ant-tree-treenode-draggable .ant-tree-draggable-icon {
      cursor: grab;
    }
  }
`;
