import { DataTreeNode } from "@models/type";
import { MAX_LEVEL_TREE } from "@utils/constants";
import {
  checkContainsSpecialCharacter,
  deepCopy,
  generateList,
  removeEmoji,
} from "@utils/helpersUtils";
import { showErrorNotification } from "@utils/notificationUtils";
import { Button, Input, Modal, Space, Tag, Tooltip } from "antd";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  AiOutlineDelete,
  AiOutlineEdit,
  AiOutlinePlusCircle,
} from "react-icons/ai";
import { Wrapper } from "./ViewpointTreeNodeStyle";

const ViewpointTreeNode = ({
  data,
  searchValue,
  node,
  onDelete,
  onSave,
  onAdd,
  nodeEditing,
  setNodeEditing,
  onSetIsSelectable,
  onCancel,
  isCheckTitleExisted,
  setError,
  error,
  setCurrentContentEditing,
}) => {
  const { t } = useTranslation(["common", "responseMessage"]);
  const [content, setContent] = useState(node?.title); // content input
  const [contentSearch, setContentSearch] = useState(node?.titleSearch); // content show when search value has value
  const handleShowDeleteConfirm = () => {
    setNodeEditing(null);
    Modal.confirm({
      title: t("common:delete_viewpoint"),
      content: t("common:confirm_delete_viewpoint"),
      cancelText: t("common:cancel"),
      okText: t("common:delete"),
      onOk: () => onDelete(node),
    });
  };

  // validate input
  const handleCheckErrors = (contentInput: string) => {
    // check the input content is empty
    if (!contentInput) {
      setError(t("validate:edit_input_tree"));
      return true;
    }
    // check the input content contains special character

    if (
      checkContainsSpecialCharacter(contentInput.trim()) ||
      removeEmoji(contentInput)
    ) {
      setError(t("validate:edit_input_tree_contains_special_character"));
      return true;
    }
    if (isCheckTitleExisted) {
      // check if the input content is the same as other
      if (
        deepCopy(data?.flatDataList)
          .filter((item: DataTreeNode) => item.key !== node.key)
          .some(
            (item: DataTreeNode) =>
              item.title.toLowerCase() === contentInput.toLowerCase()
          )
      ) {
        setError(t("validate:edit_input_tree_same_name"));
        return true;
      }
    }

    setError("");
    return false;
  };

  // double click content to show input
  const handleOnClick = (e: any) => {
    e.preventDefault();
    if (e.detail === 2) {
      if (nodeEditing && typeof nodeEditing.key === "number") {
        onDelete(nodeEditing);
      }
      setNodeEditing(node);
    }
    setError(""); // set empty error
  };

  // set keyboard shortcut event
  const handleOnKeyDown = (e: any) => {
    // keyboard Enter
    if (e.key === "Enter") {
      handleSaveDataNode(e); // save updated node
    }
    // keyboard Escape
    if (e.keyCode === 27) {
      onCancel(e); // cancel input
    }
  };

  // save node
  const handleSaveDataNode = async (e: any) => {
    e.stopPropagation();
    if (handleCheckErrors(content)) {
      return;
    }
    // check the input content has changed or not error
    try {
      await onSave(node, content, (newKey, contentValue) => {
        node.key = newKey;
        node.title = contentValue;
        // setContent(contentValue);
      });
    } catch (error) {
    } finally {
      if (typeof node?.key !== "string") {
        onSetIsSelectable(true); // set value allows to select nodes on the tree
      }
    }
    // check search value has value
    if (searchValue) {
      handleChangeTitle(node.title); // change the content of titleSearch in data
    } else {
      setContentSearch(null); // set empty content search
    }
  };

  // handle change title in data of node
  const handleChangeTitle = (newContent: string) => {
    const strTitle = newContent.toLowerCase();
    const indexTitle = strTitle.indexOf(searchValue.toLowerCase());
    const beforeStr = newContent.substring(0, indexTitle);
    const afterStr = newContent.substring(indexTitle + searchValue.length);
    const newTitle = indexTitle > -1 && (
      <span>
        {beforeStr}
        <span className="site-tree-search-value">
          {newContent.substring(indexTitle, indexTitle + searchValue.length)}
        </span>
        {afterStr}
      </span>
    );
    setContentSearch(newTitle); // set new content with search value
  };

  // count number element of node
  const handleCountNumberChildTreeNode = useMemo(() => {
    const flattenedDataNode = [];
    generateList(node.children, flattenedDataNode);
    return flattenedDataNode.length;
  }, [data.children, node, node.children]);

  // set content show when search value changed
  useEffect(() => {
    if (searchValue) {
      handleChangeTitle(content.trim());
    } else {
      setContentSearch(null);
    }
  }, [searchValue]);

  useEffect(() => {
    if (error !== "") {
      if (typeof node.key === "number") {
        onDelete(node);
      } else {
        setError(""); // set empty error
      }
    }
  }, [nodeEditing]);

  // render
  if (nodeEditing?.key === node.key) {
    return (
      <Wrapper>
        <Space
          style={{
            width: "100%",
            justifyContent: "space-between",
          }}
        >
          <Tooltip title={error} visible={error ? true : false} color="#ff4d4f">
            <Input
              // onBlurCapture={(e) => {
              //   if (!error) {
              //     handleSaveDataNode(e);
              //   }
              // }}
              autoFocus
              onChange={(e) => {
                setContent(e.target.value.trim());
                setCurrentContentEditing(e.target.value.trim());
              }}
              value={content}
              status={error ? "error" : ""}
              onKeyDown={handleOnKeyDown}
              width={100}
            />
          </Tooltip>
          <Space>
            <Button
              type="primary"
              size="small"
              onClick={(e) => {
                if (!error) {
                  handleSaveDataNode(e);
                }
              }}
            >
              {t("common:save")} [Enter]
            </Button>
            <Button size="small" onClick={onCancel}>
              {t("common:cancel")} [ESC]
            </Button>
          </Space>
        </Space>
      </Wrapper>
    );
  } else {
    return (
      <Wrapper>
        <div className="custom-tree-node">
          <Space direction="horizontal">
            <div onClick={handleOnClick} className="custom-tree-node__title">
              {contentSearch && contentSearch !== 0 ? contentSearch : content}
            </div>
            {node.children && handleCountNumberChildTreeNode !== 0 && (
              <Tag color="#87d068" style={{ fontSize: "0.75rem" }}>
                {handleCountNumberChildTreeNode}
              </Tag>
            )}
          </Space>
          <div className="option-tree-node">
            <div className="option-tree-node-btn add">
              <AiOutlinePlusCircle
                onClick={(e) => {
                  e.stopPropagation();
                  onAdd(node?.key, node);
                }}
              />
            </div>
            <div className="option-tree-node-btn edit">
              <AiOutlineEdit
                onClick={(e) => {
                  e.stopPropagation();
                  onSetIsSelectable(false);
                  if (nodeEditing && typeof nodeEditing.key === "number") {
                    onDelete(nodeEditing);
                  }
                  setNodeEditing(node);
                }}
              />
            </div>
            <div className="option-tree-node-btn delete">
              <AiOutlineDelete
                onClick={(e) => {
                  e.stopPropagation();
                  handleShowDeleteConfirm();
                }}
              />
            </div>
          </div>
        </div>
      </Wrapper>
    );
  }
};

export default ViewpointTreeNode;
