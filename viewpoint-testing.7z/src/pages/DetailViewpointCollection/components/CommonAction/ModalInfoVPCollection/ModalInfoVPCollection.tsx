import { STATUS_VIEWPOINT_COLLECTION } from "@utils/constants";
import { Button, Descriptions, Modal } from "antd";
import React from "react";
import { useTranslation } from "react-i18next";

interface IProps {
  visible: boolean;
  onCancel: () => void;
  currentVPCollection: any;
}

const ModalInfoVPCollection = ({
  visible,
  onCancel,
  currentVPCollection,
}: IProps) => {
  const { t } = useTranslation(["common"]);
  return (
    <Modal
      title={t("common:viewpoint_detail")}
      visible={visible}
      onCancel={onCancel}
      width={800}
      footer={[
        <Button key="ok" type="primary" onClick={onCancel}>
          {t("common:ok")}
        </Button>,
      ]}
    >
      <Descriptions title={currentVPCollection?.detail?.name} layout="vertical">
        <Descriptions.Item label={t("common:create_by")}>
          {currentVPCollection?.user?.account}
        </Descriptions.Item>
        <Descriptions.Item label={t("common:status")}>
          {currentVPCollection?.status ===
            STATUS_VIEWPOINT_COLLECTION.ON_GOING && t("common:on_going")}
          {currentVPCollection?.status ===
            STATUS_VIEWPOINT_COLLECTION.PUBlISH && t("common:publish")}
          {currentVPCollection?.status ===
            STATUS_VIEWPOINT_COLLECTION.PRIVATE && t("common:private")}
        </Descriptions.Item>
        <Descriptions.Item label={t("common:date_created")}>
          {new Date(currentVPCollection?.createdAt).toLocaleString()}
        </Descriptions.Item>
        <Descriptions.Item label="Domain">Automative</Descriptions.Item>
        <Descriptions.Item label={t("common:last_modified_by")}>
          ThienNTM
        </Descriptions.Item>
        <Descriptions.Item label={t("common:last_updated")}>
          {new Date(currentVPCollection?.updatedAt).toLocaleString()}
        </Descriptions.Item>
        <Descriptions.Item label={t("common:clone_from")}>
          {currentVPCollection?.cloneCollectionId}
        </Descriptions.Item>
      </Descriptions>
    </Modal>
  );
};

export default ModalInfoVPCollection;
