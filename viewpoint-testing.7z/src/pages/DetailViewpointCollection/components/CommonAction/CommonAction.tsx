import {
  CopyOutlined,
  DownloadOutlined,
  ExclamationCircleOutlined,
  ExportOutlined,
  GlobalOutlined,
  ImportOutlined,
  InfoCircleOutlined,
  SaveOutlined,
  StarOutlined,
  PlusCircleOutlined,
} from "@ant-design/icons";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import { STATUS_VIEWPOINT_COLLECTION } from "@utils/constants";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import {
  Button,
  Input,
  Modal,
  Select,
  Space,
  Tag,
  Tooltip,
  Typography,
} from "antd";
import { AiOutlineEdit, AiOutlineStar } from "react-icons/ai";
import { SearchContainer } from "AppStyled";
import * as React from "react";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { routes } from "routes";
import { Wrapper } from "./CommonAction.Styled";
import ModalImportVPCollection from "./ModalImportVPCollection/ModalImportVPCollection";
import ModalInfoVPCollection from "./ModalInfoVPCollection/ModalInfoVPCollection";
import ModalEditVPCollection from "./ModalEditVPCollection/ModalEditVPCollection";
import ModalClone from "./ModalClone/ModalClone";
import ModalRatingVPCollection from "./ModalRatingVPCollection/ModalRatingVPCollection";
import ModalCreateRequest from "./ModalCreateRequest/ModalCreateRequest";
import { debounce } from "@utils/helpersUtils";

const { Search } = Input;
const { Option } = Select;

export type CommonActionProps = {
  currentVPCollection: any;
  getData: () => void;
  setCurrentVPCollection: (any) => void;
  setSearchText: (string) => void;
  setLevelShow: (number) => void;
};

const CommonAction: React.FC<CommonActionProps> = ({
  currentVPCollection,
  getData,
  setCurrentVPCollection,
  setSearchText,
  setLevelShow,
}) => {
  const { t } = useTranslation(["common", "validate", "responseMessage"]); // languages
  const [isShowInfoModal, setShowInfoModal] = useState(false);
  const [isShowImportModal, setShowImportModal] = useState(false);
  const [isShowEditModal, setIsShowEditModal] = useState(false);
  const [isShowCloneModal, setShowCloneModal] = useState(false);
  const [isShowRatingModal, setShowRatingModal] = useState(false);
  const [isShowCreateRequestModal, setShowCreateRequestModal] = useState(false);
  const user = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : null;

  const navigate = useNavigate();

  const handleExport = async () => {
    try {
      await viewpointCollectionAPI.exportViewpointCollection(
        currentVPCollection?.id
      );
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error?.code}`));
    }
  };

  const handlePublish = () => {
    Modal.confirm({
      title: t("common:confirm_publish"),
      icon: <ExclamationCircleOutlined />,
      width: 700,
      content: (
        <>
          <p>{t("common:confirm_publish_1")}</p>
          <p>{t("common:confirm_publish_2")}</p>
        </>
      ),
      okText: t("common:publish"),
      cancelText: t("common:cancel"),
      onOk: async () => {
        try {
          await viewpointCollectionAPI.updateStatus(
            currentVPCollection?.id,
            STATUS_VIEWPOINT_COLLECTION.PUBlISH,
            STATUS_VIEWPOINT_COLLECTION.PUBlISH
          );
          setCurrentVPCollection({
            ...currentVPCollection,
            status: STATUS_VIEWPOINT_COLLECTION.PUBlISH,
          });
          showSuccessNotification(t("common:change_is_active_success"));
        } catch (error) {
          showErrorNotification(t(`responseMessage:${error?.code}`));
        } finally {
        }
      },
    });
  };
  const checkOwner = () => {
    return currentVPCollection?.user?.id === user?.id;
  };

  return (
    <Wrapper>
      <Space
        align="end"
        style={{
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center" }}>
            <Typography.Title
              level={1}
              style={{
                fontSize: "1.5rem",
                marginTop: "20px",
                fontWeight: "600",
                color: "var(--clr-text)",
                display: "block",
                overflow: "hidden",
                textOverflow: "ellipsis",
                maxWidth: "600px",
                whiteSpace: "nowrap",
              }}
            >
              {currentVPCollection?.detail?.name ??
                "No Viewpoint collection name"}
            </Typography.Title>
            {checkOwner() && (
              <Tooltip title={t("common:edit")}>
                <AiOutlineEdit
                  onClick={() => setIsShowEditModal(true)}
                  style={{
                    fontSize: "1.55rem",
                    transform: "translateY(3px)",
                    cursor: "pointer",
                  }}
                />
              </Tooltip>
            )}

            {!currentVPCollection?.cloneCollectionId && (
              <Tooltip title={t("common:base")}>
                <Tag
                  style={{
                    height: "fit-content",
                    marginLeft: "20px",
                    transform: "translateY(2px)",
                    color: "white",
                  }}
                  color="#87d068"
                >
                  {t("common:base")}
                </Tag>
              </Tooltip>
            )}
          </div>
          <Space size={20} align="start">
            <Space direction="vertical">
              <span className="label">{t("common:search")}</span>
              <SearchContainer>
                <Search
                  maxLength={20}
                  placeholder={t("common:enter_search_text")}
                  onChange={(e) => {
                    const debounceSearch = debounce(
                      () => setSearchText(e.target.value.trim()),
                      1000
                    );
                    debounceSearch();
                  }}
                  enterButton={t("common:search")}
                />
              </SearchContainer>
            </Space>
            <Space direction="vertical">
              <span className="label">{t("common:domain_level")}</span>
              <Select
                onChange={setLevelShow}
                defaultValue="-1"
                style={{ width: 150 }}
              >
                <Option value="-1">{t("common:all_level")}</Option>
                <Option value="1">{`${t("common:domain_level")} 1`}</Option>
                <Option value="2">{`${t("common:domain_level")} 2`}</Option>
                <Option value="3">{`${t("common:domain_level")} 3`}</Option>
                <Option value="4">{`${t("common:domain_level")} 4`}</Option>
                <Option value="5">{`${t("common:domain_level")} 5`}</Option>
                <Option value="6">{`${t("common:domain_level")} 6`}</Option>
                <Option value="7">{`${t("common:domain_level")} 7`}</Option>
              </Select>
            </Space>
          </Space>
        </div>

        <div className="right-action-container">
          <div style={{ display: "flex", justifyContent: "right" }}>
            <Tag className="tag-rating" color="#f50">
              {currentVPCollection?.avgRating ? (
                <div>
                  <span>{t("common:rating")}: </span>
                  <span>{currentVPCollection?.avgRating}</span>
                  <AiOutlineStar
                    style={{
                      transform: "translate(4px, 3px)",
                      fontSize: "16px",
                    }}
                  />
                </div>
              ) : (
                t("common:not_rating")
              )}
            </Tag>
            {currentVPCollection?.status ===
              STATUS_VIEWPOINT_COLLECTION.ON_GOING && (
              <Tag className="tag-status" color="#87d068">
                <span>{t("common:status")}: </span>
                {t("common:on_going")}
              </Tag>
            )}
          </div>

          <div className="top-action">
            <Button
              onClick={() => navigate(routes.ViewpointCollection.path[0])}
              type="primary"
              icon={<SaveOutlined />}
            >
              {checkOwner() ? t("common:save") : t("common:cancel")}
            </Button>
            <Button
              onClick={() => setShowCreateRequestModal(true)}
              type="primary"
              icon={<PlusCircleOutlined />}
            >
              {t("common:create_merge_request")}
            </Button>
            <Button
              onClick={() => setShowRatingModal(true)}
              type="primary"
              icon={<StarOutlined />}
            >
              {t("common:rating")}
            </Button>
            {currentVPCollection?.status ===
              STATUS_VIEWPOINT_COLLECTION.ON_GOING &&
              checkOwner() && (
                <Button
                  onClick={handlePublish}
                  type="primary"
                  icon={<GlobalOutlined />}
                >
                  {t("common:publish")}
                </Button>
              )}
            <Button
              icon={<InfoCircleOutlined />}
              type="primary"
              onClick={() => setShowInfoModal(true)}
            >
              {t("common:information")}
            </Button>
          </div>
          {checkOwner() && (
            <div className="bottom-action">
              <Button
                onClick={() => setShowCloneModal(true)}
                type="primary"
                icon={<CopyOutlined />}
              >
                {t(
                  "common:viewpoint_collection_clone_other_viewpoint_collection"
                )}
              </Button>
              <Button type="primary" icon={<DownloadOutlined />}>
                {t("common:download_template_import")}
              </Button>
              <Button
                icon={<ImportOutlined />}
                type="primary"
                onClick={() => setShowImportModal(true)}
              >
                {t("common:import")}
              </Button>
              <Button
                onClick={handleExport}
                icon={<ExportOutlined />}
                type="primary"
              >
                {t("common:export")}
              </Button>
            </div>
          )}
        </div>
      </Space>

      {/* Info Modal */}
      <ModalInfoVPCollection
        visible={isShowInfoModal}
        onCancel={() => setShowInfoModal(false)}
        currentVPCollection={currentVPCollection}
      />
      <ModalImportVPCollection
        open={isShowImportModal}
        setOpen={setShowImportModal}
        currentViewpointCollection={currentVPCollection}
        getData={getData}
      />
      <ModalEditVPCollection
        open={isShowEditModal}
        setOpen={setIsShowEditModal}
        currentVPCollection={currentVPCollection}
      />
      <ModalClone
        isModalOpen={isShowCloneModal}
        setIsModalOpen={setShowCloneModal}
        getData={getData}
      />
      <ModalRatingVPCollection
        visible={isShowRatingModal}
        onCancel={() => setShowRatingModal(false)}
        currentVPCollection={currentVPCollection}
        setCurrentVPCollection={setCurrentVPCollection}
      />
      <ModalCreateRequest
        isViewpointCollection
        open={isShowCreateRequestModal}
        handleCancel={() => setShowCreateRequestModal(false)}
        item={currentVPCollection}
        isCreateRequestIndirect
      />
    </Wrapper>
  );
};

export default CommonAction;
