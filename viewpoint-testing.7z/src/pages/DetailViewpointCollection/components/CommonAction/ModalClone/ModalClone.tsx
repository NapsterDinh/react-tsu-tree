import { CloseOutlined } from "@ant-design/icons";
import { LocaleProvider } from "@components";
import { IReponseData, IResponseViewPointCollection } from "@models/model";
import { rootState } from "@models/type";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import { checkContainsSpecialCharacter, debounce } from "@utils/helpersUtils";
import {
  AutoComplete,
  Col,
  Empty,
  Form,
  Input,
  Modal,
  Row,
  Space,
  Spin,
  Tree,
  Typography,
} from "antd";
import type { SelectProps } from "antd/es/select";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

const ModalClone = ({ isModalOpen, setIsModalOpen, getData }) => {
  const [loading, setLoading] = useState(false);
  const [loadingViewpointTree, setLoadingViewpointTree] = useState(false);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);
  const { t } = useTranslation(["common", "validate", "responseMessage"]);
  const [treeData, setTreeData] = useState([]);
  const [searchContent, setSearchContent] = useState<string>("");
  const [errorSearch, setErrorSearch] = useState<string>("");
  const [options, setOptions] = useState<SelectProps<object>["options"]>([]);
  const [selectedVPCollection, setSelectedVPCollection] = useState(null);

  const searchResult = (arr) => {
    return arr.map((item) => {
      return {
        value: item?.detail?.name,
        id: item?.id,
        label: (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>{item?.detail?.name}</span>
            <span>{item?.user?.account}</span>
          </div>
        ),
      };
    });
  };

  const handleChangeSearchInput = (content: string) => {
    setSearchContent(content);
  };

  const handleSearch = async (value) => {
    if (checkContainsSpecialCharacter(value.trim())) {
      setErrorSearch(t("validate:string_not_contains_special_characters"));
    } else {
      setErrorSearch("");
      try {
        setLoading(true);
        const response = await viewpointCollectionAPI.getAllViewpointCollection(
          {
            payload: {
              search: value?.trim(),
            },
          }
        );
        setOptions(searchResult(response?.data));
      } catch (error) {
      } finally {
        setLoading(false);
      }
    }
  };

  const onSelectAutoCompleted = async (value: string, option: any) => {
    try {
      setLoadingViewpointTree(true);
      const response = await viewpointCollectionAPI.getViewpointCollectionById(
        option.id
      );
      setSelectedVPCollection(response?.data);
    } catch (error) {
    } finally {
      setLoadingViewpointTree(false);
    }
  };

  const onSelect = (selectedKeysValue: React.Key[]) => {
    setSelectedKeys(selectedKeysValue);
  };

  const handleCancelModal = () => {
    setSearchContent("");
    setErrorSearch("");
    setSelectedKeys([]);
    setSelectedVPCollection(null);
    setTreeData([]);
    setIsModalOpen(false);
  };

  useEffect(() => {
    const keys = ["domainId", "testTypeId", "viewPointCategoryId", "id"],
      temp = { children: [] };
    if (selectedVPCollection) {
      selectedVPCollection?.viewPoints.forEach(function (a) {
        return keys.reduce(function (r, k) {
          if (!r[a[k]]) {
            r[a[k]] = { children: [] };
            r.children.push({
              ["key"]: a[k],
              ["children"]: r[a[k]].children,
              // content: a,
              title:
                k === "domainId"
                  ? a.domainId
                  : k === "testTypeId"
                  ? a.testTypeId
                  : k === "viewPointCategoryId"
                  ? a.viewPointCategoryId
                  : a.viewDetail.name,
              type:
                k === "domainId"
                  ? "domain"
                  : k === "testTypeId"
                  ? "test-type"
                  : k === "viewPointCategoryId"
                  ? "category"
                  : "viewpoint",
            });
          }
          return r[a[k]];
        }, temp);
      });
      setTreeData(temp.children);
    }
  }, [selectedVPCollection]);

  return (
    <Modal
      title={t("common:clone_viewpoint")}
      visible={isModalOpen}
      onOk={() => setIsModalOpen(false)}
      onCancel={handleCancelModal}
      confirmLoading={loading}
      width={900}
      okText={t("common:clone")}
      cancelText={t("common:cancel")}
      style={{ top: 20 }}
    >
      <Space direction="vertical">
        <Space direction="vertical">
          <Typography.Text className="color-text">
            {t("common:search_vp_clone")}
          </Typography.Text>
          <AutoComplete
            dropdownMatchSelectWidth={252}
            style={{ width: 420 }}
            value={searchContent}
            options={options}
            onSelect={onSelectAutoCompleted}
            onSearch={handleSearch}
            onChange={handleChangeSearchInput}
            maxLength={40}
          >
            <Input.Search
              className="search-box"
              placeholder={t("common:enter_search_text")}
              enterButton={t("common:search")}
              loading={loading}
              status={errorSearch !== "" ? "error" : ""}
            />
          </AutoComplete>
          {errorSearch !== "" && (
            <span className="error-search">{errorSearch}</span>
          )}
        </Space>
        {selectedVPCollection && (
          <Space direction="vertical">
            <Typography.Text className="color-text">
              {t("common:your_selected_viewpoint")}
            </Typography.Text>
            <Typography.Title level={3} className="color-text">
              {selectedVPCollection?.detail?.name}
            </Typography.Title>
          </Space>
        )}
      </Space>
      <div style={{ marginTop: "10px" }}>
        <Typography.Text className="color-text">
          {t("common:detail_new_viewpoint")}
        </Typography.Text>
        <Spin spinning={loadingViewpointTree}>
          {treeData.length > 0 ? (
            <div
              style={{
                border: "1px solid #ccc",
                padding: "20px",
                marginTop: "10px",
              }}
            >
              <Tree
                checkable
                blockNode
                defaultExpandAll
                selectedKeys={selectedKeys}
                autoExpandParent={false}
                onSelect={onSelect}
                treeData={treeData}
                rootStyle={{
                  backgroundColor: "var(--background-color-element)",
                  color: "var(--clr-text)",
                }}
              />
            </div>
          ) : (
            <div
              style={{
                border: "1px solid #ccc",
                padding: "20px",
                marginTop: "10px",
                borderRadius: "var(--border-radius-element)",
              }}
            >
              <LocaleProvider>
                <Empty style={{ marginTop: "10px" }} />
              </LocaleProvider>
            </div>
          )}
        </Spin>
      </div>
    </Modal>
  );
};

export default ModalClone;
