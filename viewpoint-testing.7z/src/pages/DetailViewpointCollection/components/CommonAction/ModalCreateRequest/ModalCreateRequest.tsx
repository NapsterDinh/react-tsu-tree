import { SearchOutlined } from "@ant-design/icons";
import { yupResolver } from "@hookform/resolvers/yup";
import requestAPI from "@services/requestAPI";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import { TYPE_REQUEST } from "@utils/constants";
import {
  MAX_LENGTH_INPUT_NAME_FIELD,
  MAX_LENGTH_TEXT_AREA,
  MIN_LENGTH_INPUT,
  ROWS_DEFAULT_TEXT_AREA,
} from "@utils/constantsUI";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { showSuccessNotification } from "@utils/notificationUtils";
import {
  AutoComplete,
  Button,
  Form,
  Input,
  Modal,
  Select,
  SelectProps,
  Space,
  Tag,
  Typography,
} from "antd";
import { useEffect, useMemo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import * as yup from "yup";

const { TextArea } = Input;
const { Option } = Select;

export type ModalCategoryProps = {
  open: boolean;
  handleCancel: () => void;
  item: any;
  isCreateRequestIndirect: boolean;
  isViewpointCollection: boolean;
};
const ModalCreateRequest: React.FC<ModalCategoryProps> = ({
  open,
  handleCancel,
  item,
  isCreateRequestIndirect = true,
  isViewpointCollection = true,
}) => {
  const { t } = useTranslation(["common", "validate", "responseMessage"]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [errorSearch, setErrorSearch] = useState("");
  const [options, setOptions] = useState<SelectProps<object>["options"]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedMergeInto, setSelectedMergeInto] = useState(null);
  const schema = useMemo(
    () =>
      yup
        .object({
          type: yup
            .number()
            .required(t("validate:type_request_require"))
            .default(TYPE_REQUEST.VIEWPOINT_COLLECTION),
          approver: yup
            .string()
            // .required(t("validate:approver_request_require"))
            .default(item?.user?.id),
          from: yup
            .string()
            // .required(t("validate:from_file_require"))
            .default(item?.id),
          mergeInto: yup
            .string()
            .required(t("validate:merge_into_file_require"))
            .default(item?.cloneCollectionId ?? ""),
          title: yup
            .string()
            .required(t("validate:title_require"))
            .trim()
            .max(
              MAX_LENGTH_INPUT_NAME_FIELD,
              t("validate:title_name_max_length")
            )
            .min(MIN_LENGTH_INPUT, t("validate:title_name_min_length"))
            .test(
              "Title",
              t("validate:title_not_contains_special_characters"),
              (value) => !checkContainsSpecialCharacter(value)
            ),
          description: yup
            .string()
            .required(t("validate:description_required"))
            .trim()
            .max(MAX_LENGTH_TEXT_AREA, t("validate:description_max_length"))
            .min(MIN_LENGTH_INPUT, t("validate:description_min_length")),
        })
        .required(),
    []
  );

  const searchResult = (arr) => {
    return arr.map((item) => {
      return {
        value: item?.detail?.name,
        id: item?.id,
        label: (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>
              {item?.detail?.name}
              {item?.cloneCollectionId && (
                <Tag style={{ transform: "translateX(10px)" }} color="#87d068">
                  {t("common:base")}
                </Tag>
              )}
            </span>
            <span>{item?.user?.account}</span>
          </div>
        ),
      };
    });
  };

  const handleSearchFrom = async (value) => {
    if (value.trim() === "") {
      setOptions([]);
    }
    if (checkContainsSpecialCharacter(value.trim())) {
      setErrorSearch(t("validate:string_not_contains_special_characters"));
      setOptions([]);
    } else {
      setErrorSearch("");
      try {
        setLoading(true);
        const response = await viewpointCollectionAPI.getAllViewpointCollection(
          {
            payload: {
              search: value?.trim(),
            },
          }
        );
        setOptions(searchResult(response?.data));
      } catch (error) {
      } finally {
        setLoading(false);
      }
    }
  };

  const onSelectAutoCompleted = async (value: string, option: any) => {
    setSelectedMergeInto(item?.id);
  };

  const {
    control,
    setValue,
    handleSubmit,
    clearErrors,
    setError,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues:
      item === ""
        ? {
            type: "",
            from: item?.cloneCollectionId,
          }
        : {
            from: item?.cloneCollectionId,
            approver: item?.user?.id,
            description: "",
            type: TYPE_REQUEST.VIEWPOINT_COLLECTION,
            mergeInto: "",
            title: "",
          },
  });

  useEffect(() => {
    if (item !== "") {
      // setValue("from", item?.cloneCollectionId);
      // setValue("approver", item?.user?.id);
    }
  }, [item]);

  const onSubmit = async (values) => {
    try {
      setConfirmLoading(true);
      await requestAPI.createRequest({
        values,
        from: item?.id,
        approver: item?.user?.id,
      });
      showSuccessNotification(t("common:create_request_successfully"));
      handleCancel();
      reset();
    } catch (error) {
      setError("title", { message: t(`responseMessage:${error?.code}`) });
    } finally {
      setConfirmLoading(false);
    }
  };

  return (
    <Modal
      title={
        isCreateRequestIndirect
          ? t("common:create_merge_request")
          : t("common:edit_request")
      }
      visible={open}
      width={800}
      onCancel={() => {
        handleCancel();
        clearErrors();
        reset();
      }}
      maskClosable={false}
      footer={null}
    >
      <Form
        name="basic"
        labelAlign="left"
        labelCol={{
          span: 6,
        }}
        wrapperCol={{
          span: 17,
        }}
        onFinish={handleSubmit(onSubmit)}
        autoComplete="off"
      >
        <Form.Item
          className={errors.type && "error-message"}
          label={t("common:type") + "*"}
        >
          <Controller
            name="type"
            control={control}
            render={({ field }) => {
              return (
                <>
                  <Space direction="vertical">
                    <Select
                      disabled={isCreateRequestIndirect}
                      defaultValue={
                        isViewpointCollection
                          ? TYPE_REQUEST.VIEWPOINT_COLLECTION
                          : TYPE_REQUEST.PRODUCT
                      }
                      style={{
                        width: 200,
                      }}
                      {...field}
                    >
                      <Option value={TYPE_REQUEST.VIEWPOINT_COLLECTION}>
                        {t("common:viewpoint_collection")}
                      </Option>
                      <Option value={TYPE_REQUEST.PRODUCT}>
                        {t("common:product")}
                      </Option>
                    </Select>
                  </Space>
                </>
              );
            }}
          />
        </Form.Item>

        <Form.Item
          className={errors.title && "error-message"}
          label={t("common:title") + "*"}
        >
          <Controller
            name="title"
            control={control}
            render={({ field }) => {
              return (
                <>
                  <Input
                    {...field}
                    placeholder={t("common:enter_request_title")}
                  />
                  {errors.title && (
                    <span className="color-red">
                      {errors.title?.message as string}
                    </span>
                  )}
                </>
              );
            }}
          />
        </Form.Item>

        <Form.Item
          className={errors.description && "error-message"}
          label={t("common:description") + "*"}
        >
          <Controller
            name="description"
            control={control}
            render={({ field }) => {
              const props = {
                ...field,
              };
              return (
                <>
                  <TextArea
                    showCount
                    rows={ROWS_DEFAULT_TEXT_AREA}
                    {...field}
                    // maxLength={MAX_LENGTH_TEXT_AREA}
                    placeholder={t("common:enter_description_category")}
                  />
                  {errors.description && (
                    <span className="color-red">
                      {errors.description?.message as string}
                    </span>
                  )}
                </>
              );
            }}
          />
        </Form.Item>

        <Form.Item
          validateStatus={errors.from ? "error" : ""}
          help={errors.from?.message as string}
          label={t("common:from")}
        >
          <Controller
            name="from"
            control={control}
            render={({ field }) => {
              const props = {
                ...field,
              };
              return (
                <Space direction="vertical">
                  <AutoComplete
                    dropdownMatchSelectWidth={252}
                    style={{ width: "217%" }}
                    maxLength={40}
                    defaultValue={{ value: item?.detail?.name, id: item?.id }}
                    disabled
                    {...field}
                  >
                    <Input.Search
                      className="search-box"
                      placeholder={t("common:enter_search_text")}
                      enterButton={<SearchOutlined />}
                    />
                  </AutoComplete>
                  <Typography.Text className="color-text">
                    *{t("common:default_from_is_current_file")}
                  </Typography.Text>
                </Space>
              );
            }}
          />
        </Form.Item>
        <Form.Item
          validateStatus={errors.mergeInto ? "error" : ""}
          help={errors.mergeInto?.message as string}
          label={t("common:merge_into")}
        >
          <Controller
            name="mergeInto"
            control={control}
            render={({ field }) => {
              const props = {
                ...field,
              };
              return (
                <Space direction="vertical">
                  <AutoComplete
                    dropdownMatchSelectWidth={252}
                    style={{ width: "531px" }}
                    options={options}
                    onSelect={onSelectAutoCompleted}
                    onSearch={handleSearchFrom}
                    maxLength={40}
                    {...field}
                    status={errorSearch !== "" ? "error" : ""}
                  >
                    <Input.Search
                      className="search-box"
                      placeholder={t("common:enter_search_text")}
                      enterButton={<SearchOutlined />}
                    />
                  </AutoComplete>
                  {errorSearch !== "" && (
                    <span className="error-search">{errorSearch}</span>
                  )}
                </Space>
              );
            }}
          />
        </Form.Item>
        <Form.Item
          validateStatus={errors.approver ? "error" : ""}
          help={errors.approver?.message as string}
          label={t("common:approver")}
        >
          <Controller
            name="approver"
            control={control}
            render={({ field }) => {
              const props = {
                ...field,
              };
              return (
                <Space direction="vertical">
                  <AutoComplete
                    dropdownMatchSelectWidth={252}
                    style={{ width: "217%" }}
                    maxLength={40}
                    disabled
                    defaultValue={{
                      value: item?.user?.account,
                      id: item?.user?.id,
                    }}
                    {...field}
                  >
                    <Input.Search
                      className="search-box"
                      placeholder={t("common:enter_search_text")}
                      enterButton={<SearchOutlined />}
                    />
                  </AutoComplete>
                  <Typography.Text className="color-text">
                    *{t("common:only_owner_can_approve")}
                  </Typography.Text>
                </Space>
              );
            }}
          />
        </Form.Item>
        <Space
          style={{
            justifyContent: "right",
            width: "100%",
            paddingRight: "30px",
          }}
        >
          <Button
            onClick={() => {
              handleCancel();
              clearErrors();
              reset();
            }}
            className="btn-secondary btn-outlined"
            block
          >
            {t("common:cancel")}
          </Button>
          <Button
            type="primary"
            loading={confirmLoading}
            block
            htmlType="submit"
          >
            {t("common:save")}
          </Button>
        </Space>
      </Form>
    </Modal>
  );
};

export default ModalCreateRequest;
