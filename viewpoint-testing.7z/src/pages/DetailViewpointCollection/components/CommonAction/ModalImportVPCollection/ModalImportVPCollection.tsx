import type { UploadProps } from "antd";
import { Checkbox, Col, Modal, Row, Typography, Upload } from "antd";
import * as React from "react";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { AiOutlineCloudUpload } from "react-icons/ai";
import type { CheckboxValueType } from "antd/es/checkbox/Group";
import { Wrapper } from "./ModalImportVPCollection.Styled";
import { VIEWPOINT_IMPORT_FIELD } from "@utils/constants";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";

const { Dragger } = Upload;
export type ModalImportVPCollectionProps = {
  open: boolean;
  setOpen: (boolean) => void;
  currentViewpointCollection: any;
  getData: () => void;
};

const defaultValueImportViewpoint = [
  VIEWPOINT_IMPORT_FIELD.DOMAIN,
  VIEWPOINT_IMPORT_FIELD.TEST_TYPE,
  VIEWPOINT_IMPORT_FIELD.CATEGORY,
  VIEWPOINT_IMPORT_FIELD.VIEWPOINT_DETAIL,
  VIEWPOINT_IMPORT_FIELD.CONFIRMATION,
  VIEWPOINT_IMPORT_FIELD.EXAMPLE,
  VIEWPOINT_IMPORT_FIELD.NOTE,
  VIEWPOINT_IMPORT_FIELD.NO,
];

const ModalImportVPCollection: React.FC<ModalImportVPCollectionProps> = ({
  open,
  setOpen,
  currentViewpointCollection,
  getData,
}) => {
  const { t } = useTranslation(["common", "validate", "responseMessage"]); // languages
  const [error, setError] = useState("");
  const [isEmpty, setIsEmpty] = useState(true);
  const [file, setFile] = useState<File>(null);
  const [loading, setLoading] = useState(false);
  const [labelImportList, setLabelImportList] = useState(
    defaultValueImportViewpoint
  );

  const handleOnChangeCheckbox = (checkedValues: CheckboxValueType[]) => {
    setLabelImportList(checkedValues as string[]);
  };
  const props: UploadProps = {
    name: "file",
    maxCount: 1,
    onChange(info) {
      if (info?.fileList?.length > 0) {
        setError("");
      }
    },
    beforeUpload: (file) => {
      setFile(file);
      setIsEmpty(false);
      return false;
    },
    onDrop(e) {
      setFile(e.dataTransfer.files[0]);
    },
    onRemove() {
      setIsEmpty(true);
      setFile(null);
    },
    multiple: false,
    listType: "text",
    showUploadList: {
      showPreviewIcon: false,
      showDownloadIcon: false,
    },
    accept:
      ".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel",
  };

  const handleOk = async () => {
    try {
      if (!file) {
        setError(t("validate:choose_one_file"));
        return;
      }
      setLoading(true);
      const data = new FormData();
      data.append("formFile", file);
      for (let index = 0; index < labelImportList.length; index++) {
        const element = labelImportList[index];
        data.append("ListTitle", element);
      }
      data.append("ViewPointCollectionId", currentViewpointCollection?.id);
      await viewpointCollectionAPI.importViewpointCollection(data);
      showSuccessNotification(
        t("common:import_viewpoint_collection_successfully")
      );
      await getData();
    } catch (error) {
      setLoading(false);
      setOpen(false);
      showErrorNotification(t(`responseMessage:${error?.code}`));
    } finally {
      setFile(null);
      setLabelImportList(defaultValueImportViewpoint);
      setIsEmpty(true);
      setLoading(false);
      setOpen(false);
    }
  };

  return (
    <Modal
      title={t("common:import_viewpoint_collection")}
      visible={open}
      width={500}
      onCancel={() => {
        setOpen(false);
      }}
      confirmLoading={loading}
      onOk={handleOk}
      cancelText={t("common:cancel")}
      okText={t("common:import")}
      maskClosable={false}
    >
      {error !== "" && (
        <Typography.Paragraph className="color-red">
          {error}
        </Typography.Paragraph>
      )}

      {!isEmpty && (
        <>
          <Typography.Text className="color-text">
            {t("common:choose_fields_import")}
          </Typography.Text>
          <Checkbox.Group
            style={{ width: "100%", marginBottom: "1rem", marginTop: "0.5rem" }}
            onChange={handleOnChangeCheckbox}
            className="choose-fields-import"
            defaultValue={defaultValueImportViewpoint}
          >
            <Row>
              <Col span={8}>
                <Checkbox
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.DOMAIN}
                >
                  {t("common:domain")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.TEST_TYPE}
                >
                  {t("common:test_type")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.CATEGORY}
                >
                  {t("common:category")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  className="color-text"
                  disabled
                  value={VIEWPOINT_IMPORT_FIELD.VIEWPOINT_DETAIL}
                >
                  {t("common:viewpoint_detail")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  disabled
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.CONFIRMATION}
                >
                  {t("common:confirmation")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  disabled
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.EXAMPLE}
                >
                  {t("common:example")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  disabled
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.NOTE}
                >
                  {t("common:note")}
                </Checkbox>
              </Col>
              <Col span={8}>
                <Checkbox
                  className="color-text"
                  value={VIEWPOINT_IMPORT_FIELD.NO}
                >
                  {t("common:No")}
                </Checkbox>
              </Col>
            </Row>
          </Checkbox.Group>
          <Typography.Text className="color-text">
            {t("common:your_upload_file")}
          </Typography.Text>
        </>
      )}
      <Wrapper className={isEmpty ? "empty" : ""}>
        <Dragger {...props}>
          <AiOutlineCloudUpload className="icon-upload" />
          <Typography.Title level={5}>{t("common:drag_file")}</Typography.Title>
          <Typography.Title level={5}>{t("common:or")}</Typography.Title>
          <Typography.Title level={5} className={"browse-file"}>
            {t("common:browse_files")}
          </Typography.Title>
        </Dragger>
      </Wrapper>
      <div
        className="restrict-files"
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: "10px",
        }}
      >
        {isEmpty && (
          <>
            <Typography.Text style={{ color: "var(--clr-text)" }}>
              {t("common:accept_fle_excel")}
            </Typography.Text>
            <Typography.Text style={{ color: "var(--clr-text)" }}>
              {t("common:upload_1_file")}
            </Typography.Text>
          </>
        )}
      </div>
    </Modal>
  );
};

export default ModalImportVPCollection;
