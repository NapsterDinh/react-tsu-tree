import { TYPE_TREE_NODE } from "@utils/constants";
import {
  Button,
  Descriptions,
  Empty,
  Form,
  Input,
  Space,
  Tag,
  Typography,
} from "antd";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Wrapper } from "./DetailViewpointForm.Styled";
const { Title } = Typography;

interface IDomainParams {
  name: string;
  description: string;
  isActive: boolean;
  parentId: React.Key;
}

interface IProps {
  onChange?: (e) => void;
  data: any;
  setData: (any) => void;
}

const DetailViewpointForm = ({ onChange, data, setData }: IProps) => {
  const { t } = useTranslation(["common", "validate"]);
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();

  const onFinish = (values) => {
    console.log(values);
  };

  useEffect(() => {
    if (data) {
      form.setFieldValue("viewpointDetail", data?.viewDetail?.viewpointDetail);
      form.setFieldValue("confirmation", data?.viewDetail?.confirmation);
      form.setFieldValue("example", data?.viewDetail?.example);
      form.setFieldValue("note", data?.viewDetail?.note);
    }
  }, [data]);

  return (
    <Wrapper className="sticky">
      {!data ? (
        <div className="detail-viewpoint-collection-detail">
          <div className="detail-viewpoint-collection-tree-empty">
            <Empty
              image={Empty.PRESENTED_IMAGE_SIMPLE}
              description={<span>{t("common:no_data")}</span>}
            />
          </div>
        </div>
      ) : (
        <div className="detail-viewpoint-collection-detail">
          <div>
            <Typography.Title level={4} className="color-text">
              {t("common:detail_info")}
            </Typography.Title>
          </div>
          <Form
            style={{ marginTop: "1.5rem" }}
            onFinish={onFinish}
            form={form}
            layout="vertical"
            autoComplete="off"
            onChange={onChange}
          >
            <Form.Item
              name="viewpointDetail"
              label={t("common:viewpoint_detail")}
            >
              <Input.TextArea
                rows={2}
                placeholder={t("common:enter_viewpoint_detail")}
              />
            </Form.Item>
            <Form.Item name="confirmation" label={t("common:confirmation")}>
              <Input.TextArea
                rows={3}
                placeholder={t("common:enter_confirmation")}
              />
            </Form.Item>
            <Form.Item name="example" label={t("common:example")}>
              <Input.TextArea
                rows={3}
                placeholder={t("common:enter_example")}
              />
            </Form.Item>
            <Form.Item name="note" label={t("common:note")}>
              <Input.TextArea rows={3} placeholder={t("common:enter_note")} />
            </Form.Item>
            <Space style={{ justifyContent: "right", width: "100%" }}>
              <Button>{t("common:cancel")}</Button>
              <Button type="primary" htmlType="submit" loading={loading}>
                {t("common:save")}
              </Button>
            </Space>
          </Form>
        </div>
      )}
    </Wrapper>
  );
};

export default DetailViewpointForm;
