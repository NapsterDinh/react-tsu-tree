import styled from "styled-components";

export const Wrapper = styled.div`
  position: sticky;
  top: 5%;
  padding: 1.5rem;
  border-radius: var(--border-radius-element);
  background-color: var(--background-color-element);
  box-shadow: var(--box-shadow-element-wrapper);
  transition: all ease-in-out 0.2s;
`;
