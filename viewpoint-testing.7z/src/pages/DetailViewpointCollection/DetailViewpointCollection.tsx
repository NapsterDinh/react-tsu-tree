import { HomeOutlined } from "@ant-design/icons";
import viewpointCollectionAPI from "@services/viewpointCollectionAPI";
import ViewpointAPI from "@services/viewpointsAPI";
import {
  DEFAULT_VIEWPOINT_NODE,
  STATUS_VIEWPOINT_COLLECTION,
  TYPE_TREE_NODE,
} from "@utils/constants";
import { convertedToDataTree } from "@utils/helpersUtils";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import { Breadcrumb, Col, Empty, Row, Space, Spin, Switch } from "antd";
import { ElementWrapper } from "AppStyled";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useNavigate, useParams } from "react-router-dom";
import { routes } from "routes";
import { CommonAction, ViewpointTree } from "./components";
import DetailViewpointForm from "./components/DetailViewpointForm/DetailViewpointForm";
import { Wrapper } from "./DetailViewpointCollection.Style";

const fakeResponse = {
  data: {
    id: "c56b2e96-780d-4362-a847-89379e0808c0",
    orderStrings: [
      "c56b2e96-780d-4362-a847-89379e0808c1",
      "c56b2e96-780d-4362-a847-89379e0808c2",
      "c56b2e96-780d-4362-a847-89379e0808c3",
      "c56b2e96-780d-4362-a847-89379e0808c4",
      "c56b2e96-780d-4362-a847-89379e0808c5",
    ],
    viewPoints: [
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c1",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 1",
          confirmation: "Confirmation 1",
          example: "Example 1",
          note: "note 1",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: null,
        orderStrings: [
          "c56b2e96-780d-4362-a847-89379e0808c6",
          "c56b2e96-780d-4362-a847-89379e0808c7",
          "c56b2e96-780d-4362-a847-89379e0808c8",
        ],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c2",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 2",
          confirmation: "Confirmation 2",
          example: "Example 2",
          note: "note 2",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: null,
        orderStrings: [
          "c56b2e96-780d-4362-a847-89379e0808c9",
          "c56b2e96-780d-4362-a847-89379e080810",
          "c56b2e96-780d-4362-a847-89379e080811",
        ],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c3",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 3",
          confirmation: "Confirmation 3",
          example: "Example 3",
          note: "note 3",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: null,
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c4",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 4",
          confirmation: "Confirmation 4",
          example: "Example 4",
          note: "note 4",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: null,
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c5",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 5",
          confirmation: "Confirmation 5",
          example: "Example 5",
          note: "note 5",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: null,
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c6",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 6",
          confirmation: "Confirmation 6",
          example: "Example 6",
          note: "note 6",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c1",
        orderStrings: [
          "c56b2e96-780d-4362-a847-89379e080812",
          "c56b2e96-780d-4362-a847-89379e080813",
        ],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c7",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 7",
          confirmation: "Confirmation 7",
          example: "Example 7",
          note: "note 7",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c1",
        orderStrings: [
          "c56b2e96-780d-4362-a847-89379e080814",
          "c56b2e96-780d-4362-a847-89379e080815",
        ],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c8",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 8",
          confirmation: "Confirmation 8",
          example: "Example 8",
          note: "note 8",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c1",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e0808c9",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 9",
          confirmation: "Confirmation 9",
          example: "Example 9",
          note: "note 9",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c2",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080810",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 10",
          confirmation: "Confirmation 10",
          example: "Example 10",
          note: "note 10",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c2",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080811",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 11",
          confirmation: "Confirmation 11",
          example: "Example 11",
          note: "note 11",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c2",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080812",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 12",
          confirmation: "Confirmation 12",
          example: "Example 12",
          note: "note 12",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c6",
        orderStrings: [
          "c56b2e96-780d-4362-a847-89379e080816",
          "c56b2e96-780d-4362-a847-89379e080817",
        ],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080813",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 13",
          confirmation: "Confirmation 13",
          example: "Example 13",
          note: "note 13",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c6",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080814",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 14",
          confirmation: "Confirmation 14",
          example: "Example 14",
          note: "note 14",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c7",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080815",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 15",
          confirmation: "Confirmation 15",
          example: "Example 15",
          note: "note 15",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e0808c7",
        orderStrings: [
          "c56b2e96-780d-4362-a847-89379e080818",
          "c56b2e96-780d-4362-a847-89379e080819",
        ],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080816",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 16",
          confirmation: "Confirmation 16",
          example: "Example 16",
          note: "note 16",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e080812",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080817",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 17",
          confirmation: "Confirmation 17",
          example: "Example 17",
          note: "note 17",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e080812",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080818",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 18",
          confirmation: "Confirmation 18",
          example: "Example 18",
          note: "note 18",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e080815",
        orderStrings: [],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080819",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 19",
          confirmation: "Confirmation 19",
          example: "Example 19",
          note: "note 19",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e080815",
        orderStrings: ["c56b2e96-780d-4362-a847-89379e080820"],
      },
      {
        id: "c56b2e96-780d-4362-a847-89379e080820",
        viewDetail: {
          language: "vi",
          viewpointDetail: "Viewpoint Detail 20",
          confirmation: "Confirmation 20",
          example: "Example 20",
          note: "note 20",
        },
        createdAt: "2022-10-19 18:12:15.7609474",
        updatedAt: "2022-10-19 18:12:15.7609474",
        updateBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        createdBy: "2d9d774b-a221-4d4f-aad1-08daaea65f6b",
        parentId: "c56b2e96-780d-4362-a847-89379e080819",
        orderStrings: [],
      },
    ],
  },
};

const DetailViewpointCollection = () => {
  const [currentVPCollection, setCurrentVPCollection] = useState(null);
  const [loadingGetById, setLoadingGetById] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [levelShow, setLevelShow] = useState(-1);
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation(["common", "validate"]); // languages
  const user = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : null;

  const handleGetViewpointCollection = async () => {
    try {
      if (id) {
        setLoadingGetById(true);
        // const response =
        //   await viewpointCollectionAPI.getViewpointCollectionById(id);
        const convertedData = convertedToDataTree(
          { ...fakeResponse?.data },
          { ...fakeResponse?.data },
          "viewPoints",
          "viewDetail.viewpointDetail"
        );
        delete convertedData.orderStrings;
        setCurrentVPCollection(convertedData);
      }
    } catch (error) {
      if (error?.code !== "IdInvalid") {
        if (error?.response?.status === 400) {
          if (!error?.response?.data?.errors?.[0]?.code) {
            showErrorNotification(t("responseMessage:IdInvalid"));
          } else {
            showErrorNotification(t(`responseMessage:${error?.code}`));
          }
          navigate("/not-found", {
            state: {
              from: {
                pathname: routes.ViewpointCollection.path[0],
              },
            },
          });
        } else {
          showErrorNotification(t(`responseMessage:${error?.code}`));
        }
      } else {
        showErrorNotification(t(`responseMessage:${error?.code}`));
        navigate("/not-found", {
          state: {
            from: {
              pathname: routes.ViewpointCollection.path[0],
            },
          },
        });
      }
    } finally {
      setLoadingGetById(false);
    }
  };

  const handleCallAPIDeleteViewpoint = async (node) => {
    try {
      //handle call api delete
      return true;
    } catch (error) {}
  };

  const handleCallAPISaveViewpoint = async (node) => {
    return true;
  };

  const handleCallAPIAddChildViewpoint = async (node) => {
    try {
      // const response = await ViewpointAPI.addNewViewpoint({
      //   viewpoint: node,
      // });
      showSuccessNotification(t("common:update_domain_succeed"));
      return Math.random().toString() + "abc";
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error?.code}`));
    }
  };

  const handleCallAPIDragDropViewpoint = async (
    dragParentKey,
    targetKey,
    dropParentKey,
    previousNodeAfterDropKey
  ) => {
    try {
      //handle call api delete
      return true;
    } catch (error) {}
  };

  const handleOnSelectNode = (e) => {
    e?.node ? setSelectedNode(e?.node) : setSelectedNode(null);
  };

  const handleChangeStatus = async (checked) => {
    try {
      await viewpointCollectionAPI.updateStatus(
        currentVPCollection?.id,
        checked
          ? STATUS_VIEWPOINT_COLLECTION.PUBlISH
          : STATUS_VIEWPOINT_COLLECTION.PRIVATE,
        checked
          ? STATUS_VIEWPOINT_COLLECTION.PUBlISH
          : STATUS_VIEWPOINT_COLLECTION.PRIVATE
      );
      setCurrentVPCollection({
        ...currentVPCollection,
        status: checked
          ? STATUS_VIEWPOINT_COLLECTION.PUBlISH
          : STATUS_VIEWPOINT_COLLECTION.PRIVATE,
      });
      showSuccessNotification(t("common:change_is_active_success"));
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error?.code}`));
    } finally {
    }
  };

  // call domain's action
  useEffect(() => {
    (async () => {
      await handleGetViewpointCollection();
    })();
  }, []);

  return (
    <Wrapper>
      <Breadcrumb>
        <Breadcrumb.Item>
          <Link to={"/"}>
            <HomeOutlined />
          </Link>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <Link
            to={routes.ViewpointCollection.path[0]}
            style={{ color: "var(--clr-text)" }}
          >
            {t("common:viewpoint_collection_management")}
          </Link>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          {/* {t("common:viewpoint_collection_detail")} */}
          {currentVPCollection?.detail?.name}
        </Breadcrumb.Item>
      </Breadcrumb>
      <CommonAction
        currentVPCollection={currentVPCollection}
        getData={handleGetViewpointCollection}
        setCurrentVPCollection={setCurrentVPCollection}
        setSearchText={setSearchText}
        setLevelShow={setLevelShow}
      />
      <Space
        align="center"
        style={{
          display: "flex",
          justifyContent: "space-between",
          margin: "1rem 0 0.5rem",
        }}
      >
        <Space></Space>
        {user?.id === currentVPCollection?.user?.id && (
          <Space>
            <div>
              <span className="label">{t("common:private")}</span>
              <Switch
                key={"switchStatus"}
                checked={
                  currentVPCollection?.status ===
                  STATUS_VIEWPOINT_COLLECTION.PUBlISH
                }
                onChange={(checked) => handleChangeStatus(checked)}
              />
              <span className="label">{t("common:publish")}</span>
            </div>
            <div>
              <span className="label">{t("common:private")}</span>
              <Switch
                key={"switchStatus"}
                checked={
                  currentVPCollection?.status ===
                  STATUS_VIEWPOINT_COLLECTION.PUBlISH
                }
                onChange={(checked) => handleChangeStatus(checked)}
              />
              <span className="label">{t("common:publish")}</span>
            </div>
          </Space>
        )}
      </Space>
      <Row gutter={8}>
        <Col xs={16}>
          <ElementWrapper>
            <div className="detail-viewpoint-collection-tree">
              {loadingGetById ? (
                <Space
                  align="center"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  <Spin tip={t("common:loading")} />
                </Space>
              ) : currentVPCollection?.children.length ? (
                <ViewpointTree
                  dataObjectTree={currentVPCollection}
                  setDataObjectTree={setCurrentVPCollection}
                  handleDeleteNodeAPI={handleCallAPIDeleteViewpoint}
                  handleDragDropAPI={handleCallAPIDragDropViewpoint}
                  handleSaveNodeAPI={handleCallAPISaveViewpoint}
                  handleAddChildAPI={handleCallAPIAddChildViewpoint}
                  handleOnSelectNode={handleOnSelectNode}
                  selectedNode={selectedNode}
                  setSelectedNode={setSelectedNode}
                  searchValue={searchText}
                  setSearchValue={setSearchText}
                  levelShow={levelShow}
                  defaultNewTreeNode={DEFAULT_VIEWPOINT_NODE}
                />
              ) : (
                <div className="detail-viewpoint-collection-empty">
                  <Empty
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    description={<span>{t("common:no_data")}</span>}
                  />
                </div>
              )}
            </div>
          </ElementWrapper>
        </Col>
        <Col xs={8}>
          <DetailViewpointForm data={selectedNode} setData={setSelectedNode} />
        </Col>
      </Row>
    </Wrapper>
  );
};

export default DetailViewpointCollection;
