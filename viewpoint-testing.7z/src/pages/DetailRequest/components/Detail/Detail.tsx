import { Descriptions } from "antd";
import React from "react";
import { DetailWrapper } from "./DetailWrapper";

const Detail = ({ header }) => {
  return (
    <DetailWrapper>
      <Descriptions
        column={2}
        title={<span className="text">{header}</span>}
        contentStyle={{ color: "var(--clr-text)" }}
      >
        <Descriptions.Item label={<span className="text">Requester</span>}>
          Unknown(FSO.HCM.GST.SUN)
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Request Type</span>}>
          Suggestion update viewpoint
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Request Type</span>}>
          status
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Date created</span>}>
          {"9:30:00 20/10/2022"}
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Requester</span>}>
          Domain
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Test type</span>}>
          Function testing
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Title</span>}>
          Update master data viewpoint
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Description</span>}>
          I think data of your master data is too old
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Approved</span>}>
          AnhVD7
        </Descriptions.Item>
        <Descriptions.Item
          label={<span className="text">Last modified by</span>}
        >
          Unknown(FSO.HCM.GST.SUN)
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Last updated</span>}>
          {"9:30:00 20/10/2022"}
        </Descriptions.Item>
        <Descriptions.Item label={<span className="text">Current stage</span>}>
          Automatic_API_Viewpoint_v1.1.2
        </Descriptions.Item>
        <Descriptions.Item
          label={<span className="text">Require change stage</span>}
        >
          Viewpoint_Collection_1
        </Descriptions.Item>
      </Descriptions>
    </DetailWrapper>
  );
};

export default Detail;
