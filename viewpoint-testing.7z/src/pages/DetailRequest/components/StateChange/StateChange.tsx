import { Col, Row, Space, Tree } from "antd";
import React from "react";
import { StateChangeWrapper } from "./StateChangeWrapper";
import { AiFillFolder } from "react-icons/ai";
import type { DataNode, DirectoryTreeProps } from "antd/es/tree";
import { ElementWrapper } from "AppStyled";
const { DirectoryTree } = Tree;
const StateChange = ({ header }) => {
  const treeData: DataNode[] = [
    {
      title: "parent 1",
      key: "1",
      children: [
        {
          title: "leaf 1-1",
          key: "1-1",
          children: [
            { title: "leaf 1-1-1", key: "1-1-1" },
            { title: "leaf 1-1-2", key: "1-1-2" },
          ],
        },
        { title: "leaf 1-2", key: "1-2" },
      ],
    },
    {
      title: "parent 2",
      key: "2",
      children: [
        { title: "leaf 2-1", key: "2-1" },
        { title: "leaf 2-2", key: "2-2" },
      ],
    },
    {
      title: "parent 3",
      key: "3",
      children: [
        { title: "leaf 3-1", key: "3-1" },
        { title: "leaf 3-2", key: "3-2" },
      ],
    },
  ];
  const treeData2: DataNode[] = [
    {
      title: "parent 1",
      key: "1",
      children: [
        {
          title: "leaf 1-1",
          key: "1-1",
          children: [
            { title: "leaf 1-1-1", key: "1-1-1" },
            { title: "leaf 1-1-2", key: "1-1-2" },
          ],
        },
        { title: "leaf 1-2", key: "1-2" },
      ],
    },
    {
      title: "",
      key: "999",
      isLeaf: true,
      children: [
        { title: "", key: "12", isLeaf: true },
        { title: "", key: "123", isLeaf: true },
      ],
    },
    {
      title: "parent 3",
      key: "3",
      children: [
        { title: "leaf 3-1", key: "3-1" },
        { title: "leaf 3-2", key: "3-2" },
      ],
    },
    {
      title: "parent 4",
      key: "4",
      children: [
        { title: "leaf 4-1", key: "4-1" },
        { title: "leaf 4-2", key: "4-2" },
      ],
    },
  ];

  const onSelect: DirectoryTreeProps["onSelect"] = (keys, info) => {
    console.log("Trigger Select", keys, info);
  };

  const onExpand: DirectoryTreeProps["onExpand"] = (keys, info) => {
    console.log("Trigger Expand", keys, info);
  };
  return (
    <StateChangeWrapper>
      <h3
        style={{ fontWeight: 700, margin: "20px 0", color: "var(--clr-text)" }}
      >
        {header}
      </h3>

      <Row>
        <Col md={12} style={{ paddingRight: "40px", borderRight: "1px solid" }}>
          <ElementWrapper>
            <p>Current state: Automotive_Viewpoint_v1.1.2</p>
            <div className="container-required">
              <DirectoryTree
                rootClassName={"tree1"}
                rootStyle={{
                  backgroundColor: "var(--background-color-element)",
                  color: "var(--clr-text)",
                }}
                selectable={true}
                blockNode
                showIcon={false}
                selectedKeys={["2", "2-1", "2-2"]}
                multiple
                defaultExpandAll
                onSelect={onSelect}
                onExpand={onExpand}
                treeData={treeData}
              />
            </div>
          </ElementWrapper>
        </Col>
        <Col md={12} style={{ paddingLeft: "40px", borderLeft: "1px solid" }}>
          <p>Require updated stage: Viewpoint_Collection_1</p>
          <div className="container-required">
            <DirectoryTree
              rootClassName={"tree2"}
              rootStyle={{
                backgroundColor: "var(--background-color-element)",
                color: "var(--clr-text)",
              }}
              multiple
              showIcon={false}
              defaultExpandAll
              selectedKeys={["4", "4-1", "4-2"]}
              onSelect={onSelect}
              onExpand={onExpand}
              treeData={treeData2}
            />
          </div>
        </Col>
      </Row>
    </StateChangeWrapper>
  );
};

export default StateChange;
