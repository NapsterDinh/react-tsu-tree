import styled from "styled-components";

export const StateChangeWrapper = styled.div`
  .container-required {
    border: 1px solid;
  }
  color: var(--clr-text);
  .tree1 .ant-tree-treenode-selected:before {
    background: #e04343 !important;
  }
  .tree1 .ant-tree-treenode-selected {
    background: #e04343 !important;
  }
  .tree2 .ant-tree-treenode-selected {
    background: #1aae1a !important;
  }
  .tree2 .ant-tree-treenode-selected:before {
    background: #1aae1a !important;
  }
`;
