import styled from "styled-components";

export const DetailRequestWrapper = styled.div`
  color: var(--clr-text);
  .text {
    color: var(--clr-text);
  }
`;
