import { BreadCrumb } from "@components";
import {
  AndroidOutlined,
  AppleOutlined,
  HomeOutlined,
  SaveOutlined,
} from "@ant-design/icons";
import { Breadcrumb, Button, Space, Spin, Tabs } from "antd";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useParams } from "react-router-dom";
import { DetailRequestWrapper } from "./DetailRequestWrapper";
import Detail from "./components/Detail/Detail";
import StateChange from "./components/StateChange/StateChange";
import { routes } from "routes";
import ButtonGroup from "antd/lib/button/button-group";
const DetailRequest = () => {
  const { t } = useTranslation(["common"]); // languages
  const { id } = useParams();
  const [header, setHeader] = useState("Staged changes");
  const onChange = (key: string) => {
    console.log(key);
    setHeader(key);
  };
  return (
    <DetailRequestWrapper>
      <Breadcrumb>
        <Breadcrumb.Item>
          <Link to={"/"}>
            <HomeOutlined />
          </Link>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          <Link
            to={routes.RequestManagement.path[0]}
            style={{ color: "var(--clr-text)" }}
          >
            {t("common:request_management")}
          </Link>
        </Breadcrumb.Item>
        <Breadcrumb.Item>
          {t("common:detail_request_management")}
        </Breadcrumb.Item>
      </Breadcrumb>
      <Space style={{ display: "flex", justifyContent: "space-between" }}>
        <h1
          style={{
            marginTop: "20px",
            fontSize: "1.5rem",
            fontWeight: "600",
            color: "var(--clr-text)",
          }}
        >
          "kaka"
        </h1>
        <Space>
          <Button>{t("common:approve")}</Button>
          {/* <ButtonGroup className="clone-btn">
            {t("common:viewpoint_collection_clone_other_viewpoint_collection")}
          </Button> */}
          <Button>{t("common:reject")}</Button>
          <Button>{t("common:cancel")}</Button>
        </Space>
      </Space>
      <div>
        <Tabs defaultActiveKey="Staged changes" onChange={onChange}>
          <Tabs.TabPane
            tab={
              <span>
                <AndroidOutlined className="text" />{" "}
                <span className="text">Details</span>
              </span>
            }
            key="Details"
          >
            <Detail header={header} />
          </Tabs.TabPane>
          <Tabs.TabPane
            tab={
              <span>
                <AppleOutlined className="text" />{" "}
                <span className="text">Staged changes</span>
              </span>
            }
            key="Staged changes"
          >
            <StateChange header={header} />
          </Tabs.TabPane>
        </Tabs>
      </div>
      <Spin spinning={false} tip="Loading..."></Spin>
    </DetailRequestWrapper>
  );
};

export default DetailRequest;
