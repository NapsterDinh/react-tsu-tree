import { BreadCrumb, LocaleProvider } from "@components";
import { usePermissions } from "@hooks/usePermissions";
import { rootState } from "@models/type";
import { userActions } from "@redux/slices";
import { roleApi } from "@services/roleAPI";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { Input, Select, Space, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useSearchParams } from "react-router-dom";
import { UserManagementWrapper } from "./UserManagementWrapper";

const { Option } = Select;
const { Search } = Input;

const UserManagement: React.FC = () => {
  const location = useLocation();
  const { t } = useTranslation(["common", "validate"]); // languages
  const user = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : null;
  const [errorSearch, setErrorSearch] = useState("");
  const [roles, setRoles] = useState<any>();
  const { checkPermission } = usePermissions();
  const [searchParams, setSearchParams] = useSearchParams();

  const handleGetAllRole = async () => {
    try {
      // setLoading(true);
      const res = await roleApi.getAllRole({});
      setRoles(res.data);
    } catch (error) {
    } finally {
      // setLoading(false);
    }
  };
  const handleChangeAsc = (value: string) => {
    if (searchParams.getAll("Text")[0] && searchParams.getAll("isActive")[0]) {
      setSearchParams({
        isActive: searchParams.getAll("isActive")[0],
        Text: searchParams.getAll("Text")[0],
        Sort: value,
      });
    } else if (searchParams.getAll("Text")[0]) {
      setSearchParams({
        Text: searchParams.getAll("Text")[0],
        Sort: value,
      });
    } else if (searchParams.getAll("isActive")[0]) {
      setSearchParams({
        isActive: searchParams.getAll("isActive")[0],
        Sort: value,
      });
    } else {
      setSearchParams({
        Sort: value,
      });
    }
  };
  const handleChangeSortActive = (value: string) => {
    if (searchParams.getAll("Text")[0] && searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        Text: searchParams.getAll("Text")[0],
        isActive: value,
      });
    } else if (searchParams.getAll("Text")[0]) {
      setSearchParams({
        Text: searchParams.getAll("Text")[0],
        isActive: value,
      });
    } else if (searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        isActive: value,
      });
    } else {
      setSearchParams({
        isActive: value,
      });
    }
  };
  const handleChangeStatus = (id: string, value: string) => {
    // console.log(`selected ${value}`);
    dispatch(
      userActions.updateStatus({ isActive: value, id, search: location.search })
    );
  };
  const handleChangeRole = (id: string, value: string) => {
    // console.log(`selected ${value} ${id}`);
    dispatch(
      userActions.updateRole({ role: value, id, search: location.search })
    );
  };
  const onSearch = (value: string) => {
    if (checkContainsSpecialCharacter(value.trim())) {
      setErrorSearch(t("validate:string_not_contains_special_characters"));
      return;
    } else {
      setErrorSearch("");
    }
    if (searchParams.getAll("isActive")[0] && searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        isActive: searchParams.getAll("isActive")[0],
        Text: value,
      });
    } else if (searchParams.getAll("isActive")[0]) {
      setSearchParams({
        isActive: searchParams.getAll("isActive")[0],
        Text: value,
      });
    } else if (searchParams.getAll("Sort")[0]) {
      setSearchParams({
        Sort: searchParams.getAll("Sort")[0],
        Text: value,
      });
    } else {
      setSearchParams({
        Text: value,
      });
    }
  };
  interface DataType {
    key: React.Key;
    userName: string;
    account: string;
    role: any;
    status: any;
    dateStart: any;
  }
  const columns: ColumnsType<DataType> = [
    {
      title: t("common:full_name"),
      dataIndex: "userName",
    },
    {
      title: t("common:account"),
      dataIndex: "account",
    },

    {
      title: t("common:role"),
      dataIndex: "role",
    },
    {
      title: t("common:status"),
      dataIndex: "status",
    },
    {
      title: t("common:date_created"),
      dataIndex: "dateStart",
    },
  ];

  const dispatch = useDispatch();
  const { users, loading } = useSelector((state: rootState) => state.user);
  const currentUser = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : null;

  useEffect(() => {
    dispatch(userActions.getAllUser({ search: location.search }));
    handleGetAllRole();
  }, [location.search]);
  let userData;

  if (users) {
    userData = users?.data
      ?.filter((item) => item?.id !== user?.id)
      ?.map((user) => {
        return {
          id: user.id,
          key: user.id,
          userName: user.userName,
          account: user.account,
          role: (
            <Select
              defaultValue={user.role}
              value={user.role}
              style={{
                width: 120,
              }}
              // disabled={
              //   (currentUser?.role === ROLE.ADMIN && user?.role === ROLE.ADMIN) ||
              //   checkPermission(["USER.UPDATE"])
              // }
              onChange={(value) => handleChangeRole(user.id, value)}
            >
              {roles &&
                roles.map((e) => {
                  // console.log(roles, "e");
                  return <Option value={e?.name}>{e?.name}</Option>;
                })}
            </Select>
          ),
          status: (
            <Select
              defaultValue={user.isActive ? "Active" : "InActive"}
              // disabled={
              //   (currentUser?.role === ROLE.ADMIN && user?.role === ROLE.ADMIN) ||
              //   checkPermission(["USER.UPDATE"])
              // }
              style={{
                width: 120,
              }}
              onChange={(value) => handleChangeStatus(user.id, value)}
            >
              <Option value="true">Active</Option>
              <Option value="false">InActive</Option>
            </Select>
          ),
          dateStart: new Date(user.createdAt).toLocaleString(),
        };
      });
  }

  const onChange = (page, pageSize) => {
    dispatch(
      userActions.getAllUser({
        search: location.search,
        PageSize: pageSize,
        PageNumber: page,
      })
    );
  };
  // console.log(searchParams.get("Sort"), "searchParams.get(Sort)");
  return (
    <UserManagementWrapper>
      <BreadCrumb
        title={t("user_management")}
        previousTitle={t("home_page")}
        link="/"
        breadCrumb={true as boolean}
      />
      <Space className="container-sort">
        <div className="item-sort">
          <p className="label">{t("common:sort")}</p>
          <Select
            defaultValue={
              searchParams.get("Sort") ? searchParams.get("Sort") : "2"
            }
            style={{ width: 180 }}
            onChange={handleChangeAsc}
          >
            <Option value={"0"}>{t("common:sort_by_name_a_z")}</Option>
            <Option value={"1"}>{t("common:sort_by_name_z_a")}</Option>
            <Option value={"2"}>{t("common:no_sort")}</Option>
          </Select>
        </div>
        <div className="item-sort">
          <p className="label">{t("common:status")}</p>
          <Select
            defaultValue={
              searchParams.get("isActive") ? searchParams.get("isActive") : "2"
            }
            style={{ width: 180 }}
            onChange={handleChangeSortActive}
          >
            <Option value="2">{t("common:all_of_status")}</Option>
            <Option value="1">{t("common:status_active")}</Option>
            <Option value="0">{t("common:status_inactive")}</Option>
          </Select>
        </div>
        <div className="item-sort1">
          <p className="label">{t("common:search")}</p>
          {/* <Search
            placeholder="input search text"
            allowClear
            onSearch={onSearch}
            style={{ width: 400 }}
          /> */}
          <div className="search-container">
            <Search
              defaultValue={searchParams.get("Text")}
              placeholder={t("common:enter_search_text")}
              onSearch={onSearch}
              enterButton={t("common:search")}
              style={{ width: 343 }}
              maxLength={20}
              status={errorSearch !== "" ? "error" : ""}
            />
            {errorSearch !== "" && (
              <div className="error-search">{errorSearch}</div>
            )}
          </div>
        </div>
      </Space>
      <div className="mr-t-20">
        <LocaleProvider>
          <Table
            loading={loading}
            scroll={{
              x: 600,
            }}
            rowKey={"id"}
            columns={columns}
            dataSource={userData}
            pagination={
              userData?.length > 20
                ? {
                    defaultPageSize: 20,
                    showSizeChanger: true,
                    pageSizeOptions: ["20", "30", "40"],
                    total: users?.metaData?.totalCount,
                    defaultCurrent: 1,
                    onChange: onChange,
                    showQuickJumper: true,
                  }
                : false
            }
          />
        </LocaleProvider>
      </div>
    </UserManagementWrapper>
  );
};

export default UserManagement;
