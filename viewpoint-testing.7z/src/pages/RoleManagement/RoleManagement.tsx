import { BreadCrumb } from "@components";
import { LocaleProvider } from "@components/index";
import { usePermissions } from "@hooks/usePermissions";
import { Button, Form, Modal, Space, Table, Tooltip } from "antd";
import type { ColumnsType } from "antd/es/table";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { AiOutlineDelete, AiOutlineEdit } from "react-icons/ai";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import ModalUpdate from "./components/ModalUpdate/ModalUpdate";
import ModalCreate from "./components/ModalCreate/ModalCreate";
import { RoleManagementWrapper } from "./RoleManagementWrappper";
import { roleApi } from "@services/roleAPI";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";

interface DataType {
  key: string;
  role: string;
  lastUpdate: string;
  dateCreated: string;
  description: string;
  status: string;
  action: any;
}
const RoleManagement: React.FC = () => {
  const { t } = useTranslation(["common", "validate"]); // languages
  const dispatch = useDispatch();
  const { checkPermission } = usePermissions();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalOpenCreate, setIsModalOpenCreate] = useState(false);
  const [isModalOpenUpdate, setIsModalOpenUpdate] = useState(false);
  const [loading, setLoading] = useState<any>();
  const [roles, setRoles] = useState<any>();
  const [permissions, setPermissions] = useState<any>();
  const [detailRole, setDetailRole] = useState<any>();
  const [roleSelect, setRoleSelect] = useState<any>();
  const [isModalOpenDelete, setIsModalOpenDelete] = useState(false);

  const handleGetAllPermission = async () => {
    try {
      setLoading(true);
      const res = await roleApi.getAllPermission({});
      setPermissions(res.data);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };
  // Modal create viewpoint collection
  const [form] = Form.useForm();

  const showModalCreate = (value) => {
    setIsModalOpenCreate(true);
  };

  const handleOkCreate = () => {
    setIsModalOpenCreate(false);
  };

  const handleCancelCreate = async () => {
    try {
      setLoading(true);
      handleGetAllPermission();
    } catch (error) {
    } finally {
      setIsModalOpenCreate(false);
      setLoading(false);
    }
  };
  // Modal create viewpoint collection
  const showModalUpdate = (value) => {
    (async () => {
      try {
        setLoading(true);
        const res = await roleApi.getRoleById(value?.id);
        setDetailRole(res.data);
      } catch (error) {
      } finally {
        setLoading(false);
      }
    })();
    form.setFieldsValue(value);
    setIsModalOpenUpdate(true);
  };

  const handleOkUpdate = () => {
    setIsModalOpenUpdate(false);
  };

  const handleCancelUpdate = () => {
    // setValueSelect(null)
    setIsModalOpenUpdate(false);
  };
  //
  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const handleGetAllRole = async () => {
    try {
      setLoading(true);
      const res = await roleApi.getAllRole({});
      setRoles(res.data);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };
  const showModalDelete = (value) => {
    setRoleSelect(value);
    setIsModalOpenDelete(true);
  };
  const handleCancelDelete = () => {
    setRoleSelect(null);
    setIsModalOpenDelete(false);
  };
  const handleOkDelete = async () => {
    try {
      setLoading(true);
      await roleApi.deleteRole(roleSelect?.id);
      showSuccessNotification(t("common:delete_success"));
      handleGetAllRole();
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error.code}`));
    } finally {
      setIsModalOpenDelete(false);
      setLoading(false);
    }
  };

  useEffect(() => {
    handleGetAllRole();
  }, []);
  useEffect(() => {
    handleGetAllPermission();
  }, [isModalOpenCreate]);
  useEffect(() => {
    // console.log("");
  }, [detailRole]);
  const columns: ColumnsType<DataType> = [
    {
      title: t("role"),
      dataIndex: "role",
      key: "role",
      width: 200,
    },
    {
      title: t("last_updated_at"),
      dataIndex: "lastUpdate",
      key: "lastUpdate",
      width: 200,
    },
    {
      title: t("description"),
      key: "description",
      dataIndex: "description",
      width: 600,
    },
    {
      title: t("status"),
      key: "status",
      dataIndex: "status",
      width: 200,
    },
    {
      title: t("action"),
      key: "action",
      dataIndex: "action",
      width: 150,
    },
  ];
  let dataRoles;
  if (roles) {
    dataRoles = roles.map((role) => {
      return {
        key: role.id,
        role: role.name,
        description: role?.description,
        lastUpdate: new Date(role.createdAt).toLocaleString(),
        dateCreated: role.createdAt,
        status: role.isActive ? t("status_active") : t("status_inactive"),
        action: (
          <Space>
            {checkPermission(["ROLE.UPDATE"]) && (
              <Tooltip title={t("common:edit")}>
                <AiOutlineEdit
                  style={{ cursor: "pointer" }}
                  onClick={() => showModalUpdate(role)}
                />
              </Tooltip>
            )}
            {checkPermission(["ROLE.DELETE"]) && (
              <Tooltip title={t("common:delete")}>
                <AiOutlineDelete
                  style={{ cursor: "pointer" }}
                  onClick={() => showModalDelete(role)}
                />
              </Tooltip>
            )}
            {!checkPermission(["ROLE.DELETE", "ROLE.UPDATE"]) && (
              <Link
                to={"/"}
                onClick={(e) => {
                  e.preventDefault();
                }}
              >
                View Details
              </Link>
            )}
          </Space>
        ),
      };
    });
  }
  const data: DataType[] = dataRoles;
  // const data: DataType[] = [
  //   {
  //     key: "1",
  //     role: "Admin",
  //     lastUpdate: "2022 19/20",
  //     dateCreated: "2022 19/20",
  //     description: "Role for technical administrator who have all permission",
  //     status: "Active",
  //     action: (
  //       <Space size="middle">
  //         <BsTrash onClick={showModal} />
  //         <Modal
  //           title="Basic Modal"
  //           // open={isModalOpen}
  //           visible={isModalOpen}
  //           onOk={handleOk}
  //           onCancel={handleCancel}
  //         >
  //           <p>Some contents...</p>
  //           <p>Some contents...</p>
  //           <p>Some contents...</p>
  //         </Modal>
  //         <FiEdit />
  //       </Space>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     role: "Leader",
  //     lastUpdate: "2022 19/20",
  //     dateCreated: "2022 19/20",
  //     description: "Role for leader to approve request from tester",
  //     status: "Active",
  //     action: (
  //       <Space size="middle">
  //         <BsTrash />
  //         <FiEdit />
  //       </Space>
  //     ),
  //   },
  //   {
  //     key: "3",
  //     role: "Tester",
  //     lastUpdate: "2022 19/20",
  //     dateCreated: "2022 19/20",
  //     description: "Role for tester to work in project",
  //     status: "Active",
  //     action: (
  //       <Space size="middle">
  //         <BsTrash />
  //         <FiEdit />
  //       </Space>
  //     ),
  //   },
  // ];

  return (
    <RoleManagementWrapper>
      <BreadCrumb
        title={t("role_management")}
        previousTitle={t("home_page")}
        link="/"
        breadCrumb={true as boolean}
      />
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <Space size="middle">
          <div>
            {checkPermission(["ROLE.CREATE"]) && (
              <Button type="primary" onClick={showModalCreate}>
                {t("common:create")}
              </Button>
            )}

            {permissions && (
              <ModalCreate
                isModalOpenCreate={isModalOpenCreate}
                handleOkCreate={handleOkCreate}
                handleCancelCreate={handleCancelCreate}
                setIsModalOpenCreate={setIsModalOpenCreate}
                permissions={permissions}
                setPermissions={setPermissions}
                setLoading={setLoading}
                handleGetAllRole={handleGetAllRole}
              />
            )}
          </div>
        </Space>
      </div>
      <div className="mr-t-20">
        <LocaleProvider>
          <Table
            loading={loading}
            columns={columns}
            dataSource={data}
            pagination={
              data?.length <= 20
                ? {
                    defaultPageSize: 20,
                  }
                : {
                    defaultPageSize: 20,
                    showSizeChanger: true,
                    pageSizeOptions: ["20", "30", "40"],
                  }
            }
          />
          <Modal
            title={t("common:viewpoint_collection_delete")}
            visible={isModalOpenDelete}
            onOk={handleOkDelete}
            onCancel={handleCancelDelete}
            footer={[
              <Button key="back" onClick={handleCancelDelete}>
                {t("common:cancel")}
              </Button>,
              <Button key="submit" type="primary" onClick={handleOkDelete}>
                {t("common:delete")}
              </Button>,
            ]}
          >
            <p style={{ color: "var(--clr-text)" }}>
              {t("common:role_confirm_delete")}
            </p>
          </Modal>
        </LocaleProvider>
      </div>
      {detailRole && (
        <ModalUpdate
          isModalOpenUpdate={isModalOpenUpdate}
          handleOkUpdate={handleOkUpdate}
          handleCancelUpdate={handleCancelUpdate}
          setIsModalOpenUpdate={setIsModalOpenUpdate}
          form={form}
          detailRole={detailRole}
          permissions={permissions}
          setLoading={setLoading}
          setDetailRole={setDetailRole}
          handleGetAllRole={handleGetAllRole}
        />
      )}
    </RoleManagementWrapper>
  );
};
// margin: 40px 42px 40px 100px;

export default RoleManagement;
