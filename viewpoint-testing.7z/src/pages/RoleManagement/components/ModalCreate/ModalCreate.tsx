import { roleApi } from "@services/roleAPI";
import { FUNCTION } from "@utils/constants";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { showSuccessNotification } from "@utils/notificationUtils";
import { Button, Checkbox, Form, Input, Modal, Switch, Table } from "antd";
import type { CheckboxChangeEvent } from "antd/es/checkbox";
import type { ColumnsType } from "antd/es/table";
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";

interface DataType {
  key: React.Key;
  function: string;
  view: any;
  create: any;
  update: any;
  delete: any;
  clone: any;
  approve: any;
  reject: any;
}
const columns: ColumnsType<DataType> = [
  {
    title: "Function",
    dataIndex: "function",
  },
  {
    title: "View",
    dataIndex: "view",
  },
  {
    title: "Create",
    dataIndex: "create",
  },
  {
    title: "Update",
    dataIndex: "update",
  },
  {
    title: "Delete",
    dataIndex: "delete",
  },
  {
    title: "Clone",
    dataIndex: "clone",
  },
  {
    title: "Approve",
    dataIndex: "approve",
  },
  {
    title: "Reject",
    dataIndex: "reject",
  },
];

const ModalCreate = ({
  isModalOpenCreate,
  handleOkCreate,
  handleCancelCreate,
  setIsModalOpenCreate,
  permissions,
  setPermissions,
  setLoading,
  handleGetAllRole,
}) => {
  const { t } = useTranslation(["common", "validate"]); // languages
  const [data, setData] = useState<any>([]);
  const [permissionIds, setPermissionIds] = useState<any>([]);
  const [errorMessage, setErrorMessage] = useState<any>();

  const [form] = Form.useForm();
  const validateMessages = {
    required: t("validate:label_translate"),
    types: {
      email: t("common:email_validate"),
      number: t("common:number_validate"),
      name: t("validate:name_validate"),
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };
  const dispatch = useDispatch();
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);

  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    // console.log("selectedRowKeys changed: ", selectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };
  const onChange = (e: CheckboxChangeEvent, i) => {
    // console.log(i, "Check");
    if (e.target.checked) {
      setPermissionIds([...permissionIds, i?.[0]?.id]);
    } else {
      const unCheckValue = permissionIds.slice(
        permissionIds.indexOf(i?.[0].id),
        permissionIds.indexOf(i?.[0].id) + 1
      );
      const newArr = permissionIds.filter((e) => {
        return e !== unCheckValue[0];
      });
      setPermissionIds(newArr);
    }
    // console.log(`checked = ${e.target.checked}`, e);
  };
  const onFinish = async (values: any) => {
    try {
      setLoading(true);
      await roleApi.createRole({ ...values, permissionIds });
      showSuccessNotification(t("common:create_new_role_success"));
      handleGetAllRole();
      setIsModalOpenCreate(false);
    } catch (error) {
      setErrorMessage(error);
    } finally {
      setLoading(false);
    }
  };
  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };
  const changeState = () => {
    const newList = { Data: [] };
    for (let i = 0; i < permissions?.length; i++) {
      newList.Data.push({
        key: i,
        view:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("VIEW");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("VIEW");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        create:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("CREATE");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("CREATE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        update:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("UPDATE");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("UPDATE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        delete:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("DELETE");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("DELETE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        clone:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("CLONE");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("CLONE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        approve:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("APPROVE");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("APPROVE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        reject:
          permissions[i]?.permissions?.filter((x) => {
            return x?.name?.includes("REJECT");
          })?.length > 0 ? (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i]?.permissions?.filter((x) => {
                    return x?.name?.includes("REJECT");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox disabled></Checkbox>
          ),
        function: FUNCTION[i]?.func,
      });
    }
    setData(newList);
  };
  useEffect(() => {
    if (errorMessage) {
      form.setFields([
        {
          name: "roleName",
          errors: [t(`responseMessage:${errorMessage?.code}`)],
        },
      ]);
    }
  }, [errorMessage, form]);
  useEffect(() => {
    changeState();
    // console.log("call");
  }, [permissions, permissionIds]);
  return (
    <Modal
      title={t("common:create_role")}
      visible={isModalOpenCreate}
      onOk={() => handleOkCreate()}
      onCancel={() => {
        setPermissions(null);
        setPermissionIds([]);
        handleCancelCreate();
      }}
      width={1200}
      footer={null}
      style={{ top: 20 }}
    >
      <Form
        name="basic"
        form={form}
        labelAlign="left"
        labelCol={{
          span: 6,
        }}
        wrapperCol={{
          span: 17,
        }}
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        validateMessages={validateMessages}
      >
        <Form.Item
          label={t("common:name")}
          name="roleName"
          rules={[
            { required: true, message: t("validate:role_name_is_required") },
            {
              min: 2,
              message: t("validate:role_name_min_length"),
            },
            {
              max: 20,
              message: t("validate:role_name_max_length"),
            },
            {
              validator(_, value) {
                if (checkContainsSpecialCharacter(value?.trim())) {
                  return Promise.reject(
                    t("validate:role_name_can_not_contains_special_charaters")
                  );
                }
                return Promise.resolve();
              },
            },
          ]}
          validateTrigger={["onBlur", "onChange"]}
        >
          <Input placeholder={t("common:enter_name_role")} />
        </Form.Item>
        <Form.Item label={t("common:description")} name="description">
          <Input.TextArea
            rows={4}
            placeholder={t("common:enter_description_role")}
          />
        </Form.Item>
        <Form.Item
          label={t("common:status")}
          name="status"
          valuePropName="checked"
        >
          <Switch />
        </Form.Item>
        <div>
          <Table
            // scroll={{
            //   x: 1200,
            // }}
            rowKey={"key"}
            // rowSelection={rowSelection}
            columns={columns}
            dataSource={data?.Data}
            size="middle"
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: ["10", "20", "30"],
              // total: FUNCTION,
              defaultCurrent: 1,
              // onChange: onChange,
              showQuickJumper: true,
            }}
          />
        </div>
        <Form.Item wrapperCol={{ offset: 20, span: 4 }}>
          <div
            style={{ display: "flex", marginLeft: "10px", marginTop: "10px" }}
          >
            <Button
              type="default"
              htmlType="button"
              style={{ marginLeft: "12px" }}
              onClick={(): void => {
                setPermissions(null);
                setPermissionIds([]);
                handleCancelCreate();
              }}
            >
              {t("common:cancel")}
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              style={{ marginLeft: "12px" }}
            >
              {t("common:create")}
            </Button>
          </div>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ModalCreate;
