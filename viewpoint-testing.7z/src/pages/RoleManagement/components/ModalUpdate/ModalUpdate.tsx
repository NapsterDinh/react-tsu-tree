import { roleApi } from "@services/roleAPI";
import { FUNCTION } from "@utils/constants";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { showSuccessNotification } from "@utils/notificationUtils";
import { Button, Checkbox, Form, Input, Modal, Switch, Table } from "antd";
import type { CheckboxChangeEvent } from "antd/es/checkbox";
import type { ColumnsType } from "antd/es/table";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import { ModalUpdateWrapper } from "./ModelUpdateWrapper";
interface DataType {
  key: React.Key;
  function: string;
  view: any;
  create: any;
  edit: any;
  delete: any;
  clone: any;
  approve: any;
  reject: any;
}
const columns: ColumnsType<DataType> = [
  {
    title: "Function",
    dataIndex: "function",
  },
  {
    title: "View",
    dataIndex: "view",
  },
  {
    title: "Create",
    dataIndex: "create",
  },
  {
    title: "Update",
    dataIndex: "update",
  },
  {
    title: "Delete",
    dataIndex: "delete",
  },
  {
    title: "Clone",
    dataIndex: "clone",
  },
  {
    title: "Approve",
    dataIndex: "approve",
  },
  {
    title: "Reject",
    dataIndex: "reject",
  },
];

const ModalUpdate = ({
  isModalOpenUpdate,
  handleOkUpdate,
  handleCancelUpdate,
  setIsModalOpenUpdate,
  form,
  detailRole,
  permissions,
  setLoading,
  setDetailRole,
  handleGetAllRole,
}) => {
  const { t } = useTranslation(["common", "validate"]); // languages
  const validateMessages = {
    required: t("validate:label_translate"),
    types: {
      email: t("common:email_validate"),
      number: t("common:number_validate"),
      name: t("validate:name_validate"),
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };
  const initValueIds = () => {
    const res = [];
    detailRole.permissions.forEach((e) => {
      e.permissions.forEach((i) => {
        res.push(i.id);
      });
    });
    return res;
  };
  const dispatch = useDispatch();
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
  const [data, setData] = useState<any>([]);
  const [permissionIds, setPermissionIds] = useState<any>(initValueIds());
  const [errorMessage, setErrorMessage] = useState<any>();
  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };
  //
  const onFinish = async (values: any) => {
    try {
      setLoading(true);
      await roleApi.updatePermmissions({ permissionIds }, detailRole?.id);
      await roleApi.updateRole(values, detailRole?.id);
      handleGetAllRole();
      showSuccessNotification(t("common:update_role_success"));
      setIsModalOpenUpdate(false);
    } catch (error) {
      setErrorMessage(error);
    } finally {
      setLoading(false);
    }
  };
  const onFinishFailed = (errorInfo: any) => {
    // console.log("Failed:", errorInfo);
  };
  // handle click check box
  const onChange = (e, i) => {
    if (e.target.checked) {
      setPermissionIds([...permissionIds, i?.[0]?.id]);
    } else {
      const unCheckValue = permissionIds.slice(
        permissionIds.indexOf(i?.[0]?.id),
        permissionIds.indexOf(i?.[0]?.id) + 1
      );
      const newArr = permissionIds.filter((e) => {
        return e !== unCheckValue?.[0];
      });
      setPermissionIds(newArr);
    }
  };
  // console.log(valueSelect, "valueSelect in role")
  // let detailRole;
  // if (valueSelect?.name == "Admin") {
  //   dataForRole = dataUpdateForAdmin;
  // } else if (valueSelect?.name == "Leader") {
  //   dataForRole = dataUpdateForLeader;
  // } else if (valueSelect?.name == "Tester") {
  //   dataForRole = dataUpdateForTester;
  // }
  const changeState = () => {
    const b = detailRole.permissions.map((e) => e.functionName);
    const c = FUNCTION.map((e, i) => {
      if (b.includes(e.key)) {
        return {
          id: detailRole.permissions?.[b.indexOf(e.key)]?.id,
          functionName:
            detailRole.permissions?.[b.indexOf(e.key)]?.functionName,
          permissions: detailRole.permissions?.[b.indexOf(e.key)]?.permissions,
          permissionType:
            detailRole.permissions?.[b.indexOf(e.key)]?.permissionType,
        };
      } else {
        return {
          id: null,
          functionName: null,
          permissions: [],
          permissionType: null,
        };
      }
    });
    const newList = { Data: [] };
    for (let i = 0; i < FUNCTION.length; i++) {
      newList.Data.push({
        key: i,
        view:
          permissions[i].permissions.filter((a) => a.name.includes("VIEW"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("VIEW");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("VIEW");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("VIEW");
                  })
                )
              }
            ></Checkbox>
          ),
        create:
          permissions[i].permissions.filter((a) => a.name.includes("CREATE"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("CREATE");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("CREATE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("CREATE");
                  })
                )
              }
            ></Checkbox>
          ),
        update:
          permissions[i].permissions.filter((a) => a.name.includes("UPDATE"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("UPDATE");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("UPDATE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("UPDATE");
                  })
                )
              }
            ></Checkbox>
          ),
        delete:
          permissions[i].permissions.filter((a) => a.name.includes("DELETE"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("DELETE");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("DELETE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("DELETE");
                  })
                )
              }
            ></Checkbox>
          ),
        clone:
          permissions[i].permissions.filter((a) => a.name.includes("CLONE"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("CLONE");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("CLONE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("CLONE");
                  })
                )
              }
            ></Checkbox>
          ),
        approve:
          permissions[i].permissions.filter((a) => a.name.includes("APPROVE"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("APPROVE");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("APPROVE");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("APPROVE");
                  })
                )
              }
            ></Checkbox>
          ),
        reject:
          permissions[i].permissions.filter((a) => a.name.includes("REJECT"))
            .length == 0 ? (
            <Checkbox disabled></Checkbox>
          ) : c[i]?.permissions.filter((x) => {
              return x.name.includes("REJECT");
            })?.length > 0 ? (
            <Checkbox
              defaultChecked
              onChange={(e) =>
                onChange(
                  e,
                  c[i]?.permissions.filter((x) => {
                    return x.name.includes("REJECT");
                  })
                )
              }
            ></Checkbox>
          ) : (
            <Checkbox
              onChange={(e) =>
                onChange(
                  e,
                  permissions[i].permissions.filter((x) => {
                    return x.name.includes("REJECT");
                  })
                )
              }
            ></Checkbox>
          ),
        function: FUNCTION[i].func as string,
      });
    }
    // console.log(newList, "newList");
    setData(newList);
  };
  useEffect(() => {
    changeState();
  }, [detailRole, permissionIds]);
  useEffect(() => {
    if (errorMessage) {
      form.setFields([
        {
          name: "roleName",
          errors: [t(`responseMessage:${errorMessage?.code}`)],
        },
      ]);
    }
  }, [errorMessage, form]);
  return (
    <ModalUpdateWrapper>
      <Modal
        title={t("common:update_role")}
        visible={isModalOpenUpdate}
        onOk={() => handleOkUpdate()}
        onCancel={() => {
          setPermissionIds([]);
          setData({ Data: [] });
          // form.resetFields();
          setDetailRole(null);
          handleCancelUpdate();
        }}
        width={1200}
        footer={null}
        style={{ top: 20 }}
      >
        <Form
          name="basic"
          labelAlign="left"
          labelCol={{
            span: 6,
          }}
          wrapperCol={{
            span: 17,
          }}
          // initialValues={{ remember: false }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          autoComplete="off"
          validateMessages={validateMessages}
        >
          <Form.Item
            label={t("common:name")}
            name="roleName"
            rules={[
              { required: true, message: t("validate:role_name_is_required") },
              {
                min: 2,
                message: t("validate:role_name_min_length"),
              },
              {
                max: 20,
                message: t("validate:role_name_max_length"),
              },
              {
                validator(_, value) {
                  if (checkContainsSpecialCharacter(value?.trim())) {
                    return Promise.reject(
                      t("validate:role_name_can_not_contains_special_charaters")
                    );
                  }
                  return Promise.resolve();
                },
              },
            ]}
            validateTrigger={["onBlur", "onChange"]}
            initialValue={detailRole?.name}
          >
            <Input placeholder={t("common:enter_name_role")} />
          </Form.Item>

          <Form.Item
            label={t("common:description")}
            name="description"
            initialValue={detailRole?.description}
          >
            <Input.TextArea
              rows={4}
              placeholder={t("common:enter_description_role")}
            />
          </Form.Item>
          <Form.Item
            label={t("common:status")}
            name="isActive"
            valuePropName="checked"
            initialValue={detailRole?.isActive}
          >
            <Switch />
          </Form.Item>
          <div>
            <Table
              // scroll={{
              //   x: 1200,
              // }}
              rowKey={"key"}
              // rowSelection={rowSelection}
              columns={columns}
              dataSource={data.Data}
              size="middle"
              pagination={{
                defaultPageSize: 10,
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "30"],
                // total: FUNCTION,
                defaultCurrent: 1,
                // onChange: onChange,
                showQuickJumper: true,
              }}
            />
          </div>
          <Form.Item wrapperCol={{ offset: 19, span: 5 }}>
            <div
              style={{
                display: "flex",
                // marginLeft: "10px",
                marginTop: "10px",
                marginLeft:
                  localStorage.getItem("i18nextLng") == "jpn"
                    ? "10px"
                    : localStorage.getItem("i18nextLng") == "vi"
                    ? "65px"
                    : "60px",
              }}
            >
              <Button
                type="default"
                htmlType="button"
                style={{ marginLeft: "12px" }}
                onClick={(): void => {
                  setPermissionIds([]);

                  setIsModalOpenUpdate(false);
                }}
              >
                {t("common:cancel")}
              </Button>
              <Button
                type="primary"
                htmlType="submit"
                style={{ marginLeft: "12px" }}
              >
                {t("common:update")}
              </Button>
            </div>
          </Form.Item>
        </Form>
      </Modal>
    </ModalUpdateWrapper>
  );
};

export default ModalUpdate;
