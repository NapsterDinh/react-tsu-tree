import styled from "styled-components";

export const RoleManagementWrapper = styled.div`
  .mr-t-20 {
    margin-top: 20px;
  }
  color: var(--clr-text);
  svg {
    font-size: var(--font-size-icon-action-table)!important;
  }
`;
