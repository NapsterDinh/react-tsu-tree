import { BreadCrumb } from "@components";
import React from "react";
import styled from "styled-components";
const FunctionList: React.FC = () => {
  return (
    <Wrapper>
      <BreadCrumb title="Function List" />
    </Wrapper>
  );
};

const Wrapper = styled.div`
  margin: 40px 100px;
`;

export default FunctionList;
