import { yupResolver } from "@hookform/resolvers/yup";
import ViewpointCategoryAPI from "@services/categoryAPI";
import {
  MAX_LENGTH_INPUT_NAME_FIELD,
  MAX_LENGTH_TEXT_AREA,
  MIN_LENGTH_INPUT,
  ROWS_DEFAULT_TEXT_AREA,
} from "@utils/constantsUI";
import { checkContainsSpecialCharacter } from "@utils/helpersUtils";
import { showSuccessNotification } from "@utils/notificationUtils";
import { Button, Form, Input, Modal, Space, Switch } from "antd";
import { useEffect, useMemo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import * as yup from "yup";

const { TextArea } = Input;

export type ModalCategoryProps = {
  open: boolean;
  handleCancel: () => void;
  item: any;
  handleCallAPI: () => void;
};
const ModalCategory: React.FC<ModalCategoryProps> = ({
  open,
  handleCancel,
  item,
  handleCallAPI,
}) => {
  const { t } = useTranslation(["common", "validate", "responseMessage"]);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const schema = useMemo(
    () =>
      yup
        .object({
          name: yup
            .string()
            .required(t("validate:category_name_required"))
            .trim()
            .max(
              MAX_LENGTH_INPUT_NAME_FIELD,
              t("validate:category_name_max_length")
            )
            .min(MIN_LENGTH_INPUT, t("validate:category_name_min_length"))
            .test(
              "Name",
              t("validate:category_name_not_contains_special_characters"),
              (value) => !checkContainsSpecialCharacter(value.trim())
            ),
          description: yup
            .string()
            .required(t("validate:description_required"))
            .trim()
            .max(MAX_LENGTH_TEXT_AREA, t("validate:description_max_length"))
            .min(MIN_LENGTH_INPUT, t("validate:description_min_length")),
          isActive: yup.boolean().default(true),
        })
        .required(),
    []
  );

  const {
    control,
    setValue,
    handleSubmit,
    clearErrors,
    setError,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues:
      item === ""
        ? {
            name: "",
            description: "",
            isActive: true,
          }
        : item,
  });

  useEffect(() => {
    if (item !== "") {
      setValue("name", item.name);
      setValue("description", item.description);
      setValue("isActive", item.isActive);
    }
  }, [item]);

  const onSubmit = async (values) => {
    try {
      setConfirmLoading(true);
      if (item !== "") {
        await ViewpointCategoryAPI.editCategory(values, item.id);
        showSuccessNotification(t("common:edit_category_success"));
      } else {
        await ViewpointCategoryAPI.createNewCategory(values);
        showSuccessNotification(t("common:create_new_category_success"));
      }
      await handleCallAPI();
      handleCancel();
      reset();
    } catch (error) {
      setError("name", { message: t(`responseMessage:${error?.code}`) });
    } finally {
      setConfirmLoading(false);
    }
  };

  return (
    <Modal
      title={
        item === ""
          ? t("common:create_new_category")
          : t("common:edit_category")
      }
      visible={open}
      width={800}
      onCancel={() => {
        handleCancel();
        clearErrors();
        reset();
      }}
      maskClosable={false}
      footer={null}
    >
      <Form
        name="basic"
        labelAlign="left"
        labelCol={{
          span: 6,
        }}
        wrapperCol={{
          span: 17,
        }}
        onFinish={handleSubmit(onSubmit)}
        autoComplete="off"
      >
        <Form.Item
          className={errors.name && "error-message"}
          label={t("common:name") + "*"}
        >
          <Controller
            name="name"
            control={control}
            render={({ field }) => {
              return (
                <>
                  <Input
                    {...field}
                    placeholder={t("common:enter_name_category")}
                  />
                  {errors.name && (
                    <span className="color-red">
                      {errors.name?.message as string}
                    </span>
                  )}
                </>
              );
            }}
          />
        </Form.Item>

        <Form.Item
          className={errors.description && "error-message"}
          label={t("common:description") + "*"}
        >
          <Controller
            name="description"
            control={control}
            render={({ field }) => {
              const props = {
                ...field,
              };
              return (
                <>
                  <TextArea
                    showCount
                    rows={ROWS_DEFAULT_TEXT_AREA}
                    {...field}
                    // maxLength={MAX_LENGTH_TEXT_AREA}
                    {...field}
                    placeholder={t("common:enter_description_category")}
                  />
                  {errors.description && (
                    <span className="color-red">
                      {errors.description?.message as string}
                    </span>
                  )}
                </>
              );
            }}
          />
        </Form.Item>

        <Form.Item
          validateStatus={errors.isActive ? "error" : ""}
          help={errors.isActive?.message as string}
          label={t("common:status_active")}
        >
          <Controller
            name="isActive"
            control={control}
            render={({ field }) => {
              const props = {
                ...field,
              };
              return <Switch {...props} checked={field.value} />;
            }}
          />
        </Form.Item>
        <Space style={{ justifyContent: "right", width: "100%" }}>
          <Button
            onClick={() => {
              handleCancel();
              clearErrors();
              reset();
            }}
            className="btn-secondary btn-outlined"
            block
          >
            {t("common:cancel")}
          </Button>
          <Button
            type="primary"
            loading={confirmLoading}
            block
            htmlType="submit"
          >
            {t("common:save")}
          </Button>
        </Space>
      </Form>
    </Modal>
  );
};

export default ModalCategory;
