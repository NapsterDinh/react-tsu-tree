import { productActions, viewpointCollectionActions } from "@redux/slices";
import productAPI from "@services/productAPI";
import {
  checkContainsSpecialCharacter,
  removeEmoji,
} from "@utils/helpersUtils";
import { showSuccessNotification } from "@utils/notificationUtils";
import { Button, Form, Input, Modal, Select, TreeSelect } from "antd";
import { Option } from "antd/lib/mentions";
import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
const { SHOW_PARENT } = TreeSelect;

const ModalCreate = ({
  isModalOpenCreate,
  handleOkCreate,
  handleCancelCreate,
  domainTree,
  setIsModalOpenCreate,
  loading,
  setLoading,
  handleCallAPI,
}) => {
  const { t } = useTranslation(["common", "validate"]); // languages
  const [form] = Form.useForm();
  const [value, setValue] = useState([]);
  const [errorMessage, setErrorMessage] = useState<any>();

  const validateMessages = {
    required: t("validate:label_translate"),
    types: {
      email: t("common:email_validate"),
      number: t("common:number_validate"),
      name: t("validate:name_validate"),
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };
  const dispatch = useDispatch();
  const user = JSON.parse(localStorage.getItem("user"));
  const onFinish = async (values: any) => {
    try {
      const contentLanguage = localStorage.getItem("i18nextLng");
      const res = {
        detail: JSON.stringify([
          {
            name: values.name,
            description: values.description,
            language: contentLanguage,
          },
        ]),
        domainIds: values.domainIds.map((domainId) => domainId.value),
        status: 0,
        createdBy: user?.id,
        updateBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
      };

      await productAPI.createProduct({
        payload: res,
      });
      showSuccessNotification(t("common:create_new_product_success"));
      handleCallAPI();
      form.resetFields();
      setIsModalOpenCreate(false);
    } catch (error) {
      setErrorMessage(error);
    } finally {
      setLoading(false);
    }
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };

  const onChangeTreeDomain = (newValue: string[]) => {
    setValue(newValue);
  };
  const treeSelectProps = {
    treeData: domainTree,
    value,
    onChange: onChangeTreeDomain,
    // onSelect,
    treeCheckable: true,
    treeCheckStrictly: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: t("common:select_domain"),
    style: {
      width: "100%",
    },
    filterTreeNode: (search, item) => {
      return item.title.toLowerCase().indexOf(search.toLowerCase()) >= 0;
    },
  };
  useEffect(() => {
    if (errorMessage) {
      form.setFields([
        {
          name: "name",
          errors: [t(`responseMessage:${errorMessage?.code}`)],
        },
      ]);
    }
  }, [errorMessage, form]);
  return (
    <Modal
      title={t("common:create_product")}
      visible={isModalOpenCreate}
      onOk={handleOkCreate}
      onCancel={() => {
        handleCancelCreate();
        setErrorMessage(null);
        form.resetFields();
      }}
      width={800}
      footer={[
        <Button
          onClick={() => {
            setIsModalOpenCreate(false);
            form.resetFields();
            setErrorMessage(null);
          }}
        >
          {t("common:cancel")}
        </Button>,
        <Button
          form="createViewpointCollection"
          type="primary"
          htmlType="submit"
        >
          {t("common:create")}
        </Button>,
      ]}
    >
      <Form
        name="basic"
        id="createViewpointCollection"
        labelAlign="left"
        form={form}
        labelCol={{
          span: 6,
        }}
        wrapperCol={{
          span: 17,
        }}
        initialValues={{ remember: true }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
        validateMessages={validateMessages}
      >
        <Form.Item
          label={t("common:name")}
          name="name"
          required
          rules={[
            {
              validator(_, value) {
                if (!value) {
                  return Promise.reject(t("validate:product_name"));
                } else if (value.startsWith(" ") || value.endsWith(" ")) {
                  return Promise.reject(t("validate:viewpoint_trim_space"));
                } else if (checkContainsSpecialCharacter(value)) {
                  return Promise.reject(
                    t("validate:viewpoint_name_contains_special_character")
                  );
                } else if (removeEmoji(value)) {
                  return Promise.reject(
                    t("validate:viewpoint_name_contains_special_character")
                  );
                }
                return Promise.resolve();
              },
            },
            {
              min: 6,
              message: t("validate:name_product_min_length"),
            },
            {
              max: 30,
              message: t("validate:name_product_max_length"),
            },
          ]}
          validateTrigger={["onBlur", "onChange"]}
        >
          <Input placeholder={t("common:enter_name_product")} />
        </Form.Item>

        <Form.Item
          label={t("common:domain")}
          name="domainIds"
          rules={[
            {
              required: true,
              message: t("validate:name_product_with_domain_list"),
            },
          ]}
          validateTrigger={["onBlur", "onChange"]}
        >
          <TreeSelect {...treeSelectProps} />
        </Form.Item>

        <Form.Item
          label={t("common:description")}
          name="description"
          required
          rules={[
            {
              validator(_, value) {
                if (!value) {
                  return Promise.reject(t("validate:viewpoint_description"));
                } else if (value.startsWith(" ") || value.endsWith(" ")) {
                  return Promise.reject(t("validate:viewpoint_trim_space"));
                } else if (checkContainsSpecialCharacter(value)) {
                  return Promise.reject(
                    t("validate:description_name_contains_special_character")
                  );
                } else if (removeEmoji(value)) {
                  return Promise.reject(
                    t("validate:description_name_contains_special_character")
                  );
                }
                return Promise.resolve();
              },
            },
            {
              max: 1200,
              message: t("validate:description_product_max_length"),
            },
          ]}
        >
          <Input.TextArea
            rows={5}
            placeholder={t("common:enter_description_product")}
          />
        </Form.Item>
        <Form.Item initialValue={"0"} label={t("common:status")} name="status">
          <Select style={{ width: 180 }}>
            <Option value="0">{t("common:on_going")}</Option>
            <Option value="1">{t("common:public")}</Option>
            <Option value="2">{t("common:private")}</Option>
          </Select>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ModalCreate;
