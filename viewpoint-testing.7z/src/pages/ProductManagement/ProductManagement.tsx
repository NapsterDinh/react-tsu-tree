import { BreadCrumb, LocaleProvider } from "@components";
import { usePermissions } from "@hooks/usePermissions";
import { rootState } from "@models/type";
import { domainActions } from "@redux/slices";
import { productActions } from "@redux/slices/productSlice";
import productAPI from "@services/productAPI";
import { SORT } from "@utils/constants";
import {
  showErrorNotification,
  showSuccessNotification,
} from "@utils/notificationUtils";
import {
  Button,
  Form,
  Input,
  Modal,
  Select,
  Space,
  Table,
  Tag,
  Tooltip,
  TreeSelect,
} from "antd";
import type { ColumnsType } from "antd/es/table";
import type { DataNode } from "antd/es/tree";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { BiDetail } from "react-icons/bi";
import { BsTrash } from "react-icons/bs";
import { FaRegClone } from "react-icons/fa";
import { useDispatch, useSelector } from "react-redux";
import {
  createSearchParams,
  Link,
  URLSearchParamsInit,
  useLocation,
  useSearchParams,
} from "react-router-dom";
import { routes } from "routes";
import ModalClone from "./components/ModalClone/ModalClone";
import ModalCreate from "./components/ModalCreate/ModalCreate";
import { ProductManagementWrapper } from "./ProductManagementWrapper";
const { Option } = Select;
const { Search } = Input;
const { SHOW_PARENT } = TreeSelect;

const convertTreeData = (table) => {
  const keys = table.map((x) => x?.id);
  const formattedData = table.map((x) => {
    return {
      key: x.id,
      title: x.detail.name,
      parentKey: x?.parentId,
      value: x?.id,
    };
  });
  const result = formattedData
    .map((parent) => {
      const children = formattedData.filter((child) => {
        if (child.key !== child.parentKey && child.parentKey === parent.key) {
          return true;
        }
        return false;
      });

      if (children.length) {
        parent.children = children;
      }
      return parent;
    })
    .filter((obj) => {
      if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
        return true;
      }
      return false;
    });
  return result;
};

const ViewpointCollection = () => {
  const { t } = useTranslation(["common", "validate"]); // languages
  const { domain } = useSelector((state: rootState) => state.domain);
  const user = localStorage.getItem("user")
    ? JSON.parse(localStorage.getItem("user"))
    : null;
  // const { products, loading } = useSelector(
  //   (state: rootState) => state.product
  // );
  const [form] = Form.useForm();
  const [valueSelect, setValueSelect] = useState<any>();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isModalOpenCreate, setIsModalOpenCreate] = useState(false);
  const [isModalOpenDelete, setIsModalOpenDelete] = useState(false);
  const [viewpointSelect, setViewpointSelect] = useState([]);
  const [collectionSelect, setCollectionSelect] = useState();
  const [dataTree, setDataTree] = useState([]);
  const [messageClone, setMessageClone] = useState<any>(null);
  const [loading, setLoading] = useState<any>(null);
  const [products, setProducts] = useState<any>(null);

  // filter
  const [searchParams, setSearchParams] = useSearchParams();
  const [domainIds, setDomainIds] = useState(searchParams.getAll("DomainIds"));
  const [sort, setSort] = useState(searchParams.get("Sort"));
  const [status, setStatus] = useState(searchParams.get("Status"));
  const [searchContent, setSearchContent] = useState(searchParams.get("Text"));
  const { checkPermission } = usePermissions();

  const dispatch = useDispatch();

  // Modal clone collection
  const showModal = (value) => {
    setValueSelect(value);
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setViewpointSelect([]);
    setIsModalOpen(false);
  };
  // Modal create viewpoint collection
  const showModalCreate = (value) => {
    setIsModalOpenCreate(true);
  };

  const handleOkCreate = () => {
    setIsModalOpenCreate(false);
  };

  const handleCancelCreate = () => {
    setIsModalOpenCreate(false);
  };
  // Modal delete collection
  const showModalDelete = (value) => {
    setCollectionSelect(value);
    setIsModalOpenDelete(true);
  };

  const handleOkDelete = async () => {
    try {
      setLoading(true);

      await productAPI.deleteProduct({
        payload: collectionSelect,
      });
      showSuccessNotification(t("common:delete_success"));
      handleCallAPI();
    } catch (error) {
      showErrorNotification(t(`responseMessage:${error.code}`));
    } finally {
      setIsModalOpenDelete(false);
      setLoading(false);
    }
  };

  const handleCancelDelete = () => {
    setCollectionSelect(null);
    setIsModalOpenDelete(false);
  };
  //
  const location = useLocation();

  const handleSelectMultipleDomain = (values) => {
    const newDomainIds = values.map((item) => item.value);
    setDomainIds(newDomainIds);
  }; // handle select multiple domain to filter

  const handleSelectSort = (value) => {
    setSort(value);
  }; // handle select sort

  const handleSelectStatus = (value) => {
    setStatus(value);
  }; // handle select sort

  const handleEnterInputSearch = (value) => {
    setSearchContent(value.trim());
  }; // handle enter search to set content search

  // handle call get all product
  const handleCallAPI = async () => {
    try {
      setLoading(true);
      const res: any = await productAPI.getAllProduct({
        payload: {
          search: location.search,
        },
      });
      setProducts(res);
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };
  // filter when params has changed
  useEffect(() => {
    const params: URLSearchParamsInit = {};
    if (domainIds.length) {
      params.DomainIds = domainIds;
    }
    if (sort) {
      params.Sort = sort;
    }
    if (status) {
      params.Status = status;
    }
    if (searchContent) {
      params.Text = searchContent;
    }
    setSearchParams(createSearchParams(params));
  }, [domainIds, sort, status, searchContent]);

  useEffect(() => {
    setDataTree(convertTreeData(domain));
  }, [domain]);
  //  function submit clone collection
  const onFinish = async (values: any) => {
    try {
      const contentLanguage = localStorage.getItem("i18nextLng");
      const res = {
        detail: JSON.stringify([
          {
            name: values.name,
            language: contentLanguage,
            description: values.description,
          },
        ]),
        cloneCollectionId: valueSelect.id,
        domainIds: values.domainIds.map((domainId) => domainId.value),
        viewPoints: viewpointSelect.map((e) => {
          return {
            confirmation: e.confirmation,
            createdAt: e.createdAt,
            createdBy: e.createdBy,
            id: e.id,
            image: e?.image,
            isActive: e.isActive,
            isDeleted: e.isDeleted,
            parentId: e.parentId,
            sample: e.sample,
            testTypeId: e.testTypeId,
            updateBy: e.updateBy,
            updatedAt: e.updatedAt,
            viewDetail: JSON.stringify([e.viewDetail]),
            viewPointCategoryId: e.viewPointCategoryId,
            viewPointCollectionId: e.viewPointCollectionId,
          };
        }),
        status: 0,
      };

      await productAPI.cloneProduct({
        clone: res,
        search: location.search,
      });

      handleCallAPI();
      setIsModalOpen(false);
      form.resetFields();
      setViewpointSelect(null);
      setValueSelect(null);
    } catch (error) {
      // console.log(error, "error");
      setMessageClone(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (messageClone) {
      form.setFields([
        {
          name: "name",
          errors: [t(`responseMessage:${messageClone?.code}`)],
        },
      ]);
    }
  }, [messageClone]);

  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };

  useEffect(() => {
    dispatch(domainActions.getDomain());
  }, []);

  useEffect(() => {
    handleCallAPI();
  }, [location.search]);

  // tree

  // const [expandedKeys, setExpandedKeys] = useState<React.Key[]>([
  //   "0-0-0",
  //   "0-0-1",
  // ]);
  const [checkedKeys, setCheckedKeys] = useState<React.Key[]>([""]);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);
  const [autoExpandParent, setAutoExpandParent] = useState<boolean>(true);

  const onExpand = (expandedKeysValue: React.Key[]) => {
    // if not set autoExpandParent to false, if children expanded, parent can not collapse.
    // or, you can remove all expanded children keys.
    // setExpandedKeys(expandedKeysValue);
    setAutoExpandParent(false);
  };

  let dataViewpoint;
  // convert data when we have a viewpointCollection and click on the icon clone collection
  if (products && valueSelect) {
    const res = products.data.filter(
      (viewpoint) => viewpoint.id == valueSelect?.id
    );
    // function convert data to format tree in antd

    const convertTreeData = (table) => {
      const keys = table.map((x) => x?.id);
      const formattedData = table.map((x) => {
        return {
          key: x.id,
          title: x.viewDetail.name,
          // JSON.parse(x.viewDetail)[0]?.Name
          parentKey: x?.parentId,
          description: x?.description,
          isActive: x?.isActive,
        };
      });
      const result = formattedData
        .map((parent) => {
          const children = formattedData.filter((child) => {
            if (
              child.key !== child.parentKey &&
              child.parentKey === parent.key
            ) {
              return true;
            }
            return false;
          });
          if (children.length) {
            parent.children = children;
          }
          return parent;
        })
        .filter((obj) => {
          if (obj.key === obj.parentKey || !keys.includes(obj.parentKey)) {
            return true;
          }
          return false;
        });
      return result;
    };
    if (res[0]?.viewPoints?.length > 0) {
      dataViewpoint = convertTreeData(res[0]?.viewPoints);
    } else {
      dataViewpoint = [];
    }
  }
  // function check and uncheck viewpoint
  const onCheck = (checkedKeysValue: any, infor) => {
    const array = [];
    const res = products.data.filter(
      (viewpoint) => viewpoint.id == valueSelect?.id
    );
    if (infor.halfCheckedKeys.length == 0) {
      checkedKeysValue.forEach((node) => {
        res.forEach((value) => {
          value.viewPoints.forEach((viewpoint) => {
            if (viewpoint.id == node) {
              array.push(viewpoint);
            }
          });
        });
      });
    } else {
      checkedKeysValue.forEach((node) => {
        res.forEach((value) => {
          value.viewPoints.forEach((viewpoint) => {
            if (viewpoint.id == node) {
              array.push(viewpoint);
            }
          });
        });
      });
      infor.halfCheckedKeys.forEach((key) => {
        res.forEach((value) => {
          value.viewPoints.forEach((viewpoint) => {
            if (viewpoint.id == key) {
              array.push(viewpoint);
            }
          });
        });
      });
    }
    setViewpointSelect(array);
    setCheckedKeys(checkedKeysValue);
  };

  const onSelect = (selectedKeysValue: React.Key[], info: any) => {
    setSelectedKeys(selectedKeysValue);
  };
  const treeData0: DataNode[] = dataViewpoint;
  // //end data tree
  // // table
  interface DataType {
    key: string;
    name: string;
    status: string;
    rating: string;
    lastUpdate: string;
    createdAt: string;
    action: any;
  }

  const columns: ColumnsType<DataType> = [
    {
      title: t("common:name"),
      dataIndex: "name",
      key: "name",
    },
    {
      title: t("common:status"),
      dataIndex: "status",
      key: "status",
    },
    {
      title: t("common:rating"),
      dataIndex: "rating",
      key: "rating",
    },
    {
      title: t("common:last_updated_at"),
      key: "lastUpdate",
      dataIndex: "lastUpdate",
    },
    {
      title: t("common:owner"),
      key: "owner",
      dataIndex: "owner",
    },
    {
      title: t("common:action"),
      key: "action",
      dataIndex: "action",
      align: "center",
    },
  ];

  // tree select filter
  const treeSelectProps = {
    treeData: dataTree,
    value: domainIds,
    onChange: handleSelectMultipleDomain,
    treeCheckable: true,
    treeCheckStrictly: true,
    showCheckedStrategy: SHOW_PARENT,
    placeholder: t("common:select_domain"),
    style: {
      width: "100%",
    },
    filterTreeNode: (search, item) => {
      return item.title.toLowerCase().indexOf(search.toLowerCase()) >= 0;
    },
  };
  // end tree select filter
  let viewpointData;
  if (products) {
    viewpointData = products.data.map((value) => {
      if (value.status == 0) {
        return {
          key: value?.id,
          id: value?.id,
          status:
            value.status == 0
              ? t("common:on_going")
              : value.status == 1
              ? t("common:public")
              : value.status == 2
              ? t("common:private")
              : "",
          rating: value?.rating?.startRating ?? t("common:not_rating"),
          lastUpdate: new Date(value.updatedAt).toLocaleString(),
          createdAt: new Date(value.createdAt).toLocaleString(),
          name: (
            <div>
              {value.detail.name}

              {value?.cloneCollectionId ? null : (
                <Tag
                  style={{ marginLeft: "5px", color: "#fff" }}
                  color="#87d068"
                >
                  Base
                </Tag>
              )}
            </div>
          ),
          owner: value?.userCreate?.account,
          action: (
            <ProductManagementWrapper>
              <Space size="middle" key={value?.id}>
                {checkPermission(["PRODUCT.DELETE"]) &&
                value?.userCreate?.account === user?.account ? (
                  <Tooltip title={t("common:delete")}>
                    <BsTrash
                      className="icon-action"
                      onClick={() => showModalDelete(value)}
                    />
                  </Tooltip>
                ) : (
                  <BsTrash className="icon-action" style={{ opacity: "0" }} />
                )}
                {checkPermission(["PRODUCT.VIEW"]) ? (
                  <Tooltip title={t("common:edit")}>
                    <Link
                      to={routes.ProductManagement.path[0] + `/${value?.id}`}
                    >
                      <BiDetail className="icon-action" />
                    </Link>
                  </Tooltip>
                ) : (
                  <BiDetail className="icon-action" style={{ opacity: "0" }} />
                )}
                {checkPermission(["PRODUCT.CLONE"]) ? (
                  <Tooltip title={t("common:clone")}>
                    <FaRegClone
                      className="icon-action"
                      onClick={() => showModal(value)}
                    />
                  </Tooltip>
                ) : (
                  <FaRegClone
                    className="icon-action"
                    style={{ opacity: "0" }}
                  />
                )}
              </Space>
            </ProductManagementWrapper>
          ),
        };
      }
    });
  }
  const onChange = (page, pageSize) => {
    (async () => {
      try {
        setLoading(true);
        const res: any = await productAPI.getAllProduct({
          payload: {
            search: location.search,
            PageSize: pageSize,
            PageNumber: page,
          },
        });
        setProducts(res);
      } catch (error) {
      } finally {
        setLoading(false);
      }
    })();
  };

  const data: DataType[] = viewpointData;
  return (
    <ProductManagementWrapper>
      <BreadCrumb
        title={t("common:product_management")}
        link="/"
        previousTitle={t("home_page")}
        breadCrumb={true as boolean}
      />
      <Space
        align="end"
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: "1rem",
        }}
      >
        <Space>
          <Space direction="vertical">
            <span>{t("common:domain")}</span>
            <TreeSelect {...treeSelectProps} style={{ width: 180 }} />
          </Space>
          <Space direction="vertical">
            <span>{t("common:sort")}</span>
            <Select
              defaultValue={
                searchParams.get("Sort")
                  ? searchParams.get("Sort")
                  : SORT.DEFAULT
              }
              style={{ width: 180 }}
              onChange={handleSelectSort}
            >
              <Option value={SORT.DEFAULT}>{t("common:no_sort")}</Option>
              <Option value={SORT.ACS}>{t("common:sort_by_name_a_z")}</Option>
              <Option value={SORT.DESC}>{t("common:sort_by_name_z_a")}</Option>
            </Select>
          </Space>
          <Space direction="vertical">
            <span>{t("common:status")}</span>
            <Select
              defaultValue={
                searchParams.get("Status") ? searchParams.get("Status") : "3"
              }
              style={{ width: 180 }}
              onChange={handleSelectStatus}
            >
              <Option value="0">{t("common:on_going")}</Option>
              <Option value="1">{t("common:public")}</Option>
              <Option value="2">{t("common:private")}</Option>
              <Option value="3">{t("common:all_of_status")}</Option>
            </Select>
          </Space>
          <Space direction="vertical">
            <span>{t("common:search")}</span>
            <Search
              placeholder={t("common:enter_search_text")}
              onSearch={handleEnterInputSearch}
              enterButton="Search"
              maxLength={20}
              style={{ width: 300 }}
              defaultValue={searchParams.get("Text")}
            />
          </Space>
        </Space>
        <Button type="primary" onClick={showModalCreate}>
          {t("common:create")}
        </Button>
      </Space>
      <LocaleProvider>
        <Table
          scroll={{
            x: 600,
          }}
          loading={loading}
          rowKey={"id"}
          columns={columns}
          dataSource={data}
          pagination={
            products?.metaData?.totalCount > 20
              ? {
                  defaultPageSize: 20,
                  showSizeChanger: true,
                  pageSizeOptions: ["20", "30", "50"],
                  total: products?.metaData?.totalCount,
                  defaultCurrent: 1,
                  onChange: onChange,
                  showQuickJumper: true,
                }
              : false
          }
        />
      </LocaleProvider>

      <ModalCreate
        isModalOpenCreate={isModalOpenCreate}
        handleOkCreate={handleOkCreate}
        handleCancelCreate={handleCancelCreate}
        domainTree={dataTree}
        setIsModalOpenCreate={setIsModalOpenCreate}
        loading={loading}
        setLoading={setLoading}
        handleCallAPI={handleCallAPI}
      />
      <ModalClone
        isModalOpen={isModalOpen}
        handleOk={handleOk}
        handleCancel={handleCancel}
        setIsModalOpen={setIsModalOpen}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        form={form}
        valueSelect={valueSelect}
        domain={domain}
        onExpand={onExpand}
        autoExpandParent={autoExpandParent}
        checkedKeys={checkedKeys}
        onCheck={onCheck}
        onSelect={onSelect}
        selectedKeys={selectedKeys}
        treeData0={treeData0}
        t={t}
      />
      <Modal
        title={t("common:product_delete")}
        visible={isModalOpenDelete}
        onOk={handleOkDelete}
        onCancel={handleCancelDelete}
        footer={[
          <Button key="back" onClick={handleCancelDelete}>
            {t("common:cancel")}
          </Button>,
          <Button key="submit" type="primary" onClick={handleOkDelete}>
            {t("common:delete")}
          </Button>,
        ]}
      >
        <p style={{ color: "var(--clr-text)" }}>
          {t("common:product_confirm_delete")}
        </p>
      </Modal>
    </ProductManagementWrapper>
  );
};

export default ViewpointCollection;
