import { DataTreeNode } from "@models/type";
import {
  checkContainsSpecialCharacter,
  removeEmoji,
} from "@utils/helpersUtils";
import { Button, Form, Input, Modal } from "antd";
import { FormInstance } from "antd/es/form/Form";
import React from "react";
import { useTranslation } from "react-i18next";

interface IProps {
  visible: boolean;
  onCancel: () => void;
  onFinish: (values: {
    name: string;
    description: string;
    parentId: React.Key;
  }) => void;
  form: FormInstance<any>;
  loading: boolean;
  flattenedData: DataTreeNode[];
}

const CreateDomainModal = ({
  visible,
  form,
  onCancel,
  onFinish,
  loading,
  flattenedData,
}: IProps) => {
  const { t } = useTranslation(["common", "validate"]);
  return (
    <Modal
      title={t("common:domain_modal_create")}
      visible={visible}
      onCancel={onCancel}
      footer={[
        <Button key="cancel" onClick={onCancel}>
          {t("common:domain_cancel")}
        </Button>,
        <Button
          loading={loading}
          form="createDomainForm"
          key="create"
          type="primary"
          htmlType="submit"
        >
          {t("common:domain_create")}
        </Button>,
      ]}
    >
      <Form
        id="createDomainForm"
        form={form}
        onFinish={onFinish}
        layout="vertical"
        autoComplete="off"
      >
        <Form.Item
          name="name"
          label={t("common:domain_detail_name")}
          required
          rules={[
            {
              validator(_, value) {
                if (!value) {
                  return Promise.reject(t("validate:domain_name"));
                } else if (value.startsWith(" ") || value.endsWith(" ")) {
                  return Promise.reject(t("validate:domain_trim_space"));
                } else if (
                  checkContainsSpecialCharacter(value) ||
                  removeEmoji(value)
                ) {
                  return Promise.reject(
                    t("validate:domain_name_contains_special_character")
                  );
                } else if (flattenedData.some((item) => item.title === value)) {
                  return Promise.reject(t("validate:name_is_duplicated"));
                } else if (value.length >= 20) {
                  return Promise.reject(t("validate:domain_name_max_length"));
                }
                return Promise.resolve();
              },
            },
          ]}
          validateTrigger={["onBlur", "onChange"]}
        >
          <Input placeholder={t("common:domain_search_placeholder")} />
        </Form.Item>
        <Form.Item
          name="description"
          label={t("common:domain_detail_desc")}
          rules={[
            {
              validator(_, value) {
                if (value !== undefined) {
                  if (value.length !== value.trim().length) {
                    return Promise.reject(t("validate:domain_trim_space"));
                  }
                }
                return Promise.resolve();
              },
            },
          ]}
          validateTrigger={["onBlur", "onChange"]}
        >
          <Input.TextArea
            rows={4}
            placeholder={t("common:domain_detail_desc_placeholder")}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default CreateDomainModal;
