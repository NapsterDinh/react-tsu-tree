import { Button, Form, Input, Switch, Typography } from "antd";
import { FormInstance } from "antd/es/form/Form";
import React from "react";
import { useTranslation } from "react-i18next";
const { Title } = Typography;

interface IDomainParams {
  name: string;
  description: string;
  isActive: boolean;
  parentId: React.Key;
}

interface IProps {
  loading: boolean;
  disabled: boolean;
  form: FormInstance<any>;
  onFinish: (values: IDomainParams) => void;
  onChange: (changedValues?, allValues?) => void;
}

const DetailDomainForm = ({ loading, form, onFinish, onChange }: IProps) => {
  const { t } = useTranslation(["common", "validate"]);

  return (
    <Form
      onFinish={onFinish}
      initialValues={{
        name: "",
        isActive: true,
        description: "",
      }}
      form={form}
      layout="vertical"
      autoComplete="off"
      onValuesChange={onChange}
    >
      <Form.Item name="name">
        <Title level={4}>{form.getFieldValue("name")}</Title>
      </Form.Item>
      <Form.Item
        name="isActive"
        label={t("common:domain_detail_status")}
        valuePropName="checked"
      >
        <Switch checkedChildren="Active" unCheckedChildren="Inactive" />
      </Form.Item>
      <Form.Item
        name="description"
        label={t("common:domain_detail_desc")}
        rules={[
          {
            validator(_, value) {
              if (value !== undefined) {
                if (value.length !== value.trim().length) {
                  return Promise.reject(t("validate:domain_trim_space"));
                }
              }
              return Promise.resolve();
            },
          },
        ]}
        validateTrigger={["onChange"]}
      >
        <Input.TextArea
          rows={4}
          placeholder={t("common:domain_detail_desc_placeholder")}
        />
      </Form.Item>
      <Button type="primary" htmlType="submit" loading={loading}>
        {t("common:save")}
      </Button>
    </Form>
  );
};

export default DetailDomainForm;
