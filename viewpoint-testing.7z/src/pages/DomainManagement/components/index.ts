export { default as DetailDomainForm } from "./DetailDomainForm/DetailDomainForm";
export { default as CreateDomainModal } from "./Modals/CreateDomainModal";
